import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

enum Pose { phone, cards, book, water, chat }

/// شخصية كرتونية مرسومة بالكود (خطوط سميكة وألوان دافئة) مع حركة تنفّس ورمش.
class Character extends StatefulWidget {
  const Character({super.key, required this.pose, this.height = 190});
  final Pose pose;
  final double height;

  @override
  State<Character> createState() => _CharacterState();
}

class _CharacterState extends State<Character>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))
        ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final line = Pal.of(context).line;
    return SizedBox(
      height: widget.height,
      width: widget.height * 0.8,
      child: CustomPaint(painter: _CharPainter(widget.pose, _c, line)),
    );
  }
}

class _CharPainter extends CustomPainter {
  _CharPainter(this.pose, this.anim, this.line) : super(repaint: anim);
  final Pose pose;
  final Animation<double> anim;
  final Color line;

  static const skin = Color(0xFFF6C9A8);
  static const hair = Color(0xFF5B3A29);
  static const mustard = Color(0xFFE9B422);
  static const blue = Color(0xFF4A66B0);
  static const green = Color(0xFF7FA68A);
  static const cream = Color(0xFFFFF4DC);

  Paint _fill(Color c) => Paint()
    ..color = c
    ..style = PaintingStyle.fill;

  Paint _stroke([double w = 3]) => Paint()
    ..color = line
    ..style = PaintingStyle.stroke
    ..strokeWidth = w
    ..strokeJoin = StrokeJoin.round
    ..strokeCap = StrokeCap.round;

  void _shape(Canvas c, Path p, Color fill) {
    c.drawPath(p, _fill(fill));
    c.drawPath(p, _stroke());
  }

  void _rr(Canvas c, RRect r, Color fill) {
    c.drawRRect(r, _fill(fill));
    c.drawRRect(r, _stroke());
  }

  void _circle(Canvas c, Offset o, double r, Color fill) {
    c.drawCircle(o, r, _fill(fill));
    c.drawCircle(o, r, _stroke());
  }

  void _arm(Canvas c, Offset a, Offset b) {
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    p.color = line;
    p.strokeWidth = 26;
    c.drawLine(a, b, p);
    p.color = mustard;
    p.strokeWidth = 20;
    c.drawLine(a, b, p);
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 200, size.height / 250);
    canvas.clipRect(const Rect.fromLTWH(0, 0, 200, 250));

    final v = anim.value;
    final bob = math.sin(v * 2 * math.pi) * 3;
    canvas.translate(0, bob);
    final blink = v > 0.9 && v < 0.95;

    // شعر خلفي
    _rr(canvas, RRect.fromLTRBR(44, 42, 156, 152, const Radius.circular(42)), hair);

    // الجسم (كارديغان)
    _rr(
        canvas,
        RRect.fromLTRBAndCorners(36, 158, 164, 280,
            topLeft: const Radius.circular(48),
            topRight: const Radius.circular(48)),
        mustard);
    _rr(canvas, RRect.fromLTRBR(78, 160, 122, 280, const Radius.circular(6)),
        Colors.white);
    final vneck = Path()
      ..moveTo(84, 158)
      ..lineTo(100, 180)
      ..lineTo(116, 158)
      ..close();
    _shape(canvas, vneck, skin);
    canvas.drawCircle(const Offset(132, 205), 3, _fill(line));
    canvas.drawCircle(const Offset(132, 230), 3, _fill(line));

    // الذراعان
    late Offset lh, rh;
    switch (pose) {
      case Pose.phone:
        lh = const Offset(86, 214);
        rh = const Offset(152, 112);
        break;
      case Pose.cards:
        lh = const Offset(78, 216);
        rh = const Offset(122, 216);
        break;
      case Pose.book:
        lh = const Offset(66, 214);
        rh = const Offset(134, 214);
        break;
      case Pose.water:
        lh = const Offset(62, 214);
        rh = const Offset(140, 204);
        break;
      case Pose.chat:
        lh = const Offset(62, 214);
        rh = Offset(154 + math.sin(v * 2 * math.pi * 3) * 5, 118);
        break;
    }
    _arm(canvas, const Offset(58, 182), lh);
    _arm(canvas, const Offset(142, 182), rh);

    // الأدوات
    switch (pose) {
      case Pose.phone:
        canvas.save();
        canvas.translate(90, 208);
        canvas.rotate(-0.15);
        _rr(canvas, RRect.fromLTRBR(-15, -27, 15, 27, const Radius.circular(7)),
            green);
        canvas.drawCircle(const Offset(-6, -19), 2.5, _fill(line));
        canvas.drawCircle(const Offset(-6, -12), 2.5, _fill(line));
        canvas.restore();
        break;
      case Pose.cards:
        canvas.save();
        canvas.translate(90, 196);
        canvas.rotate(-0.2);
        _rr(canvas, RRect.fromLTRBR(-22, -32, 22, 32, const Radius.circular(8)),
            cream);
        canvas.restore();
        canvas.save();
        canvas.translate(110, 196);
        canvas.rotate(0.18);
        _rr(canvas, RRect.fromLTRBR(-22, -32, 22, 32, const Radius.circular(8)),
            Colors.white);
        canvas.drawLine(const Offset(-12, -12), const Offset(12, -12), _stroke(3));
        canvas.drawLine(const Offset(-12, 0), const Offset(8, 0), _stroke(3));
        canvas.restore();
        break;
      case Pose.book:
        final l = Path()
          ..moveTo(52, 198)
          ..lineTo(100, 206)
          ..lineTo(100, 246)
          ..lineTo(52, 238)
          ..close();
        final r = Path()
          ..moveTo(100, 206)
          ..lineTo(148, 198)
          ..lineTo(148, 238)
          ..lineTo(100, 246)
          ..close();
        _shape(canvas, l, Colors.white);
        _shape(canvas, r, cream);
        for (var i = 0; i < 3; i++) {
          final y = 214.0 + i * 8;
          canvas.drawLine(Offset(60, y - 2), Offset(92, y + 2), _stroke(2));
          canvas.drawLine(Offset(108, y + 2), Offset(140, y - 2), _stroke(2));
        }
        break;
      case Pose.water:
        _rr(canvas, RRect.fromLTRBR(128, 190, 168, 224, const Radius.circular(8)),
            blue);
        final spout = Path()
          ..moveTo(168, 204)
          ..lineTo(188, 186);
        canvas.drawPath(spout, _stroke(9));
        canvas.drawPath(
            spout,
            Paint()
              ..color = blue
              ..style = PaintingStyle.stroke
              ..strokeWidth = 5
              ..strokeCap = StrokeCap.round);
        for (var i = 0; i < 3; i++) {
          final t = (v * 3 + i / 3) % 1.0;
          canvas.drawCircle(Offset(192 + i * 2.0, 190 + t * 50), 2.6,
              _fill(blue.withAlpha(((1 - t) * 255).toInt())));
        }
        break;
      case Pose.chat:
        final tail = Path()
          ..moveTo(130, 38)
          ..lineTo(128, 54)
          ..lineTo(146, 38)
          ..close();
        _shape(canvas, tail, Colors.white);
        _rr(canvas, RRect.fromLTRBR(112, 2, 194, 40, const Radius.circular(14)),
            Colors.white);
        // لتغطية خط ذيل الفقاعة
        canvas.drawLine(const Offset(131, 38.5), const Offset(145, 38.5),
            Paint()
              ..color = Colors.white
              ..strokeWidth = 3.5);
        for (var i = 0; i < 3; i++) {
          final dy = math.sin(v * 2 * math.pi * 2 + i * 0.9) * 3;
          canvas.drawCircle(Offset(136 + i * 15.0, 21 + dy), 4, _fill(line));
        }
        break;
    }

    // الرقبة والرأس
    _rr(canvas, RRect.fromLTRBR(89, 128, 111, 164, const Radius.circular(6)), skin);
    final head = Rect.fromCenter(
        center: const Offset(100, 92), width: 92, height: 100);
    canvas.drawOval(head, _fill(skin));
    canvas.drawOval(head, _stroke());

    // الوجه
    if (blink) {
      canvas.drawLine(const Offset(77, 98), const Offset(87, 98), _stroke(3));
      canvas.drawLine(const Offset(113, 98), const Offset(123, 98), _stroke(3));
    } else {
      canvas.drawCircle(const Offset(82, 97), 3.8, _fill(line));
      canvas.drawCircle(const Offset(118, 97), 3.8, _fill(line));
    }
    canvas.drawCircle(const Offset(72, 111), 7, _fill(const Color(0x55F28B82)));
    canvas.drawCircle(const Offset(128, 111), 7, _fill(const Color(0x55F28B82)));
    final nose = Path()
      ..moveTo(100, 100)
      ..quadraticBezierTo(96, 108, 102, 109);
    canvas.drawPath(nose, _stroke(2.5));
    final smile = Path()
      ..moveTo(90, 115)
      ..quadraticBezierTo(100, 124, 110, 115);
    canvas.drawPath(smile, _stroke(3));

    // الغرّة
    final bangs = Path()
      ..moveTo(54, 98)
      ..quadraticBezierTo(48, 42, 100, 40)
      ..quadraticBezierTo(152, 42, 146, 98)
      ..quadraticBezierTo(138, 68, 112, 62)
      ..quadraticBezierTo(98, 80, 78, 70)
      ..quadraticBezierTo(60, 76, 54, 98)
      ..close();
    _shape(canvas, bangs, hair);

    // سماعات
    if (pose == Pose.phone) {
      final band = Rect.fromLTRB(44, 30, 156, 140);
      canvas.drawArc(
          band, math.pi, math.pi, false, _stroke(15));
      canvas.drawArc(
          band,
          math.pi,
          math.pi,
          false,
          Paint()
            ..color = blue
            ..style = PaintingStyle.stroke
            ..strokeWidth = 9);
      _rr(canvas, RRect.fromLTRBR(36, 82, 56, 118, const Radius.circular(9)), blue);
      _rr(canvas, RRect.fromLTRBR(144, 82, 164, 118, const Radius.circular(9)),
          blue);
    }

    // الأيدي
    _circle(canvas, lh, 11, skin);
    _circle(canvas, rh, 11, skin);
  }

  @override
  bool shouldRepaint(covariant _CharPainter old) =>
      old.pose != pose || old.line != line;
}
