import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Studylo palette: soft light surfaces + deep navy ink + indigo accent.
class C {
  static const cream = Color(0xFFF4F6FB); // app background
  static const creamDark = Color(0xFFE8ECF6); // secondary fills
  static const paper = Color(0xFFFFFFFF); // cards
  static const ink = Color(0xFF1E2749); // text + primary buttons
  static const grey = Color(0xFF6B7490);
  static const line = Color(0xFFE1E5F0);
  static const good = Color(0xFF2FA06B);
  static const bad = Color(0xFFD64545);
  static const warn = Color(0xFFE39A2D);
  static const accent = Color(0xFF5B6CF0);
  static const accentSoft = Color(0xFFE6E9FF);
  static const leaf = Color(0xFF3E9B5A);
}

ThemeData buildTheme() {
  const scheme = ColorScheme.light(
    primary: C.ink,
    onPrimary: C.cream,
    secondary: C.ink,
    onSecondary: C.cream,
    surface: C.cream,
    onSurface: C.ink,
    error: C.bad,
    onError: Colors.white,
    outline: C.line,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: C.cream,
    splashFactory: InkRipple.splashFactory,
  );
  final text = GoogleFonts.cairoTextTheme(base.textTheme)
      .apply(bodyColor: C.ink, displayColor: C.ink);

  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: c, width: w),
      );

  return base.copyWith(
    textTheme: text,
    primaryTextTheme: text,
    appBarTheme: AppBarTheme(
      backgroundColor: C.cream,
      foregroundColor: C.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: GoogleFonts.cairo(
          fontSize: 20, fontWeight: FontWeight.w800, color: C.ink),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: C.ink,
        foregroundColor: C.cream,
        disabledBackgroundColor: C.creamDark,
        minimumSize: const Size.fromHeight(54),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle:
            GoogleFonts.cairo(fontWeight: FontWeight.w700, fontSize: 16),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: C.ink,
        minimumSize: const Size(0, 50),
        side: const BorderSide(color: C.ink, width: 1.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle:
            GoogleFonts.cairo(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: C.ink,
        textStyle: GoogleFonts.cairo(fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.paper,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: GoogleFonts.cairo(color: C.grey.withAlpha(170)),
      border: border(C.line),
      enabledBorder: border(C.line),
      focusedBorder: border(C.ink, 1.6),
    ),
    textSelectionTheme: TextSelectionThemeData(
      cursorColor: C.ink,
      selectionColor: C.ink.withAlpha(50),
      selectionHandleColor: C.ink,
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(color: C.ink),
    dividerColor: C.line,
    dialogTheme: DialogThemeData(
      backgroundColor: C.paper,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: C.ink,
      contentTextStyle: GoogleFonts.cairo(color: C.cream),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
  );
}
