import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Plant kinds available in the Pomodoro garden.
const plantKinds = ['flower', 'tree', 'cactus'];

/// Animated plant that grows with [progress] (0 = seed, 1 = fully grown).
class PlantView extends StatefulWidget {
  const PlantView({
    super.key,
    required this.kind,
    required this.progress,
    this.wilt = 0,
    this.animate = true,
    this.showPot = true,
  });

  final String kind;
  final double progress;
  final double wilt;
  final bool animate;
  final bool showPot;

  @override
  State<PlantView> createState() => _PlantViewState();
}

class _PlantViewState extends State<PlantView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(seconds: 7));

  @override
  void initState() {
    super.initState();
    if (widget.animate) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant PlantView old) {
    super.didUpdateWidget(old);
    if (widget.animate && !_c.isAnimating) _c.repeat();
    if (!widget.animate && _c.isAnimating) _c.stop();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget paint(double p) => AnimatedBuilder(
          animation: _c,
          builder: (context, _) => CustomPaint(
            size: Size.infinite,
            painter: PlantPainter(
              kind: widget.kind,
              progress: p,
              t: widget.animate ? _c.value : 0.25,
              wilt: widget.wilt,
              showPot: widget.showPot,
              particles: widget.animate,
            ),
          ),
        );
    if (!widget.animate) return paint(widget.progress);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(end: widget.progress),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOut,
      builder: (context, p, _) => paint(p),
    );
  }
}

/// Draws a potted plant in a virtual 300 x 340 box (scaled to fit).
class PlantPainter extends CustomPainter {
  PlantPainter({
    required this.kind,
    required this.progress,
    this.t = 0,
    this.wilt = 0,
    this.showPot = true,
    this.particles = true,
  });

  final String kind;
  final double progress;
  final double t; // 0..1 looping time for sway
  final double wilt; // 0..1 (withered)
  final bool showPot;
  final bool particles;

  static const double _w = 300;
  static const double _h = 340;
  static const Offset _base = Offset(150, 258);

  // ------------------------------------------------------------- helpers
  double _seg(double p, double a, double b) =>
      ((p - a) / (b - a)).clamp(0.0, 1.0).toDouble();

  double _ease(double x) => 1 - math.pow(1 - x, 3).toDouble();

  Color _g(Color c) => Color.lerp(c, const Color(0xFF9A8A52), wilt * 0.9)!;

  Offset _bez(Offset a, Offset b, Offset c, double u) {
    final v = 1 - u;
    return Offset(
      v * v * a.dx + 2 * v * u * b.dx + u * u * c.dx,
      v * v * a.dy + 2 * v * u * b.dy + u * u * c.dy,
    );
  }

  // --------------------------------------------------------------- paint
  @override
  void paint(Canvas canvas, Size size) {
    final sc = math.min(size.width / _w, size.height / _h);
    canvas.save();
    canvas.translate((size.width - _w * sc) / 2, (size.height - _h * sc) / 2);
    canvas.scale(sc);

    if (particles && wilt == 0) _drawParticles(canvas);
    if (showPot) _drawPotBack(canvas);

    final p = progress.clamp(0.0, 1.0).toDouble();
    _drawSeed(canvas, p);
    switch (kind) {
      case 'tree':
        _drawTree(canvas, p);
        break;
      case 'cactus':
        _drawCactus(canvas, p);
        break;
      default:
        _drawFlower(canvas, p);
    }
    if (showPot) _drawPotFront(canvas);
    canvas.restore();
  }

  // ------------------------------------------------------------ ambience
  void _drawParticles(Canvas c) {
    for (var i = 0; i < 9; i++) {
      final phase = (t + i * 0.113) % 1.0;
      final x = 38 + ((i * 53) % 224) + math.sin((phase + i) * 6.28) * 6;
      final y = 300 - phase * 250;
      final a = (math.sin(math.pi * phase) * 150).round().clamp(0, 255);
      c.drawCircle(
        Offset(x, y),
        1.6 + (i % 3) * 0.7,
        Paint()..color = const Color(0xFFFFF3B0).withAlpha(a),
      );
    }
  }

  // ----------------------------------------------------------------- pot
  void _drawPotBack(Canvas c) {
    // ground shadow
    c.drawOval(
      Rect.fromCenter(center: const Offset(150, 331), width: 136, height: 14),
      Paint()
        ..color = Colors.black.withAlpha(34)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    // body
    final body = Path()
      ..moveTo(98, 276)
      ..lineTo(202, 276)
      ..lineTo(191, 322)
      ..quadraticBezierTo(189, 331, 179, 331)
      ..lineTo(121, 331)
      ..quadraticBezierTo(111, 331, 109, 322)
      ..close();
    c.drawPath(
      body,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFFD2693E), Color(0xFFF0A074), Color(0xFFC25A32)],
          stops: [0, 0.42, 1],
        ).createShader(const Rect.fromLTRB(98, 276, 202, 331)),
    );
    // rim
    final rim =
        RRect.fromRectAndRadius(const Rect.fromLTRB(88, 258, 212, 284), const Radius.circular(9));
    c.drawRRect(
      rim,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFFD8744A), Color(0xFFF4AA7E), Color(0xFFC95F37)],
          stops: [0, 0.4, 1],
        ).createShader(rim.outerRect),
    );
    c.drawRRect(
      RRect.fromRectAndRadius(
          const Rect.fromLTRB(96, 262, 204, 266), const Radius.circular(2)),
      Paint()..color = Colors.white.withAlpha(70),
    );
    // soil
    final soil = Rect.fromCenter(
        center: const Offset(150, 259), width: 112, height: 13);
    c.drawOval(
      soil,
      Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFF6B4A30), Color(0xFF3E2A1A)],
        ).createShader(soil),
    );
    // soil crumbs
    final crumb = Paint()..color = const Color(0xFF8A6542).withAlpha(150);
    for (final o in const [
      Offset(122, 259),
      Offset(134, 262),
      Offset(168, 261),
      Offset(179, 258),
      Offset(142, 256)
    ]) {
      c.drawCircle(o, 1.6, crumb);
    }
  }

  void _drawPotFront(Canvas c) {
    // thin front lip so stems look planted inside the soil
    final lip = Path()
      ..moveTo(92, 262)
      ..quadraticBezierTo(150, 270, 208, 262)
      ..lineTo(208, 268)
      ..quadraticBezierTo(150, 277, 92, 268)
      ..close();
    c.drawPath(
      lip,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFFD8744A), Color(0xFFF4AA7E), Color(0xFFC95F37)],
          stops: [0, 0.4, 1],
        ).createShader(const Rect.fromLTRB(92, 262, 208, 277)),
    );
  }

  void _drawSeed(Canvas c, double p) {
    final a = ((1 - _seg(p, 0.0, 0.12)) * 255).round();
    if (a <= 0) return;
    final seed = Rect.fromCenter(
        center: const Offset(150, 256), width: 15, height: 9);
    c.drawOval(seed, Paint()..color = const Color(0xFF8B5E34).withAlpha(a));
    c.drawOval(
      Rect.fromCenter(center: const Offset(148, 254.5), width: 7, height: 3),
      Paint()..color = const Color(0xFFC79A66).withAlpha(a),
    );
  }

  // ---------------------------------------------------------------- leaf
  void _leaf(Canvas c, Offset base, double angle, double len, double wid,
      Color a, Color b) {
    if (len < 1.5) return;
    c.save();
    c.translate(base.dx, base.dy);
    c.rotate(angle);
    final path = Path()
      ..moveTo(0, 0)
      ..cubicTo(len * 0.22, -wid * 1.05, len * 0.72, -wid * 0.9, len, 0)
      ..cubicTo(len * 0.72, wid * 0.9, len * 0.22, wid * 1.05, 0, 0)
      ..close();
    final rect = Rect.fromLTWH(0, -wid, len, wid * 2);
    c.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(colors: [a, b]).createShader(rect),
    );
    c.save();
    c.clipPath(path);
    c.drawRect(Rect.fromLTWH(0, 0, len, wid),
        Paint()..color = Colors.black.withAlpha(24));
    c.restore();
    c.drawLine(
      Offset(len * 0.04, 0),
      Offset(len * 0.92, 0),
      Paint()
        ..color = Colors.white.withAlpha(95)
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = math.max(0.8, wid * 0.07),
    );
    final vein = Paint()
      ..color = Colors.white.withAlpha(50)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(0.6, wid * 0.04);
    for (var i = 1; i <= 3; i++) {
      final x = len * (0.16 + i * 0.2);
      final dy = wid * 0.55 * (1 - i * 0.14);
      c.drawLine(Offset(x, 0), Offset(x + len * 0.13, -dy), vein);
      c.drawLine(Offset(x, 0), Offset(x + len * 0.13, dy), vein);
    }
    c.restore();
  }

  void _leafPair(Canvas c, Offset at, double size, double grow, double phase,
      {double lift = 0.5}) {
    final a = _g(const Color(0xFF2C7F45));
    final b = _g(const Color(0xFF66C173));
    final sw = math.sin(t * 2 * math.pi + phase) * 0.05;
    final len = size * grow;
    final wid = size * 0.3 * grow;
    final droop = wilt * 1.1;
    _leaf(c, at, -lift + droop + sw, len, wid, a, b);
    _leaf(c, at, math.pi + lift - droop - sw, len, wid, a, b);
  }

  // ---------------------------------------------------------------- stem
  Offset _drawStem(
    Canvas c, {
    required double height,
    required double w0,
    required double w1,
    required Color c0,
    required Color c1,
    required Offset p1,
    required Offset p2,
  }) {
    const n = 30;
    Offset prev = _base;
    for (var i = 1; i <= n; i++) {
      final u = i / n;
      final cur = _bez(_base, p1, p2, u);
      final col = Color.lerp(_g(c0), _g(c1), u)!;
      final wd = w0 + (w1 - w0) * u;
      c.drawLine(
        prev,
        cur,
        Paint()
          ..color = col
          ..strokeWidth = wd
          ..strokeCap = StrokeCap.round,
      );
      // soft highlight on the lit side
      c.drawLine(
        prev.translate(-wd * 0.18, 0),
        cur.translate(-wd * 0.18, 0),
        Paint()
          ..color = Colors.white.withAlpha(34)
          ..strokeWidth = wd * 0.28
          ..strokeCap = StrokeCap.round,
      );
      prev = cur;
    }
    return p2;
  }

  // -------------------------------------------------------------- flower
  void _drawFlower(Canvas c, double p) {
    if (p < 0.04) return;
    final sw = math.sin(t * 2 * math.pi);
    final grow = _ease(_seg(p, 0.04, 0.8));
    final h = 8 + 178 * grow;
    final lean = 8.0;
    final p1 = Offset(_base.dx - lean * 0.6, _base.dy - h * 0.55);
    final p2 = Offset(
      _base.dx + lean + sw * (2 + 5 * grow) + wilt * 58,
      _base.dy - h * (1 - wilt * 0.28),
    );
    final top = _drawStem(c,
        height: h,
        w0: 8.5,
        w1: 4.4,
        c0: const Color(0xFF2B7A44),
        c1: const Color(0xFF55B166),
        p1: p1,
        p2: p2);

    // side leaf pairs
    const ts = [0.2, 0.36, 0.52, 0.68];
    const sizes = [66.0, 60.0, 52.0, 44.0];
    for (var i = 0; i < ts.length; i++) {
      final th = 0.14 + i * 0.12;
      final g = _ease(_seg(p, th, th + 0.2));
      if (g <= 0) continue;
      final at = _bez(_base, p1, p2, ts[i]);
      _leafPair(c, at, sizes[i], g, i * 1.3, lift: 0.55 - i * 0.05);
    }
    // sprout leaves at the top (shrink away when the head forms)
    final sprout = _ease(_seg(p, 0.06, 0.3)) * (1 - _seg(p, 0.55, 0.78));
    if (sprout > 0) _leafPair(c, top, 30, sprout, 0.4, lift: 1.05);

    // head
    final bud = _ease(_seg(p, 0.6, 0.82));
    final bloom = _ease(_seg(p, 0.8, 1.0));
    if (bud <= 0) return;
    c.save();
    c.translate(top.dx, top.dy);
    c.rotate(sw * 0.045 + wilt * 1.25);
    c.translate(0, -4);
    if (bloom <= 0) {
      _drawBud(c, bud);
    } else {
      _drawSunflower(c, bloom);
    }
    c.restore();
  }

  void _drawBud(Canvas c, double bud) {
    final w = 10.0 * bud, h = 15.0 * bud;
    final rect = Rect.fromCenter(center: Offset(0, -h * 0.6), width: w * 2, height: h * 2);
    c.drawOval(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [_g(const Color(0xFF2F8A47)), _g(const Color(0xFFF3B722))],
          stops: const [0.45, 1],
        ).createShader(rect),
    );
    c.drawLine(
      Offset(0, -h * 0.1),
      Offset(0, -h * 1.5),
      Paint()
        ..color = Colors.white.withAlpha(60)
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.round,
    );
  }

  void _drawSunflower(Canvas c, double bloom) {
    final center = Offset(0, -26 * bloom);
    c.save();
    c.translate(center.dx, center.dy);
    // sepals
    for (var i = 0; i < 8; i++) {
      _leaf(c, Offset.zero, i * math.pi / 4, 20 * bloom, 5.5 * bloom,
          _g(const Color(0xFF2A7A42)), _g(const Color(0xFF4FAE62)));
    }
    final visible = (16 * (1 - wilt * 0.6)).round();
    final petalLen = 36 * bloom * (1 - wilt * 0.25);
    final petalW = 11.5 * bloom;
    // back layer
    for (var i = 0; i < visible; i++) {
      final ang = (i + 0.5) * 2 * math.pi / 16 + math.sin(i * 1.7) * 0.03;
      _petal(c, ang, petalLen * 0.92, petalW,
          _g(const Color(0xFFEF9A12)), _g(const Color(0xFFF7BE2E)));
    }
    // front layer
    for (var i = 0; i < visible; i++) {
      final ang = i * 2 * math.pi / 16 + math.sin(i * 2.3) * 0.04;
      _petal(c, ang, petalLen, petalW,
          _g(const Color(0xFFF6AE1B)), _g(const Color(0xFFFFE15A)));
    }
    // disk
    final r = 15 * bloom;
    final disk = Rect.fromCircle(center: Offset.zero, radius: r);
    c.drawCircle(
      Offset.zero,
      r,
      Paint()
        ..shader = RadialGradient(colors: [
          _g(const Color(0xFF5A3517)),
          _g(const Color(0xFF3B220E)),
        ]).createShader(disk),
    );
    c.drawCircle(
      Offset.zero,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2 * bloom
        ..color = _g(const Color(0xFF9A6A2C)).withAlpha(190),
    );
    final dot = Paint()..color = _g(const Color(0xFFB98A4A)).withAlpha(200);
    for (var k = 1; k < 70; k++) {
      final rr = (r - 2.5) * math.sqrt(k / 70);
      final a = k * 2.399963;
      c.drawCircle(Offset(rr * math.cos(a), rr * math.sin(a)), 0.9 * bloom, dot);
    }
    c.restore();
  }

  void _petal(Canvas c, double ang, double len, double wid, Color a, Color b) {
    if (len < 1) return;
    c.save();
    c.rotate(ang);
    c.translate(8, 0);
    final path = Path()
      ..moveTo(0, 0)
      ..cubicTo(len * 0.25, -wid * 1.1, len * 0.85, -wid * 0.75, len, 0)
      ..cubicTo(len * 0.85, wid * 0.75, len * 0.25, wid * 1.1, 0, 0)
      ..close();
    c.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(colors: [a, b])
            .createShader(Rect.fromLTWH(0, -wid, len, wid * 2)),
    );
    c.drawLine(
      Offset(len * 0.1, 0),
      Offset(len * 0.8, 0),
      Paint()
        ..color = Colors.white.withAlpha(60)
        ..strokeWidth = 0.9,
    );
    c.restore();
  }

  // ---------------------------------------------------------------- tree
  void _drawTree(Canvas c, double p) {
    if (p < 0.04) return;
    final sw = math.sin(t * 2 * math.pi);
    final grow = _ease(_seg(p, 0.04, 0.72));
    final h = 8 + 150 * grow;
    final p1 = Offset(_base.dx + 6, _base.dy - h * 0.55);
    final p2 = Offset(
      _base.dx - 4 + sw * (1.5 + 3 * grow) + wilt * 40,
      _base.dy - h * (1 - wilt * 0.2),
    );
    final woody = _seg(p, 0.2, 0.5);
    final top = _drawStem(c,
        height: h,
        w0: 7 + 8 * woody,
        w1: 4 + 3.5 * woody,
        c0: Color.lerp(const Color(0xFF2B7A44), const Color(0xFF6E4A2A), woody)!,
        c1: Color.lerp(const Color(0xFF55B166), const Color(0xFF9A6B3C), woody)!,
        p1: p1,
        p2: p2);

    const ts = [0.3, 0.5, 0.68];
    const sizes = [46.0, 42.0, 36.0];
    for (var i = 0; i < ts.length; i++) {
      final th = 0.16 + i * 0.14;
      final g = _ease(_seg(p, th, th + 0.2));
      if (g <= 0) continue;
      _leafPair(c, _bez(_base, p1, p2, ts[i]), sizes[i], g, i * 1.1,
          lift: 0.6);
    }
    final sprout = _ease(_seg(p, 0.06, 0.3)) * (1 - _seg(p, 0.5, 0.7));
    if (sprout > 0) _leafPair(c, top, 28, sprout, 0.3, lift: 1.0);

    // canopy
    final cg = _ease(_seg(p, 0.42, 1.0));
    if (cg <= 0) return;
    final R = 74.0 * cg * (1 - wilt * 0.28);
    final center = top.translate(sw * 2.5 * cg, -12 * cg + wilt * 22);
    const blobs = [
      [0.0, 0.1, 0.6, 0.0],
      [-0.5, 0.18, 0.5, 0.0],
      [0.5, 0.18, 0.5, 0.0],
      [-0.28, -0.4, 0.52, 1.0],
      [0.3, -0.42, 0.5, 1.0],
      [0.0, -0.18, 0.6, 1.0],
      [-0.66, 0.4, 0.38, 0.0],
      [0.66, 0.4, 0.38, 0.0],
      [-0.2, 0.34, 0.44, 0.0],
      [0.26, 0.36, 0.44, 0.0],
    ];
    for (final b in blobs) {
      final rr = R * b[2];
      final cc = center.translate(R * b[0], R * b[1] * 0.9);
      final light = b[3] > 0.5;
      final rect = Rect.fromCircle(center: cc, radius: rr);
      c.drawCircle(
        cc,
        rr,
        Paint()
          ..shader = RadialGradient(
            center: const Alignment(-0.35, -0.45),
            radius: 1.0,
            colors: [
              _g(light ? const Color(0xFF7BD27E) : const Color(0xFF4DAE5F)),
              _g(light ? const Color(0xFF3C9B52) : const Color(0xFF22703C)),
            ],
          ).createShader(rect),
        );
    }
    // edge leaves for an organic outline
    for (var i = 0; i < 16; i++) {
      final a = i * 2 * math.pi / 16 + 0.2;
      final pos = center.translate(
          math.cos(a) * R * 0.86, math.sin(a) * R * 0.74 - R * 0.05);
      final sway = math.sin(t * 2 * math.pi + i) * 0.06;
      _leaf(c, pos, a + sway + wilt * 0.8, 20 * cg, 6.5 * cg,
          _g(const Color(0xFF2F8F4A)), _g(const Color(0xFF6DCB78)));
    }
    // soft highlights
    final hl = Paint()..color = Colors.white.withAlpha(26);
    for (var i = 0; i < 7; i++) {
      c.drawCircle(
        center.translate(math.cos(i * 1.9) * R * 0.5 - R * 0.1,
            math.sin(i * 2.3) * R * 0.4 - R * 0.2),
        R * 0.07,
        hl,
      );
    }
    // apples
    final ap = _ease(_seg(p, 0.9, 1.0)) * (1 - wilt);
    if (ap > 0) {
      for (final o in const [
        Offset(-0.38, 0.12),
        Offset(0.34, 0.02),
        Offset(0.05, 0.42),
      ]) {
        final pos = center.translate(R * o.dx, R * o.dy);
        final r = 6.2 * ap;
        c.drawCircle(
          pos,
          r,
          Paint()
            ..shader = const RadialGradient(
              center: Alignment(-0.4, -0.4),
              colors: [Color(0xFFFF6B5E), Color(0xFFC62828)],
            ).createShader(Rect.fromCircle(center: pos, radius: r)),
        );
        c.drawCircle(pos.translate(-r * 0.35, -r * 0.4), r * 0.22,
            Paint()..color = Colors.white.withAlpha(150));
      }
    }
  }

  // -------------------------------------------------------------- cactus
  void _drawCactus(Canvas c, double p) {
    if (p < 0.04) return;
    final sw = math.sin(t * 2 * math.pi);
    final grow = _ease(_seg(p, 0.04, 0.85));
    final hc = 14 + 150 * grow;
    const bw = 46.0;
    c.save();
    c.translate(_base.dx, _base.dy);
    c.rotate(sw * 0.012 + wilt * 0.32);
    c.translate(-_base.dx, -_base.dy);

    final dark = _g(const Color(0xFF2A7646));
    final mid = _g(const Color(0xFF5DB96E));

    // arms (behind body)
    void arm(double side, double yFrac, double th, double reach, double rise) {
      final g = _ease(_seg(p, th, th + 0.22));
      if (g <= 0) return;
      final y = _base.dy - hc * yFrac;
      final x0 = _base.dx + side * (bw / 2 - 4);
      final path = Path()
        ..moveTo(x0, y)
        ..lineTo(x0 + side * reach * g, y)
        ..lineTo(x0 + side * reach * g, y - rise * g);
      c.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..strokeWidth = 17
          ..color = dark,
      );
      c.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..strokeWidth = 9
          ..color = mid,
      );
    }

    arm(1, 0.42, 0.42, 30, 40);
    arm(-1, 0.6, 0.58, 26, 30);

    // body
    final body = RRect.fromRectAndCorners(
      Rect.fromLTRB(_base.dx - bw / 2, _base.dy - hc, _base.dx + bw / 2, _base.dy),
      topLeft: const Radius.circular(23),
      topRight: const Radius.circular(23),
      bottomLeft: const Radius.circular(5),
      bottomRight: const Radius.circular(5),
    );
    c.drawRRect(
      body,
      Paint()
        ..shader = LinearGradient(
          colors: [dark, mid, dark],
          stops: const [0, 0.45, 1],
        ).createShader(body.outerRect),
    );
    // ribs
    final rib = Paint()
      ..color = const Color(0xFF1B5A34).withAlpha(70)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    for (final dx in const [-11.0, 0.0, 11.0]) {
      final path = Path()
        ..moveTo(_base.dx + dx, _base.dy - 2)
        ..quadraticBezierTo(_base.dx + dx * 1.15, _base.dy - hc * 0.5,
            _base.dx + dx * 0.6, _base.dy - hc + 16);
      c.drawPath(path, rib);
    }
    // spines
    final sp = Paint()
      ..color = const Color(0xFFFFF3D1).withAlpha(230)
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round;
    var row = 0;
    for (var y = _base.dy - 14; y > _base.dy - hc + 18; y -= 15) {
      for (final dx in (row.isEven ? const [-14.0, 0.0, 14.0] : const [-7.0, 7.0])) {
        final o = Offset(_base.dx + dx, y);
        c.drawLine(o.translate(-3, -3), o.translate(3, 3), sp);
        c.drawLine(o.translate(3, -3), o.translate(-3, 3), sp);
      }
      row++;
    }
    // flower on top
    final bloom = _ease(_seg(p, 0.88, 1.0)) * (1 - wilt * 0.7);
    if (bloom > 0) {
      final fc = Offset(_base.dx, _base.dy - hc + 2);
      for (var i = 0; i < 6; i++) {
        c.save();
        c.translate(fc.dx, fc.dy);
        c.rotate(i * math.pi / 3 + 0.3);
        final r = Rect.fromCenter(
            center: Offset(0, -9 * bloom), width: 9 * bloom, height: 20 * bloom);
        c.drawOval(
          r,
          Paint()
            ..shader = const LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [Color(0xFFFF4F8E), Color(0xFFFFA6C6)],
            ).createShader(r),
        );
        c.restore();
      }
      c.drawCircle(fc, 4.5 * bloom, Paint()..color = const Color(0xFFFFD84A));
    }
    c.restore();
  }

  @override
  bool shouldRepaint(covariant PlantPainter old) =>
      old.progress != progress ||
      old.t != t ||
      old.wilt != wilt ||
      old.kind != kind ||
      old.showPot != showPot ||
      old.particles != particles;
}
