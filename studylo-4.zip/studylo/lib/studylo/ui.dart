import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import 'illus.dart';
import 'services/ai_service.dart';
import 'state.dart';
import 'theme.dart';

// ----------------------------------------------------------------- helpers
extension Tr on BuildContext {
  /// Translated string (rebuilds when the language changes). Use in build().
  String tr(String k) => Provider.of<AppState>(this).t(k);

  /// Translated string without listening. Use in callbacks.
  String trr(String k) => Provider.of<AppState>(this, listen: false).t(k);

  bool get isAr => Provider.of<AppState>(this).locale == 'ar';
}

String errMsg(BuildContext context, Object e) {
  final s = Provider.of<AppState>(context, listen: false);
  if (e is AiException) {
    final base = s.t(e.code);
    final d = e.detail;
    return (d == null || d.isEmpty) ? base : '$base\n$d';
  }
  if (e is FormatException) return s.t('err_parse');
  return s.t('err_generic');
}

void toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? C.bad : C.ink,
    ));
}

Future<bool> confirm(BuildContext context, String message,
    {String? yes}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Text(message, style: const TextStyle(fontSize: 16, height: 1.5)),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(ctx.trr('cancel'))),
        TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(yes ?? ctx.trr('ok'))),
      ],
    ),
  );
  return r == true;
}

String fmtDate(DateTime d) => '${d.year}/${d.month}/${d.day}';

Route<T> slideRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 350),
      reverseTransitionDuration: const Duration(milliseconds: 250),
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, anim, __, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
                .animate(curved),
            child: child,
          ),
        );
      },
    );

/// Runs [job] behind a blocking "AI is working" dialog. Returns null on error
/// (and shows the error as a toast).
Future<T?> runBusy<T>(
    BuildContext context, String message, Future<T> Function() job) async {
  final nav = Navigator.of(context, rootNavigator: true);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: C.ink.withAlpha(150),
    builder: (_) => PopScope(canPop: false, child: _BusyDialog(message)),
  );
  try {
    final r = await job();
    nav.pop();
    return r;
  } catch (e) {
    nav.pop();
    if (context.mounted) toast(context, errMsg(context, e), error: true);
    return null;
  }
}

class _BusyDialog extends StatelessWidget {
  const _BusyDialog(this.message);
  final String message;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var i = 0; i < 3; i++)
                  Container(
                    width: 12,
                    height: 12,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration:
                        const BoxDecoration(color: C.ink, shape: BoxShape.circle),
                  )
                      .animate(
                        delay: (i * 160).ms,
                        onPlay: (c) => c.repeat(reverse: true),
                      )
                      .scale(
                        begin: const Offset(0.5, 0.5),
                        end: const Offset(1.2, 1.2),
                        duration: 450.ms,
                        curve: Curves.easeInOut,
                      ),
              ],
            ),
            const SizedBox(height: 20),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(context.trr('please_wait'),
                style: const TextStyle(fontSize: 13, color: C.grey)),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------- widgets
class StudyLogo extends StatelessWidget {
  const StudyLogo({super.key, this.size = 48});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: C.ink,
        borderRadius: BorderRadius.circular(size * 0.3),
      ),
      child: Icon(Icons.auto_stories_rounded, color: C.cream, size: size * 0.55),
    );
  }
}

class ScreenHeader extends StatelessWidget {
  const ScreenHeader({super.key, required this.title, this.subtitle});
  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 30, fontWeight: FontWeight.w800, height: 1.2)),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(subtitle!,
                        style: const TextStyle(color: C.grey, fontSize: 14)),
                  ),
              ],
            ),
          ),
          const StudyLogo(size: 44),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.15, end: 0);
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 10),
        child: Text(text,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      );
}

class PaperCard extends StatelessWidget {
  const PaperCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.onTap,
    this.borderColor,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final VoidCallback? onTap;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(18);
    return Material(
      color: color ?? C.paper,
      borderRadius: r,
      child: InkWell(
        onTap: onTap,
        borderRadius: r,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: r,
            border: Border.all(color: borderColor ?? C.line),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Segmented choice row (cream/black).
class Seg<T> extends StatelessWidget {
  const Seg({
    super.key,
    required this.items,
    required this.value,
    required this.onChanged,
  });

  final Map<T, String> items;
  final T value;
  final ValueChanged<T> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: C.creamDark,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          for (final e in items.entries)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onChanged(e.key),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOut,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: e.key == value ? C.ink : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    e.value,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: e.key == value ? C.cream : C.ink,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill({super.key, required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? C.ink : C.paper,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: selected ? C.ink : C.line),
        ),
        child: Text(label,
            style: TextStyle(
                color: selected ? C.cream : C.ink,
                fontWeight: FontWeight.w700,
                fontSize: 13)),
      ),
    );
  }
}

class CountStepper extends StatelessWidget {
  const CountStepper({
    super.key,
    required this.label,
    required this.value,
    required this.onChanged,
    this.min = 0,
    this.max = 20,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(label,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
        ),
        _RoundBtn(Icons.remove, value > min ? () => onChanged(value - 1) : null),
        SizedBox(
          width: 46,
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
              child: Text('$value',
                  key: ValueKey(value),
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ),
          ),
        ),
        _RoundBtn(Icons.add, value < max ? () => onChanged(value + 1) : null),
      ],
    );
  }
}

class _RoundBtn extends StatelessWidget {
  const _RoundBtn(this.icon, this.onTap);
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: onTap == null ? C.creamDark : C.ink,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 36,
          height: 36,
          child: Icon(icon, size: 18, color: onTap == null ? C.grey : C.cream),
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState(
      {super.key, required this.icon, required this.text, this.illus});
  final IconData icon;
  final String text;

  /// Optional illustration name (assets/illus). Replaces the icon bubble.
  final String? illus;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 36),
      child: Column(
        children: [
          if (illus != null)
            IllusImg(illus!, size: 140, float: true)
          else
            Container(
              width: 84,
              height: 84,
              decoration: const BoxDecoration(
                  color: C.creamDark, shape: BoxShape.circle),
              child: Icon(icon, size: 38, color: C.ink),
            )
                .animate(onPlay: (c) => c.repeat(reverse: true))
                .moveY(
                    begin: -4,
                    end: 4,
                    duration: 1500.ms,
                    curve: Curves.easeInOut),
          const SizedBox(height: 14),
          Text(text,
              textAlign: TextAlign.center,
              style: const TextStyle(color: C.grey, fontSize: 15, height: 1.5)),
        ],
      ),
    );
  }
}

/// Types text out letter by letter (always laid out left-to-right).
class Typewriter extends StatefulWidget {
  const Typewriter({
    super.key,
    required this.text,
    this.style,
    this.delay = Duration.zero,
    this.duration = const Duration(milliseconds: 900),
  });

  final String text;
  final TextStyle? style;
  final Duration delay;
  final Duration duration;

  @override
  State<Typewriter> createState() => _TypewriterState();
}

class _TypewriterState extends State<Typewriter>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: widget.duration);

  @override
  void initState() {
    super.initState();
    Future.delayed(widget.delay, () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final n = (widget.text.length * _c.value).round();
          return Stack(
            children: [
              Opacity(opacity: 0, child: Text(widget.text, style: widget.style)),
              Text(widget.text.substring(0, n), style: widget.style),
            ],
          );
        },
      ),
    );
  }
}

/// Text field that looks like lined exam paper.
class RuledField extends StatelessWidget {
  const RuledField({
    super.key,
    required this.controller,
    this.minLines = 4,
    this.readOnly = false,
    this.hint,
  });

  final TextEditingController controller;
  final int minLines;
  final bool readOnly;
  final String? hint;

  static const double lineHeight = 32;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: CustomPaint(painter: _LinesPainter())),
        TextField(
          controller: controller,
          readOnly: readOnly,
          minLines: minLines,
          maxLines: null,
          keyboardType: TextInputType.multiline,
          style: const TextStyle(fontSize: 16, height: 2.0, color: C.ink),
          strutStyle: const StrutStyle(
              fontSize: 16, height: 2.0, forceStrutHeight: true),
          decoration: InputDecoration(
            hintText: hint,
            filled: false,
            isDense: true,
            contentPadding: EdgeInsets.zero,
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
          ),
        ),
      ],
    );
  }
}

class _LinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = C.line
      ..strokeWidth = 1;
    for (double y = RuledField.lineHeight; y <= size.height + 0.5; y += RuledField.lineHeight) {
      canvas.drawLine(Offset(0, y - 1), Offset(size.width, y - 1), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Renders model text: headings (ending with ':'), bullets and paragraphs.
class FormattedText extends StatelessWidget {
  const FormattedText(this.text, {super.key, this.fontSize = 16});
  final String text;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final widgets = <Widget>[];
    for (final line in text.split('\n')) {
      var t = line.trim().replaceAll('**', '');
      if (t.isEmpty) {
        widgets.add(const SizedBox(height: 8));
        continue;
      }
      final hashHead = t.startsWith('#');
      if (hashHead) t = t.replaceFirst(RegExp(r'^#+\s*'), '');
      final bullet = t.startsWith('•') || t.startsWith('- ') || t.startsWith('* ');
      if (bullet) {
        t = t.substring(1).trim();
        widgets.add(Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 9, left: 4, right: 4),
                child: Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                        color: C.ink, shape: BoxShape.circle)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: SelectableText(t,
                    style: TextStyle(fontSize: fontSize, height: 1.6)),
              ),
            ],
          ),
        ));
        continue;
      }
      final head = hashHead ||
          (t.length <= 60 && (t.endsWith(':') || t.endsWith('：')));
      widgets.add(Padding(
        padding: EdgeInsets.only(top: head ? 10 : 0, bottom: 4),
        child: SelectableText(t,
            style: TextStyle(
              fontSize: head ? fontSize + 1 : fontSize,
              height: 1.6,
              fontWeight: head ? FontWeight.w800 : FontWeight.w400,
            )),
      ));
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets);
  }
}
