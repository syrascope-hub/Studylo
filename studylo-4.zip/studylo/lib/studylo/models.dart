import '../models.dart' show Flashcard;

int _ctr = 0;

String newId() => '${DateTime.now().microsecondsSinceEpoch}${_ctr++}';

String asStr(dynamic v) => v == null ? '' : v.toString().trim();

int asInt(dynamic v, [int d = 0]) {
  if (v is int) return v;
  if (v is num) return v.round();
  if (v is String) return int.tryParse(v.trim()) ?? d;
  return d;
}

double asDouble(dynamic v, [double d = 0]) {
  if (v is num) return v.toDouble();
  if (v is String) return double.tryParse(v.trim()) ?? d;
  return d;
}

/// Result of grading one question.
class QResult {
  const QResult(this.score, this.feedback);
  final double score; // 0..1
  final String feedback;
}

class Question {
  const Question({
    required this.type,
    required this.text,
    this.options = const [],
    this.correct = 0,
    this.modelAnswer = '',
    this.explanation = '',
    this.ref,
  });

  final String type; // mcq | explain | solve
  final String text;
  final List<String> options;
  final int correct;
  final String modelAnswer;
  final String explanation;

  /// Id of the Mistake this question was created from (retry quizzes).
  final String? ref;

  bool get isMcq => type == 'mcq';

  static int rank(String type) =>
      type == 'mcq' ? 0 : (type == 'explain' ? 1 : 2);

  /// Parses a question produced by the AI (tolerant to small format errors).
  factory Question.fromAi(Map<String, dynamic> j) {
    final raw = asStr(j['type']).toLowerCase();
    final t = (raw == 'mcq' || raw == 'explain' || raw == 'solve')
        ? raw
        : 'explain';
    final opts = (j['options'] is List)
        ? (j['options'] as List).map((e) => asStr(e)).toList()
        : <String>[];
    var idx = asInt(j['answer_index'] ?? j['answer'], 0);
    if (idx < 0 || idx >= opts.length) idx = 0;
    final isMcq = t == 'mcq' && opts.length >= 2;
    return Question(
      type: isMcq ? 'mcq' : (t == 'mcq' ? 'explain' : t),
      text: asStr(j['q'] ?? j['question']),
      options: isMcq ? opts : const [],
      correct: isMcq ? idx : 0,
      modelAnswer: asStr(j['model_answer'] ?? j['solution']),
      explanation: asStr(j['explanation']),
    );
  }

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        type: asStr(j['type']),
        text: asStr(j['text']),
        options: (j['options'] as List? ?? []).map((e) => asStr(e)).toList(),
        correct: asInt(j['correct']),
        modelAnswer: asStr(j['modelAnswer']),
        explanation: asStr(j['explanation']),
        ref: j['ref'] == null ? null : asStr(j['ref']),
      );

  Map<String, dynamic> toJson() => {
        'type': type,
        'text': text,
        'options': options,
        'correct': correct,
        'modelAnswer': modelAnswer,
        'explanation': explanation,
        'ref': ref,
      };

  Question withRef(String? r) => Question(
        type: type,
        text: text,
        options: options,
        correct: correct,
        modelAnswer: modelAnswer,
        explanation: explanation,
        ref: r,
      );
}

class Quiz {
  Quiz({
    required this.id,
    required this.title,
    required this.questions,
    required this.createdAt,
    this.minutes = 0,
    this.lastPercent,
  });

  final String id;
  final String title;
  final List<Question> questions;
  final DateTime createdAt;
  final int minutes;
  double? lastPercent;

  factory Quiz.fromJson(Map<String, dynamic> j) => Quiz(
        id: asStr(j['id']),
        title: asStr(j['title']),
        questions: (j['questions'] as List? ?? [])
            .map((e) => Question.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        createdAt: DateTime.tryParse(asStr(j['createdAt'])) ?? DateTime.now(),
        minutes: asInt(j['minutes']),
        lastPercent:
            j['lastPercent'] == null ? null : asDouble(j['lastPercent']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'questions': questions.map((e) => e.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'minutes': minutes,
        'lastPercent': lastPercent,
      };
}

class SummaryItem {
  SummaryItem({
    required this.id,
    required this.title,
    required this.body,
    required this.mode,
    this.cards = const [],
    required this.createdAt,
    this.source = '',
  });

  final String id;
  final String title;
  final String body;
  final String mode; // points | short | cards
  final List<Map<String, String>> cards;
  final DateTime createdAt;
  final String source;

  String get plainText {
    if (mode == 'cards') {
      return '$title\n\n${cards.map((c) => '${c['front']}\n${c['back']}').join('\n\n')}';
    }
    return '$title\n\n$body';
  }

  factory SummaryItem.fromJson(Map<String, dynamic> j) => SummaryItem(
        id: asStr(j['id']),
        title: asStr(j['title']),
        body: asStr(j['body']),
        mode: asStr(j['mode']),
        cards: (j['cards'] as List? ?? []).map((e) {
          final m = e as Map;
          return <String, String>{
            'front': asStr(m['front']),
            'back': asStr(m['back']),
          };
        }).toList(),
        createdAt: DateTime.tryParse(asStr(j['createdAt'])) ?? DateTime.now(),
        source: asStr(j['source']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'mode': mode,
        'cards': cards,
        'createdAt': createdAt.toIso8601String(),
        'source': source,
      };
}

class Lesson {
  Lesson({required this.title, this.content = '', this.done = false});
  String title;
  String content;
  bool done;

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
        title: asStr(j['title']),
        content: (j['content'] ?? '').toString(),
        done: j['done'] == true,
      );

  Map<String, dynamic> toJson() =>
      {'title': title, 'content': content, 'done': done};
}

class Module {
  Module({required this.title, required this.lessons});
  String title;
  List<Lesson> lessons;

  factory Module.fromJson(Map<String, dynamic> j) => Module(
        title: asStr(j['title']),
        lessons: (j['lessons'] as List? ?? [])
            .map((e) => Lesson.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'title': title,
        'lessons': lessons.map((e) => e.toJson()).toList(),
      };
}

class Course {
  Course({
    required this.id,
    required this.title,
    this.description = '',
    required this.modules,
    this.sourceText = '',
    required this.createdAt,
  });

  final String id;
  String title;
  String description;
  List<Module> modules;
  final String sourceText;
  final DateTime createdAt;

  int get total => modules.fold<int>(0, (a, m) => a + m.lessons.length);
  int get done => modules.fold<int>(
      0, (a, m) => a + m.lessons.where((l) => l.done).length);
  double get progress => total == 0 ? 0 : done / total;

  factory Course.fromJson(Map<String, dynamic> j) => Course(
        id: asStr(j['id']),
        title: asStr(j['title']),
        description: asStr(j['description']),
        modules: (j['modules'] as List? ?? [])
            .map((e) => Module.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        sourceText: (j['sourceText'] ?? '').toString(),
        createdAt: DateTime.tryParse(asStr(j['createdAt'])) ?? DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'modules': modules.map((e) => e.toJson()).toList(),
        'sourceText': sourceText,
        'createdAt': createdAt.toIso8601String(),
      };
}

class Mistake {
  Mistake({
    required this.id,
    required this.question,
    required this.userAnswer,
    required this.feedback,
    required this.date,
  });

  final String id;
  final Question question;
  final String userAnswer;
  final String feedback;
  final DateTime date;

  factory Mistake.fromJson(Map<String, dynamic> j) => Mistake(
        id: asStr(j['id']),
        question:
            Question.fromJson(Map<String, dynamic>.from(j['question'] as Map)),
        userAnswer: asStr(j['userAnswer']),
        feedback: asStr(j['feedback']),
        date: DateTime.tryParse(asStr(j['date'])) ?? DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'question': question.toJson(),
        'userAnswer': userAnswer,
        'feedback': feedback,
        'date': date.toIso8601String(),
      };
}

class Attempt {
  Attempt({required this.quizTitle, required this.percent, required this.date});
  final String quizTitle;
  final double percent;
  final DateTime date;

  factory Attempt.fromJson(Map<String, dynamic> j) => Attempt(
        quizTitle: asStr(j['quizTitle']),
        percent: asDouble(j['percent']),
        date: DateTime.tryParse(asStr(j['date'])) ?? DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'quizTitle': quizTitle,
        'percent': percent,
        'date': date.toIso8601String(),
      };
}

/// One vocabulary flashcard (word + translation).
/// البطاقات مشتركة مع واجهة ورقة: نفس النموذج ونفس المخزن.
typedef CardItem = Flashcard;

/// Result of parsing a pasted list of "word, translation" lines.
class ParsedCards {
  const ParsedCards(this.pairs, this.invalid);

  /// Each entry is [word, translation].
  final List<List<String>> pairs;

  /// Number of non-empty lines that had no comma or an empty side.
  final int invalid;
}

/// One card per line. The line is split at its FIRST separator (comma,
/// Arabic comma or tab), so the translation itself may contain commas.
ParsedCards parseCardLines(String text) {
  const seps = {',', '\u060C', '\uFF0C', '\t'};
  final pairs = <List<String>>[];
  var invalid = 0;
  for (final raw in text.split(RegExp(r'\r?\n'))) {
    final line = raw.trim();
    if (line.isEmpty) continue;
    var cut = -1;
    for (var i = 0; i < line.length; i++) {
      if (seps.contains(line[i])) {
        cut = i;
        break;
      }
    }
    if (cut <= 0) {
      invalid++;
      continue;
    }
    final f = line.substring(0, cut).trim();
    final b = line.substring(cut + 1).trim();
    if (f.isEmpty || b.isEmpty) {
      invalid++;
      continue;
    }
    pairs.add([f, b]);
  }
  return ParsedCards(pairs, invalid);
}
