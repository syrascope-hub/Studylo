import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/home_shell.dart';
import 'screens/welcome_screen.dart';
import 'state.dart';
import 'theme.dart';

/// The whole Studylo experience (home, explore, quizzes, summaries, courses,
/// cards, focus, progress, settings) hosted inside the main app.
/// It has its own Navigator, theme and language; Android back goes back
/// inside it first and leaves to the main app from its first screen.
class StudyloSection extends StatefulWidget {
  const StudyloSection({super.key});

  @override
  State<StudyloSection> createState() => _StudyloSectionState();
}

class _StudyloSectionState extends State<StudyloSection> {
  final _nav = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final outer = Navigator.of(context);
    return Localizations.override(
      context: context,
      locale: Locale(s.locale),
      child: Theme(
        data: buildTheme(),
        child: PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, _) {
            if (didPop) return;
            final n = _nav.currentState;
            if (n != null && n.canPop()) {
              n.maybePop();
            } else {
              outer.pop();
            }
          },
          child: Navigator(
            key: _nav,
            onGenerateRoute: (_) => MaterialPageRoute<void>(
              builder: (_) =>
                  s.onboarded ? const HomeShell() : const WelcomeScreen(),
            ),
          ),
        ),
      ),
    );
  }
}
