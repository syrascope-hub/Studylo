import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../models.dart';

/// Error with a localisable [code] (see l10n.dart) and optional raw [detail].
class AiException implements Exception {
  AiException(this.code, [this.detail]);
  final String code;
  final String? detail;

  @override
  String toString() => detail == null ? code : '$code: $detail';
}

class KeyTestResult {
  KeyTestResult({
    required this.tokenOk,
    this.user,
    this.tokenError,
    this.modelOk = false,
    this.modelErrCode,
    this.modelErrDetail,
  });
  final bool tokenOk;
  final String? user;
  final String? tokenError;
  final bool modelOk;
  final String? modelErrCode;
  final String? modelErrDetail;
}

/// Pulls the first JSON object/array out of a model reply.
dynamic extractJson(String raw) {
  final s = raw.trim();
  final a = s.indexOf('{');
  final b = s.indexOf('[');
  if (a == -1 && b == -1) throw const FormatException('no json');
  late int start;
  late String close;
  if (b == -1 || (a != -1 && a < b)) {
    start = a;
    close = '}';
  } else {
    start = b;
    close = ']';
  }
  final end = s.lastIndexOf(close);
  if (end <= start) throw const FormatException('bad json');
  return jsonDecode(s.substring(start, end + 1));
}

/// Hugging Face Inference Providers (OpenAI-compatible chat completions).
class AiService {
  AiService({
    required this.apiKey,
    required this.model,
    required this.visionModel,
    required this.lang,
  });

  final String apiKey;
  final String model;
  final String visionModel;
  final String lang;

  static const _chatUrl = 'https://router.huggingface.co/v1/chat/completions';
  static const _whoamiUrl = 'https://huggingface.co/api/whoami-v2';

  String get langName => lang == 'ar' ? 'Arabic' : 'English';

  Map<String, String> get _headers => {
        'Authorization': 'Bearer ${apiKey.trim()}',
        'Content-Type': 'application/json',
      };

  String _clip(String s, int n) => s.length <= n ? s : s.substring(0, n);

  // ------------------------------------------------------------------ core
  Future<String> _chat(
    String modelId,
    List<Map<String, dynamic>> messages, {
    double temperature = 0.4,
    int maxTokens = 3500,
  }) async {
    if (apiKey.trim().isEmpty) throw AiException('no_key');
    http.Response res;
    try {
      res = await http
          .post(
            Uri.parse(_chatUrl),
            headers: _headers,
            body: jsonEncode({
              'model': modelId,
              'messages': messages,
              'max_tokens': maxTokens,
              'temperature': temperature,
              'stream': false,
            }),
          )
          .timeout(const Duration(seconds: 150));
    } on TimeoutException {
      throw AiException('err_timeout');
    } on SocketException {
      throw AiException('err_network');
    } on http.ClientException {
      throw AiException('err_network');
    }
    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode != 200) throw _httpError(res.statusCode, body);
    dynamic data;
    try {
      data = jsonDecode(body);
    } catch (_) {
      throw AiException('err_parse');
    }
    dynamic content;
    if (data is Map) {
      final choices = data['choices'];
      if (choices is List && choices.isNotEmpty) {
        final first = choices[0];
        if (first is Map) {
          final message = first['message'];
          if (message is Map) content = message['content'];
        }
      }
    }
    if (content == null || content.toString().trim().isEmpty) {
      throw AiException('err_empty');
    }
    return content.toString().trim();
  }

  AiException _httpError(int code, String body) {
    var detail = '';
    try {
      final j = jsonDecode(body);
      if (j is Map) {
        final e = j['error'];
        if (e is Map) {
          detail = (e['message'] ?? '').toString();
        } else {
          detail = (e ?? j['message'] ?? '').toString();
        }
      }
    } catch (_) {
      detail = body.length > 200 ? body.substring(0, 200) : body;
    }
    if (detail.length > 240) detail = detail.substring(0, 240);
    if (code == 401) return AiException('err_401', detail);
    if (code == 402) return AiException('err_402', detail);
    if (code == 403) return AiException('err_403', detail);
    if (code == 404 || code == 400 || code == 422) {
      return AiException('err_model', detail);
    }
    if (code == 429) return AiException('err_429', detail);
    return AiException('err_server', '$code $detail');
  }

  Future<String> ask(
    String system,
    String user, {
    double temperature = 0.4,
    int maxTokens = 3500,
  }) =>
      _chat(
        model,
        [
          {'role': 'system', 'content': system},
          {'role': 'user', 'content': user},
        ],
        temperature: temperature,
        maxTokens: maxTokens,
      );

  Future<dynamic> askJson(String system, String user,
      {int maxTokens = 4000}) async {
    final sys =
        '$system\nReturn ONLY valid JSON. No markdown fences and no commentary.';
    for (var attempt = 0; attempt < 2; attempt++) {
      final raw = await ask(sys, user,
          temperature: attempt == 0 ? 0.4 : 0.1, maxTokens: maxTokens);
      try {
        return extractJson(raw);
      } on FormatException {
        if (attempt == 1) throw AiException('err_parse');
      }
    }
    throw AiException('err_parse');
  }

  // ------------------------------------------------------------- key test
  Future<KeyTestResult> testKey() async {
    if (apiKey.trim().isEmpty) throw AiException('no_key');
    String? user;
    try {
      final r = await http
          .get(Uri.parse(_whoamiUrl),
              headers: {'Authorization': 'Bearer ${apiKey.trim()}'})
          .timeout(const Duration(seconds: 25));
      if (r.statusCode != 200) {
        return KeyTestResult(tokenOk: false, tokenError: 'HTTP ${r.statusCode}');
      }
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      user = ((j is Map) ? j['name'] : null)?.toString();
    } on TimeoutException {
      throw AiException('err_timeout');
    } on SocketException {
      throw AiException('err_network');
    } on http.ClientException {
      throw AiException('err_network');
    }
    try {
      await _chat(
        model,
        [
          {'role': 'user', 'content': 'Reply with the single word OK'}
        ],
        temperature: 0,
        maxTokens: 16,
      );
      return KeyTestResult(tokenOk: true, user: user, modelOk: true);
    } on AiException catch (e) {
      return KeyTestResult(
        tokenOk: true,
        user: user,
        modelOk: false,
        modelErrCode: e.code,
        modelErrDetail: e.detail,
      );
    }
  }

  // ----------------------------------------------------------------- quiz
  Future<Quiz> generateQuiz({
    required String source,
    required bool isTopic,
    required int mcq,
    required int explain,
    required int solve,
    required String difficulty,
    int minutes = 0,
  }) async {
    const diffs = {
      'easy': 'easy (recall and basic understanding)',
      'medium': 'medium',
      'hard': 'hard (analysis and multi-step reasoning)',
    };
    final sys =
        'You are an expert teacher who writes exam papers. Write everything in $langName. '
        'Questions must be accurate, unambiguous and self-contained.';
    final user = StringBuffer()
      ..writeln(isTopic
          ? 'Topic: ${_clip(source, 600)}'
          : 'Source material:\n"""\n${_clip(source, 14000)}\n"""')
      ..writeln('Difficulty: ${diffs[difficulty] ?? 'medium'}.')
      ..writeln('Create EXACTLY: $mcq multiple-choice questions (type "mcq", 4 options, exactly one correct), '
          '$explain explanation questions (type "explain": the student must explain or justify in writing), '
          '$solve problem-solving questions (type "solve": the student must write a worked solution; use numbers and steps, '
          'or for non-numeric subjects use a practical case/application problem).')
      ..writeln('JSON schema: {"title": string, "questions": ['
          '{"type":"mcq","q":string,"options":[string,string,string,string],"answer_index":0,"explanation":string},'
          '{"type":"explain","q":string,"model_answer":string},'
          '{"type":"solve","q":string,"model_answer":string}]}')
      ..writeln('Put mcq questions first, then explain, then solve. Do not number the questions. '
          'Do not put letters before the options. answer_index is the 0-based index of the correct option. '
          'For solve questions model_answer must contain the full step-by-step solution and the final answer.');
    final data = await askJson(sys, user.toString(), maxTokens: 6000);

    final map = (data is Map) ? data : {'questions': data};
    final rawList = map['questions'];
    if (rawList is! List) throw AiException('err_parse');
    final parsed = <Question>[];
    for (final e in rawList) {
      if (e is Map) {
        final q = Question.fromAi(Map<String, dynamic>.from(e));
        if (q.text.isNotEmpty) parsed.add(q);
      }
    }
    if (parsed.isEmpty) throw AiException('err_parse');
    final ordered = <Question>[
      ...parsed.where((q) => q.type == 'mcq'),
      ...parsed.where((q) => q.type == 'explain'),
      ...parsed.where((q) => q.type == 'solve'),
    ];
    var title = asStr(map['title']);
    if (title.isEmpty) {
      title = source.trim().replaceAll('\n', ' ');
      title = title.length > 40 ? title.substring(0, 40) : title;
    }
    return Quiz(
      id: newId(),
      title: title,
      questions: ordered,
      createdAt: DateTime.now(),
      minutes: minutes,
    );
  }

  /// Grades open answers. [items]: id, type, q, model_answer, student.
  Future<Map<int, QResult>> gradeOpen(List<Map<String, String>> items) async {
    final sys =
        'You are a strict but fair teacher grading student answers. Write feedback in $langName, '
        'addressed to the student, 1-3 sentences, saying what is wrong or missing. '
        'Accept equivalent wording and alternative valid methods.';
    final user =
        'Grade each answer from 0 to 1 (use 0, 0.25, 0.5, 0.75 or 1). '
        'For "solve" questions give partial credit for a correct method even if the final number is wrong.\n'
        'Items JSON:\n${jsonEncode(items)}\n'
        'Return JSON: {"results":[{"id":string,"score":number,"feedback":string}]}';
    final data = await askJson(sys, user, maxTokens: 3000);
    final list = (data is Map) ? (data['results'] as List? ?? []) : ((data is List) ? data : []);
    final out = <int, QResult>{};
    for (final g in list) {
      if (g is! Map) continue;
      final id = int.tryParse(asStr(g['id']));
      if (id == null) continue;
      final sc = asDouble(g['score']).clamp(0.0, 1.0).toDouble();
      out[id] = QResult(sc, asStr(g['feedback']));
    }
    return out;
  }

  // -------------------------------------------------------------- summary
  Future<String> imagesToText(List<Uint8List> images) async {
    final content = <Map<String, dynamic>>[
      {
        'type': 'text',
        'text':
            'Transcribe ALL the text in these images (handwritten or printed) exactly as written, in reading order. '
                'If there are diagrams or equations, describe them briefly in square brackets. Output only the transcription.',
      },
      for (final b in images)
        {
          'type': 'image_url',
          'image_url': {'url': 'data:image/jpeg;base64,${base64Encode(b)}'},
        },
    ];
    return _chat(
      visionModel,
      [
        {'role': 'user', 'content': content}
      ],
      temperature: 0.1,
      maxTokens: 3000,
    );
  }

  String _cleanLine(String s) => s
      .replaceAll('**', '')
      .replaceFirst(RegExp(r'^#+\s*'), '')
      .replaceFirst(RegExp(r'^(title|العنوان)\s*[:：]\s*', caseSensitive: false), '')
      .trim();

  Future<SummaryItem> summarize(String text, String mode,
      {String fallbackTitle = '', String source = ''}) async {
    final clipped = _clip(text, 16000);
    if (mode == 'cards') {
      final data = await askJson(
        'You create study flashcards. Write in $langName.',
        'Create 8 to 20 flashcards from the material. Each card has a short question or term on the front and a concise answer on the back.\n'
        'JSON: {"title":string,"cards":[{"front":string,"back":string}]}\n'
        'Material:\n"""\n$clipped\n"""',
        maxTokens: 4000,
      );
      final map = (data is Map) ? data : {'cards': data};
      final cards = <Map<String, String>>[];
      final raw = map['cards'];
      if (raw is List) {
        for (final c in raw) {
          if (c is Map) {
            final f = asStr(c['front']);
            final b = asStr(c['back']);
            if (f.isNotEmpty && b.isNotEmpty) cards.add({'front': f, 'back': b});
          }
        }
      }
      if (cards.isEmpty) throw AiException('err_parse');
      var title = asStr(map['title']);
      if (title.isEmpty) title = fallbackTitle;
      return SummaryItem(
        id: newId(),
        title: title.isEmpty ? 'Flashcards' : title,
        body: '',
        mode: 'cards',
        cards: cards,
        createdAt: DateTime.now(),
        source: source,
      );
    }
    final style = mode == 'short'
        ? 'a short summary: one or two short paragraphs, at most 150 words'
        : 'a structured summary: short headings that end with a colon, each followed by bullet points starting with "•"; '
            'cover all key ideas, definitions, formulas and dates; be complete but concise';
    final raw = await ask(
      'You are an expert at summarizing study material. Write in $langName. '
      'Use plain text only: no markdown symbols (no ** and no #).',
      'Summarize the material below as $style.\n'
      'The FIRST line must be a short title (at most 8 words, no ending punctuation). Then a blank line, then the summary.\n'
      'Material:\n"""\n$clipped\n"""',
      maxTokens: 2500,
    );
    final lines = raw.split('\n');
    var title = _cleanLine(lines.first);
    var body = lines.skip(1).join('\n').trim();
    if (body.isEmpty) {
      body = raw;
      title = fallbackTitle;
    }
    if (title.isEmpty) title = fallbackTitle.isEmpty ? 'Summary' : fallbackTitle;
    return SummaryItem(
      id: newId(),
      title: title,
      body: body,
      mode: mode,
      createdAt: DateTime.now(),
      source: source,
    );
  }

  // --------------------------------------------------------------- course
  Future<Course> generateCourse({
    required String topic,
    String source = '',
    required String level,
  }) async {
    const levels = {
      'beginner': 'beginner',
      'intermediate': 'intermediate',
      'advanced': 'advanced',
    };
    final sys =
        'You are an expert curriculum designer. Write in $langName.';
    final user = StringBuffer()
      ..writeln(source.trim().isEmpty
          ? 'Design a course about: ${_clip(topic, 400)}'
          : 'Design a course based on this material${topic.trim().isEmpty ? '' : ' (focus: ${_clip(topic, 200)})'}:\n"""\n${_clip(source, 12000)}\n"""')
      ..writeln('Level: ${levels[level] ?? 'beginner'}.')
      ..writeln('Create 3 to 5 modules, each with 2 to 4 lessons, in a logical learning order.')
      ..writeln('JSON: {"title":string,"description":string,"modules":[{"title":string,"lessons":[{"title":string}]}]}');
    final data = await askJson(sys, user.toString(), maxTokens: 3000);
    if (data is! Map) throw AiException('err_parse');
    final modules = <Module>[];
    final rawModules = data['modules'];
    if (rawModules is List) {
      for (final m in rawModules) {
        if (m is! Map) continue;
        final lessons = <Lesson>[];
        final rawLessons = m['lessons'];
        if (rawLessons is List) {
          for (final l in rawLessons) {
            final t = (l is Map) ? asStr(l['title']) : asStr(l);
            if (t.isNotEmpty) lessons.add(Lesson(title: t));
          }
        }
        final mt = asStr(m['title']);
        if (mt.isNotEmpty && lessons.isNotEmpty) {
          modules.add(Module(title: mt, lessons: lessons));
        }
      }
    }
    if (modules.isEmpty) throw AiException('err_parse');
    var title = asStr(data['title']);
    if (title.isEmpty) title = _clip(topic.trim(), 40);
    return Course(
      id: newId(),
      title: title.isEmpty ? 'Course' : title,
      description: asStr(data['description']),
      modules: modules,
      sourceText: _clip(source, 9000),
      createdAt: DateTime.now(),
    );
  }

  Future<String> generateLesson({
    required Course course,
    required Module module,
    required Lesson lesson,
  }) {
    final ctx = course.sourceText.isEmpty
        ? ''
        : '\nReference material (base the lesson on it):\n"""\n${_clip(course.sourceText, 7000)}\n"""';
    return ask(
      'You are an excellent teacher. Write in $langName. Plain text only: no markdown symbols (no ** and no #). '
      'Use short headings that end with a colon and bullets that start with "•".',
      'Course: ${course.title}\nModule: ${module.title}\nLesson: ${lesson.title}\n'
      'Write a clear, engaging lesson of 300-500 words: an explanation, one or two worked examples, and a final section of key takeaways.$ctx',
      maxTokens: 2500,
    );
  }
}
