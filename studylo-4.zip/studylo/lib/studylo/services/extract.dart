import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

import 'ai_service.dart' show AiException;

/// Helpers that get raw text/bytes out of PDFs, photos and YouTube videos.
class Extractor {
  /// Lets the user choose a PDF. Returns (file name, bytes) or null.
  static Future<(String, Uint8List)?> pickPdfBytes() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
      withData: true,
    );
    if (r == null || r.files.isEmpty) return null;
    final f = r.files.first;
    Uint8List? bytes = f.bytes;
    if (bytes == null && f.path != null) {
      bytes = await File(f.path!).readAsBytes();
    }
    if (bytes == null) return null;
    return (f.name, bytes);
  }

  static Future<String> pdfToText(Uint8List bytes) async {
    final doc = PdfDocument(inputBytes: bytes);
    try {
      return PdfTextExtractor(doc).extractText().trim();
    } finally {
      doc.dispose();
    }
  }

  /// Camera shot or gallery pick (gallery allows several images).
  static Future<List<Uint8List>> pickImages({required bool camera}) async {
    final picker = ImagePicker();
    if (camera) {
      final x = await picker.pickImage(
          source: ImageSource.camera, imageQuality: 70, maxWidth: 1600);
      return x == null ? [] : [await x.readAsBytes()];
    }
    final xs = await picker.pickMultiImage(imageQuality: 70, maxWidth: 1600);
    final out = <Uint8List>[];
    for (final x in xs.take(6)) {
      out.add(await x.readAsBytes());
    }
    return out;
  }

  /// Downloads the caption track of a YouTube video. Returns (title, text).
  static Future<(String, String)> youtube(String url, String lang) async {
    final yt = YoutubeExplode();
    try {
      final VideoId id;
      try {
        id = VideoId(url.trim());
      } catch (_) {
        throw AiException('err_bad_url');
      }
      final video = await yt.videos.get(id);
      final manifest = await yt.videos.closedCaptions.getManifest(id);
      if (manifest.tracks.isEmpty) throw AiException('err_no_captions');
      var pick = manifest.tracks.first;
      outer:
      for (final code in [lang, 'en', 'ar']) {
        for (final t in manifest.tracks) {
          if (t.language.code.toLowerCase().startsWith(code)) {
            pick = t;
            break outer;
          }
        }
      }
      final track = await yt.videos.closedCaptions.get(pick);
      final text = track.captions
          .map((c) => c.text.trim())
          .where((t) => t.isNotEmpty)
          .join(' ');
      return (video.title, text);
    } on AiException {
      rethrow;
    } catch (e) {
      throw AiException('err_yt', e.toString());
    } finally {
      yt.close();
    }
  }
}
