import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import 'theme.dart';

/// Small flat "spot illustration" built from shapes (no image assets needed):
/// a soft circle, a black accent blob, a ring and a tilted black tile with an icon.
class Illus extends StatelessWidget {
  const Illus({
    super.key,
    required this.icon,
    this.size = 90,
    this.seed = 0,
    this.bg,
  });

  final IconData icon;
  final double size;
  final int seed;
  final Color? bg;

  @override
  Widget build(BuildContext context) {
    final flip = seed.isEven ? -1.0 : 1.0;
    final tile = size * 0.5;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: size * 0.88,
            height: size * 0.88,
            decoration: BoxDecoration(
                color: bg ?? C.creamDark, shape: BoxShape.circle),
          ),
          Positioned(
            top: size * 0.06,
            right: flip < 0 ? size * 0.06 : null,
            left: flip > 0 ? size * 0.06 : null,
            child: Container(
              width: size * 0.2,
              height: size * 0.2,
              decoration:
                  const BoxDecoration(color: C.ink, shape: BoxShape.circle),
            ),
          ),
          Positioned(
            bottom: size * 0.12,
            left: flip < 0 ? size * 0.04 : null,
            right: flip > 0 ? size * 0.04 : null,
            child: Container(
              width: size * 0.15,
              height: size * 0.15,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: C.ink, width: 2),
              ),
            ),
          ),
          Transform.rotate(
            angle: flip * 0.1,
            child: Container(
              width: tile,
              height: tile,
              decoration: BoxDecoration(
                color: C.ink,
                borderRadius: BorderRadius.circular(tile * 0.3),
              ),
              child: Icon(icon, color: C.cream, size: tile * 0.58),
            ),
          ),
          Positioned(
            bottom: size * 0.05,
            child: Container(
              width: size * 0.36,
              height: 4,
              decoration: BoxDecoration(
                  color: C.ink.withAlpha(40),
                  borderRadius: BorderRadius.circular(4)),
            ),
          ),
        ],
      ),
    )
        .animate(
          delay: (seed * 220).ms,
          onPlay: (c) => c.repeat(reverse: true),
        )
        .moveY(begin: -3, end: 3, duration: 1900.ms, curve: Curves.easeInOut);
  }
}


/// Ready-made illustration from assets/illus (transparent PNG).
/// Names: start, plan, subjects, tasks, smart, goals, focus, progress,
/// quizzes, sync, night, learn, notes, lessons, alerts, achieve, modern.
class IllusImg extends StatelessWidget {
  const IllusImg(this.name, {super.key, this.size = 120, this.float = false});

  final String name;
  final double size;

  /// Gentle up/down floating animation.
  final bool float;

  @override
  Widget build(BuildContext context) {
    final img = Image.asset(
      'assets/illus/$name.png',
      width: size,
      height: size,
      fit: BoxFit.contain,
      filterQuality: FilterQuality.medium,
      errorBuilder: (_, __, ___) => SizedBox(width: size, height: size),
    );
    if (!float) return img;
    return img
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .moveY(begin: -4, end: 4, duration: 1800.ms, curve: Curves.easeInOut);
  }
}
