import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../services/sfx.dart';
import 'models.dart';
import 'pomodoro_models.dart';
import 'state.dart';

/// Runtime Pomodoro engine. Time is computed from [_endAt] (a wall-clock
/// timestamp), so the timer stays correct if the app goes to the background.
class PomodoroController extends ChangeNotifier with WidgetsBindingObserver {
  PomodoroController(this.app) {
    WidgetsBinding.instance.addObserver(this);
    _resetPhase();
  }

  final AppState app;

  PomoPhase phase = PomoPhase.focus;
  bool running = false;

  /// Focus sessions finished since the last long break.
  int doneInCycle = 0;

  /// Set when a phase ends; the UI shows a dialog once, then clears it.
  PomoPhase? finishedPhase;

  late Duration _remaining;
  late Duration _phaseTotal;
  DateTime? _endAt;
  Timer? _ticker;

  // ------------------------------------------------------------------ info
  int get phaseMinutes {
    switch (phase) {
      case PomoPhase.focus:
        return app.focusMin;
      case PomoPhase.shortBreak:
        return app.shortBreakMin;
      case PomoPhase.longBreak:
        return app.longBreakMin;
    }
  }

  /// Length of the current phase, fixed when the phase starts.
  Duration get total => _phaseTotal;

  Duration get remaining {
    if (running && _endAt != null) {
      final d = _endAt!.difference(DateTime.now());
      return d.isNegative ? Duration.zero : d;
    }
    return _remaining;
  }

  /// 0..1 of the current phase that has elapsed.
  double get progress {
    final t = total.inMilliseconds;
    if (t <= 0) return 0;
    return (1 - remaining.inMilliseconds / t).clamp(0.0, 1.0).toDouble();
  }

  /// Whole minutes studied so far in the current focus phase.
  int get elapsedMinutes =>
      ((total - remaining).inSeconds / 60).floor().clamp(0, 600);

  bool get started => remaining < total;

  // --------------------------------------------------------------- actions
  void start() {
    if (running) return;
    if (_remaining <= Duration.zero) _remaining = total;
    _endAt = DateTime.now().add(_remaining);
    running = true;
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(milliseconds: 250), (_) => _tick());
    _wake(phase == PomoPhase.focus);
    notifyListeners();
  }

  void pause() {
    if (!running) return;
    _remaining = remaining;
    running = false;
    _endAt = null;
    _ticker?.cancel();
    _wake(false);
    notifyListeners();
  }

  void toggle() => running ? pause() : start();

  /// Back to the beginning of the current phase (no plant recorded).
  void reset() {
    _stopTimer();
    _resetPhase();
    notifyListeners();
  }

  /// Abandon a focus session: the plant withers and is kept in the garden.
  void giveUp() {
    if (phase != PomoPhase.focus) {
      reset();
      return;
    }
    final prog = progress;
    final mins = elapsedMinutes;
    _stopTimer();
    if (mins >= 1) {
      app.addGardenPlant(GardenPlant(
        id: newId(),
        kind: app.plantKind,
        minutes: mins,
        date: DateTime.now(),
        withered: true,
        progress: prog,
      ));
    }
    _resetPhase();
    notifyListeners();
  }

  void skipBreak() {
    if (phase == PomoPhase.focus) return;
    _stopTimer();
    _goto(PomoPhase.focus);
  }

  void selectPhase(PomoPhase p) {
    if (p == phase) return;
    _stopTimer();
    _goto(p);
  }

  /// Call after the user changed durations in settings.
  void settingsChanged() {
    if (!running && !started) _resetPhase();
    notifyListeners();
  }

  void clearFinished() {
    finishedPhase = null;
  }

  // ------------------------------------------------------------- internals
  void _resetPhase() {
    _phaseTotal = Duration(minutes: phaseMinutes);
    _remaining = _phaseTotal;
  }

  void _goto(PomoPhase p) {
    phase = p;
    _resetPhase();
    notifyListeners();
  }

  void _stopTimer() {
    running = false;
    _endAt = null;
    _ticker?.cancel();
    _wake(false);
  }

  void _tick() {
    if (!running) return;
    if (remaining <= Duration.zero) {
      _complete();
    } else {
      notifyListeners();
    }
  }

  void _complete() {
    final done = phase;
    _stopTimer();
    if (done == PomoPhase.focus) {
      app.addGardenPlant(GardenPlant(
        id: newId(),
        kind: app.plantKind,
        minutes: _phaseTotal.inMinutes,
        date: DateTime.now(),
        withered: false,
        progress: 1,
      ));
      doneInCycle++;
      final long = doneInCycle >= app.cyclesBeforeLong;
      if (long) doneInCycle = 0;
      phase = long ? PomoPhase.longBreak : PomoPhase.shortBreak;
    } else {
      phase = PomoPhase.focus;
    }
    _resetPhase();
    Sfx.play(done == PomoPhase.focus ? 'done' : 'start');
    finishedPhase = done;
    notifyListeners();
  }

  void _wake(bool on) {
    try {
      if (on) {
        WakelockPlus.enable();
      } else {
        WakelockPlus.disable();
      }
    } catch (_) {}
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _tick();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    _wake(false);
    super.dispose();
  }
}
