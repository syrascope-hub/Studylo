import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../card_store.dart';
import 'l10n.dart';
import 'models.dart';
import 'pomodoro_models.dart';
import 'services/ai_service.dart';

class AppState extends ChangeNotifier {
  static const defaultModel = 'Qwen/Qwen2.5-72B-Instruct';
  static const defaultVision = 'Qwen/Qwen2.5-VL-72B-Instruct';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  late _Prefs _p;

  String locale = 'ar';
  bool onboarded = false;
  String apiKey = '';
  String model = defaultModel;
  String visionModel = defaultVision;
  String userName = '';

  List<Quiz> quizzes = [];
  List<SummaryItem> summaries = [];
  List<Course> courses = [];
  List<Mistake> mistakes = [];
  List<Attempt> attempts = [];
  List<CardItem> get cards => CardStore.instance.cards;
  List<String> days = [];

  // ---- focus / pomodoro (settings + garden)
  int focusMin = 25;
  int shortBreakMin = 5;
  int longBreakMin = 15;
  int cyclesBeforeLong = 4;
  String plantKind = 'flower';
  int dailyGoalMin = 60;
  List<GardenPlant> garden = [];
  Map<String, int> focusLog = {};

  AppState() {
    CardStore.instance.addListener(notifyListeners);
  }

  String t(String key) => tr(locale, key);

  bool get hasKey => apiKey.trim().isNotEmpty;

  AiService get ai => AiService(
        apiKey: apiKey,
        model: model.trim().isEmpty ? defaultModel : model.trim(),
        visionModel:
            visionModel.trim().isEmpty ? defaultVision : visionModel.trim(),
        lang: locale,
      );

  // ---------------------------------------------------------------- load
  Future<void> load() async {
    await CardStore.instance.load();
    _p = _Prefs(await SharedPreferences.getInstance());
    locale = _p.getString('locale') ?? 'ar';
    onboarded = _p.getBool('onboarded') ?? false;
    userName = _p.getString('name') ?? '';
    model = _p.getString('model') ?? defaultModel;
    visionModel = _p.getString('visionModel') ?? defaultVision;
    try {
      apiKey = await _secure.read(key: 'hf_key') ?? '';
    } catch (_) {
      apiKey = '';
    }
    quizzes = _loadList('quizzes', Quiz.fromJson);
    summaries = _loadList('summaries', SummaryItem.fromJson);
    courses = _loadList('courses', Course.fromJson);
    mistakes = _loadList('mistakes', Mistake.fromJson);
    attempts = _loadList('attempts', Attempt.fromJson);
    days = _p.getStringList('days') ?? [];
    focusMin = _p.getInt('focusMin') ?? 25;
    shortBreakMin = _p.getInt('shortBreakMin') ?? 5;
    longBreakMin = _p.getInt('longBreakMin') ?? 15;
    cyclesBeforeLong = _p.getInt('cyclesBeforeLong') ?? 4;
    plantKind = _p.getString('plantKind') ?? 'flower';
    dailyGoalMin = _p.getInt('dailyGoalMin') ?? 60;
    garden = _loadList('garden', GardenPlant.fromJson);
    try {
      final raw = _p.getString('focusLog');
      focusLog = raw == null
          ? {}
          : (jsonDecode(raw) as Map)
              .map((k, v) => MapEntry(k.toString(), asInt(v)));
    } catch (_) {
      focusLog = {};
    }
  }

  List<T> _loadList<T>(String key, T Function(Map<String, dynamic>) f) {
    final raw = _p.getString(key);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => f(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  void _save(String key, Iterable<Map<String, dynamic>> items) {
    _p.setString(key, jsonEncode(items.toList()));
  }

  // ------------------------------------------------------------ settings
  void setLocale(String l) {
    locale = l;
    _p.setString('locale', l);
    notifyListeners();
  }

  void setName(String n) {
    userName = n.trim();
    _p.setString('name', userName);
    notifyListeners();
  }

  void finishOnboarding() {
    onboarded = true;
    _p.setBool('onboarded', true);
    notifyListeners();
  }

  Future<void> saveKey(String key) async {
    apiKey = key.trim();
    try {
      if (apiKey.isEmpty) {
        await _secure.delete(key: 'hf_key');
      } else {
        await _secure.write(key: 'hf_key', value: apiKey);
      }
    } catch (_) {}
    notifyListeners();
  }

  void saveModels(String m, String v) {
    model = m.trim().isEmpty ? defaultModel : m.trim();
    visionModel = v.trim().isEmpty ? defaultVision : v.trim();
    _p.setString('model', model);
    _p.setString('visionModel', visionModel);
    notifyListeners();
  }

  // ---------------------------------------------------------------- quizzes
  void addQuiz(Quiz q) {
    quizzes.insert(0, q);
    persistQuizzes();
  }

  void deleteQuiz(Quiz q) {
    quizzes.removeWhere((e) => e.id == q.id);
    persistQuizzes();
  }

  void persistQuizzes() {
    _save('quizzes', quizzes.map((e) => e.toJson()));
    notifyListeners();
  }

  // -------------------------------------------------------------- summaries
  void addSummary(SummaryItem s) {
    summaries.insert(0, s);
    _save('summaries', summaries.map((e) => e.toJson()));
    markActive();
  }

  void deleteSummary(SummaryItem s) {
    summaries.removeWhere((e) => e.id == s.id);
    _save('summaries', summaries.map((e) => e.toJson()));
    notifyListeners();
  }

  // ------------------------------------------------------------------ cards
  /// Adds [word, translation] pairs, skipping words that already exist.
  /// Returns how many cards were really added.
  int addCards(List<List<String>> pairs) {
    final seen = cards.map((c) => c.front.trim().toLowerCase()).toSet();
    final fresh = <CardItem>[];
    for (final p in pairs) {
      final f = p[0].trim();
      final b = p[1].trim();
      final k = f.toLowerCase();
      if (f.isEmpty || b.isEmpty || seen.contains(k)) continue;
      seen.add(k);
      fresh.add(CardItem(id: newId(), front: f, back: b));
    }
    if (fresh.isEmpty) return 0;
    cards.insertAll(0, fresh);
    CardStore.instance.save();
    markActive();
    return fresh.length;
  }

  void updateCard(CardItem c, String front, String back) {
    c.front = front.trim();
    c.back = back.trim();
    persistCards();
  }

  void toggleLearned(CardItem c) {
    c.learned = !c.learned;
    persistCards();
  }

  void deleteCard(CardItem c) {
    cards.removeWhere((e) => e.id == c.id);
    persistCards();
  }

  void persistCards() {
    CardStore.instance.save();
    notifyListeners();
  }

  // ---------------------------------------------------------------- courses
  void addCourse(Course c) {
    courses.insert(0, c);
    persistCourses();
  }

  void deleteCourse(Course c) {
    courses.removeWhere((e) => e.id == c.id);
    persistCourses();
  }

  void persistCourses() {
    _save('courses', courses.map((e) => e.toJson()));
    notifyListeners();
  }

  // --------------------------------------------------------------- mistakes
  void addMistake(Mistake m) {
    final exists = mistakes.any((e) => e.question.text == m.question.text);
    if (exists) return;
    mistakes.insert(0, m.question.ref == null
        ? m
        : Mistake(
            id: m.id,
            question: m.question.withRef(null),
            userAnswer: m.userAnswer,
            feedback: m.feedback,
            date: m.date));
    _save('mistakes', mistakes.map((e) => e.toJson()));
    notifyListeners();
  }

  void removeMistake(String id) {
    mistakes.removeWhere((e) => e.id == id);
    _save('mistakes', mistakes.map((e) => e.toJson()));
    notifyListeners();
  }

  // --------------------------------------------------------------- progress
  void addAttempt(Attempt a) {
    attempts.add(a);
    if (attempts.length > 200) attempts.removeAt(0);
    _save('attempts', attempts.map((e) => e.toJson()));
    markActive();
  }

  static String _day(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void markActive() {
    final today = _day(DateTime.now());
    if (!days.contains(today)) {
      days.add(today);
      if (days.length > 400) days.removeAt(0);
      _p.setStringList('days', days);
    }
    notifyListeners();
  }

  int get streak {
    if (days.isEmpty) return 0;
    final set = days.toSet();
    var d = DateTime.now();
    if (!set.contains(_day(d))) d = d.subtract(const Duration(days: 1));
    var n = 0;
    while (set.contains(_day(d))) {
      n++;
      d = d.subtract(const Duration(days: 1));
    }
    return n;
  }

  double get avgPercent {
    if (attempts.isEmpty) return 0;
    return attempts.fold<double>(0, (a, e) => a + e.percent) / attempts.length;
  }

  // ------------------------------------------------------------------ focus
  static String dayKey(DateTime d) => _day(d);

  void saveFocusSettings({
    int? focus,
    int? short,
    int? long,
    int? cycles,
    String? plant,
    int? goal,
  }) {
    if (focus != null) focusMin = focus;
    if (short != null) shortBreakMin = short;
    if (long != null) longBreakMin = long;
    if (cycles != null) cyclesBeforeLong = cycles;
    if (plant != null) plantKind = plant;
    if (goal != null) dailyGoalMin = goal;
    _p.setInt('focusMin', focusMin);
    _p.setInt('shortBreakMin', shortBreakMin);
    _p.setInt('longBreakMin', longBreakMin);
    _p.setInt('cyclesBeforeLong', cyclesBeforeLong);
    _p.setString('plantKind', plantKind);
    _p.setInt('dailyGoalMin', dailyGoalMin);
    notifyListeners();
  }

  /// Called when a focus session ends (grown = completed, otherwise withered).
  void addGardenPlant(GardenPlant g) {
    garden.insert(0, g);
    if (garden.length > 300) garden.removeLast();
    _save('garden', garden.map((e) => e.toJson()));
    if (g.minutes > 0) {
      final k = _day(g.date);
      focusLog[k] = (focusLog[k] ?? 0) + g.minutes;
      if (focusLog.length > 120) {
        final keys = focusLog.keys.toList()..sort();
        focusLog.remove(keys.first);
      }
      _p.setString('focusLog', jsonEncode(focusLog));
    }
    if (!g.withered) {
      markActive();
    } else {
      notifyListeners();
    }
  }

  int get focusToday => focusLog[_day(DateTime.now())] ?? 0;

  int get focusTotal => focusLog.values.fold<int>(0, (a, b) => a + b);

  int get grownCount => garden.where((g) => !g.withered).length;

  /// Minutes for the last 7 days (oldest first).
  List<int> focusWeek() {
    final now = DateTime.now();
    return [
      for (var i = 6; i >= 0; i--)
        focusLog[_day(now.subtract(Duration(days: i)))] ?? 0
    ];
  }

  Future<void> clearAll() async {
    quizzes = [];
    summaries = [];
    courses = [];
    mistakes = [];
    attempts = [];
    days = [];
    garden = [];
    focusLog = {};
    await _p.remove('garden');
    await _p.remove('focusLog');
    for (final k in ['quizzes', 'summaries', 'courses', 'mistakes', 'attempts']) {
      await _p.remove(k);
    }
    await _p.remove('days');
    notifyListeners();
  }
}


/// SharedPreferences wrapper that prefixes every key with `sl_`, so the
/// Studylo section never collides with the keys used by the cards/words side
/// of the app (both used names like `cards`).
class _Prefs {
  _Prefs(this._s);
  final SharedPreferences _s;
  static const _pre = 'sl_';

  String? getString(String k) => _s.getString(_pre + k);
  bool? getBool(String k) => _s.getBool(_pre + k);
  int? getInt(String k) => _s.getInt(_pre + k);
  List<String>? getStringList(String k) => _s.getStringList(_pre + k);

  Future<bool> setString(String k, String v) => _s.setString(_pre + k, v);
  Future<bool> setBool(String k, bool v) => _s.setBool(_pre + k, v);
  Future<bool> setInt(String k, int v) => _s.setInt(_pre + k, v);
  Future<bool> setStringList(String k, List<String> v) =>
      _s.setStringList(_pre + k, v);
  Future<bool> remove(String k) => _s.remove(_pre + k);
}
