import 'models.dart';

enum PomoPhase { focus, shortBreak, longBreak }

/// One plant in the user's garden: grown (session finished) or withered
/// (session abandoned).
class GardenPlant {
  GardenPlant({
    required this.id,
    required this.kind,
    required this.minutes,
    required this.date,
    this.withered = false,
    this.progress = 1,
  });

  final String id;
  final String kind; // flower | tree | cactus
  final int minutes;
  final DateTime date;
  final bool withered;

  /// How far the plant had grown (0..1) when the session ended.
  final double progress;

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind,
        'minutes': minutes,
        'date': date.millisecondsSinceEpoch,
        'withered': withered,
        'progress': progress,
      };

  factory GardenPlant.fromJson(Map<String, dynamic> j) => GardenPlant(
        id: asStr(j['id']),
        kind: asStr(j['kind']).isEmpty ? 'flower' : asStr(j['kind']),
        minutes: asInt(j['minutes']),
        date: DateTime.fromMillisecondsSinceEpoch(asInt(j['date'])),
        withered: j['withered'] == true,
        progress: asDouble(j['progress'], 1).clamp(0.0, 1.0).toDouble(),
      );
}
