import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../illus.dart';
import '../plant.dart';
import '../pomodoro.dart';
import '../pomodoro_models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';

/// Pomodoro tab: a plant grows while you focus.
class FocusScreen extends StatefulWidget {
  const FocusScreen({super.key});

  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> {
  late final PomodoroController _pomo;
  bool _dialogOpen = false;

  @override
  void initState() {
    super.initState();
    _pomo = context.read<PomodoroController>();
    _pomo.addListener(_onPomo);
  }

  @override
  void dispose() {
    _pomo.removeListener(_onPomo);
    super.dispose();
  }

  void _onPomo() {
    final done = _pomo.finishedPhase;
    if (done == null || _dialogOpen || !mounted) return;
    _pomo.clearFinished();
    _dialogOpen = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) {
        _dialogOpen = false;
        return;
      }
      await _showDone(done);
      _dialogOpen = false;
    });
  }

  Future<void> _showDone(PomoPhase done) async {
    final focusDone = done == PomoPhase.focus;
    final go = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        contentPadding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IllusImg(focusDone ? 'achieve' : 'goals', size: 120, float: true),
            const SizedBox(height: 10),
            Text(ctx.tr(focusDone ? 'f_done_title' : 'f_break_done_title'),
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(ctx.tr(focusDone ? 'f_done_body' : 'f_break_done_body'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: C.grey, height: 1.5)),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: Text(ctx.trr('close'))),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: Text(
                          ctx.trr(focusDone ? 'f_start_break' : 'f_start'),
                          textAlign: TextAlign.center)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    if (go == true) _pomo.start();
  }

  void _openSettings() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: C.paper,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => const _SettingsSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(context.tr('focus_title'),
                          style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              height: 1.2)),
                      Text(context.tr('focus_sub'),
                          style:
                              const TextStyle(color: C.grey, fontSize: 13.5)),
                    ],
                  ),
                ),
                Material(
                  color: C.paper,
                  shape: const CircleBorder(side: BorderSide(color: C.line)),
                  child: IconButton(
                    onPressed: _openSettings,
                    icon: const Icon(Icons.tune_rounded),
                  ),
                ),
              ],
            ),
          ).animate().fadeIn(duration: 350.ms).slideY(begin: -0.15, end: 0),
          const _TimerSection(),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                  child: _StatTile(
                      icon: Icons.timer_rounded,
                      value: '${s.focusToday}',
                      unit: context.tr('f_min_short'),
                      label: context.tr('f_today'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _StatTile(
                      icon: Icons.eco_rounded,
                      value: '${s.grownCount}',
                      label: context.tr('f_plants'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _StatTile(
                      icon: Icons.hourglass_bottom_rounded,
                      value: '${s.focusTotal}',
                      unit: context.tr('f_min_short'),
                      label: context.tr('f_total'))),
            ],
          ),
          const SizedBox(height: 12),
          const _GoalCard(),
          const SizedBox(height: 12),
          const _WeekCard(),
          const SizedBox(height: 22),
          SectionTitle(context.tr('f_garden')),
          const _Garden(),
        ],
      ),
    );
  }
}

// =================================================================== timer
class _TimerSection extends StatelessWidget {
  const _TimerSection();

  static int _stage(double p) {
    if (p < 0.12) return 0;
    if (p < 0.38) return 1;
    if (p < 0.7) return 2;
    if (p < 0.97) return 3;
    return 4;
  }

  @override
  Widget build(BuildContext context) {
    final pomo = context.watch<PomodoroController>();
    final s = context.watch<AppState>();
    final isFocus = pomo.phase == PomoPhase.focus;
    final p = isFocus ? pomo.progress : 1.0;

    final secs = (pomo.remaining.inMilliseconds / 1000).ceil();
    String two(int n) => n.toString().padLeft(2, '0');
    final clock = '${two(secs ~/ 60)}:${two(secs % 60)}';

    final chipText = isFocus
        ? context.tr('stage_${_stage(p)}')
        : context.tr(pomo.phase == PomoPhase.shortBreak ? 'ph_short' : 'ph_long');

    final hint = isFocus
        ? (pomo.running
            ? context.tr('f_focus_hint')
            : '${pomo.phaseMinutes} ${context.tr('min')}')
        : context.tr('f_break_hint');

    final btnLabel = pomo.running
        ? context.tr('f_pause')
        : (pomo.started
            ? context.tr('f_resume')
            : context.tr(isFocus ? 'f_start' : 'f_start_break'));

    return Column(
      children: [
        Seg<PomoPhase>(
          items: {
            PomoPhase.focus: context.tr('ph_focus'),
            PomoPhase.shortBreak: context.tr('ph_short'),
            PomoPhase.longBreak: context.tr('ph_long'),
          },
          value: pomo.phase,
          onChanged: (v) {
            if (pomo.running) return;
            pomo.selectPhase(v);
          },
        ),
        const SizedBox(height: 14),
        Container(
          height: 330,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: isFocus
                  ? const [Color(0xFFDCE5FF), Color(0xFFF0F4FF), Color(0xFFE3F5EA)]
                  : const [Color(0xFFFFE6D2), Color(0xFFFFF5EA), Color(0xFFE6F5EA)],
            ),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: C.line),
            boxShadow: [
              BoxShadow(
                  color: C.accent.withAlpha(30),
                  blurRadius: 26,
                  offset: const Offset(0, 10)),
            ],
          ),
          child: Stack(
            children: [
              // soft sun
              PositionedDirectional(
                top: -30,
                end: -30,
                child: Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(colors: [
                      const Color(0xFFFFE08A).withAlpha(190),
                      const Color(0xFFFFE08A).withAlpha(0),
                    ]),
                  ),
                ),
              ),
              Positioned.fill(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 40, 16, 8),
                  child: PlantView(kind: s.plantKind, progress: p),
                ),
              ),
              PositionedDirectional(
                top: 14,
                start: 14,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(215),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(isFocus ? Icons.eco_rounded : Icons.coffee_rounded,
                          size: 16, color: isFocus ? C.leaf : C.warn),
                      const SizedBox(width: 6),
                      Text(chipText,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 12.5)),
                    ],
                  ),
                ),
              ),
              PositionedDirectional(
                bottom: 14,
                end: 16,
                child: Row(
                  children: [
                    for (var i = 0; i < s.cyclesBeforeLong; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        width: 9,
                        height: 9,
                        margin: const EdgeInsets.symmetric(horizontal: 2.5),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < pomo.doneInCycle
                              ? C.leaf
                              : C.ink.withAlpha(40),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ).animate().fadeIn(duration: 450.ms).scale(
            begin: const Offset(0.97, 0.97),
            end: const Offset(1, 1),
            duration: 450.ms,
            curve: Curves.easeOut),
        const SizedBox(height: 16),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Text(
            clock,
            style: const TextStyle(
              fontSize: 66,
              fontWeight: FontWeight.w900,
              height: 1.05,
              letterSpacing: 1,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ),
        const SizedBox(height: 2),
        Text(hint, style: const TextStyle(color: C.grey, fontSize: 14)),
        const SizedBox(height: 16),
        Row(
          children: [
            _CircleBtn(
              icon: Icons.stop_rounded,
              enabled: pomo.started,
              onTap: () async {
                if (isFocus && pomo.started) {
                  final ok = await confirm(
                      context, context.trr('f_giveup_confirm'),
                      yes: context.trr('f_giveup_yes'));
                  if (ok) pomo.giveUp();
                } else {
                  pomo.reset();
                }
              },
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: pomo.toggle,
                icon: Icon(
                    pomo.running
                        ? Icons.pause_rounded
                        : Icons.play_arrow_rounded,
                    size: 26),
                label: Text(btnLabel),
              ),
            ),
            const SizedBox(width: 12),
            _CircleBtn(
              icon: Icons.skip_next_rounded,
              enabled: !isFocus,
              onTap: pomo.skipBreak,
            ),
          ],
        ),
      ],
    );
  }
}

class _CircleBtn extends StatelessWidget {
  const _CircleBtn(
      {required this.icon, required this.enabled, required this.onTap});
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: C.paper,
      shape: CircleBorder(side: BorderSide(color: enabled ? C.ink : C.line, width: 1.4)),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: enabled ? onTap : null,
        child: SizedBox(
          width: 56,
          height: 56,
          child: Icon(icon, color: enabled ? C.ink : C.grey.withAlpha(110)),
        ),
      ),
    );
  }
}

// =================================================================== stats
class _StatTile extends StatelessWidget {
  const _StatTile(
      {required this.icon,
      required this.value,
      required this.label,
      this.unit = ''});
  final IconData icon;
  final String value;
  final String unit;
  final String label;

  @override
  Widget build(BuildContext context) {
    return PaperCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: C.accent),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(value,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, height: 1)),
              if (unit.isNotEmpty) ...[
                const SizedBox(width: 3),
                Text(unit,
                    style: const TextStyle(color: C.grey, fontSize: 12)),
              ],
            ],
          ),
          const SizedBox(height: 4),
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: C.grey, fontSize: 12)),
        ],
      ),
    );
  }
}

class _GoalCard extends StatelessWidget {
  const _GoalCard();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final goal = math.max(1, s.dailyGoalMin);
    final v = (s.focusToday / goal).clamp(0.0, 1.0).toDouble();
    return PaperCard(
      child: Row(
        children: [
          const IllusImg('goals', size: 58),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(context.tr('f_goal'),
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    Text(
                        '${s.focusToday} / ${s.dailyGoalMin} ${context.tr('f_min_short')}',
                        style: const TextStyle(
                            color: C.grey,
                            fontSize: 13,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: v,
                    minHeight: 10,
                    color: v >= 1 ? C.good : C.accent,
                    backgroundColor: C.creamDark,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WeekCard extends StatelessWidget {
  const _WeekCard();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final wk = s.focusWeek();
    final now = DateTime.now();
    final labels = context.tr('wd_short').split(',');
    final mx = math.max(30, wk.fold<int>(0, (a, b) => math.max(a, b)));
    return PaperCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(context.tr('f_week'),
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          SizedBox(
            height: 112,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (var i = 0; i < wk.length; i++)
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (wk[i] > 0)
                          Text('${wk[i]}',
                              style: const TextStyle(
                                  fontSize: 10.5, color: C.grey)),
                        const SizedBox(height: 3),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 500),
                          curve: Curves.easeOutCubic,
                          width: 18,
                          height: 4 + 68 * (wk[i] / mx),
                          decoration: BoxDecoration(
                            color: i == wk.length - 1
                                ? C.accent
                                : C.accent.withAlpha(wk[i] > 0 ? 120 : 45),
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          () {
                            final d = now.subtract(Duration(days: 6 - i));
                            final idx = d.weekday - 1;
                            return idx < labels.length ? labels[idx] : '';
                          }(),
                          style: const TextStyle(
                              fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================== garden
class _Garden extends StatelessWidget {
  const _Garden();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.garden.isEmpty) {
      return PaperCard(
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
        child: Column(
          children: [
            const IllusImg('start', size: 130, float: true),
            const SizedBox(height: 8),
            Text(context.tr('f_garden_empty'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: C.grey, height: 1.5)),
          ],
        ),
      );
    }
    final items = s.garden.take(12).toList();
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 0.82,
      children: [for (final g in items) _GardenTile(g: g)],
    );
  }
}

class _GardenTile extends StatelessWidget {
  const _GardenTile({required this.g});
  final GardenPlant g;

  @override
  Widget build(BuildContext context) {
    final unit = context.tr('f_min_short');
    return Container(
      padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
      decoration: BoxDecoration(
        color: g.withered ? C.creamDark : C.paper,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: C.line),
      ),
      child: Column(
        children: [
          Expanded(
            child: PlantView(
              kind: g.kind,
              progress: g.progress,
              wilt: g.withered ? 1 : 0,
              animate: false,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            g.withered
                ? '${g.minutes}$unit · ${context.tr('f_withered')}'
                : '${g.minutes} $unit',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: g.withered ? C.grey : C.ink),
          ),
        ],
      ),
    );
  }
}

// =============================================================== settings
class _SettingsSheet extends StatelessWidget {
  const _SettingsSheet();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final pomo = context.read<PomodoroController>();

    void change({int? focus, int? short, int? long, int? cycles, int? goal}) {
      s.saveFocusSettings(
          focus: focus, short: short, long: long, cycles: cycles, goal: goal);
      pomo.settingsChanged();
    }

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
            20, 12, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                    color: C.line, borderRadius: BorderRadius.circular(3)),
              ),
            ),
            const SizedBox(height: 16),
            Text(context.tr('f_settings'),
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            Text(context.tr('f_focus_len'),
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final m in const [15, 25, 30, 45, 60])
                  Pill(
                      label: '$m',
                      selected: s.focusMin == m,
                      onTap: () => change(focus: m)),
              ],
            ),
            const SizedBox(height: 18),
            CountStepper(
                label: context.tr('f_short_len'),
                value: s.shortBreakMin,
                min: 1,
                max: 30,
                onChanged: (v) => change(short: v)),
            const SizedBox(height: 12),
            CountStepper(
                label: context.tr('f_long_len'),
                value: s.longBreakMin,
                min: 5,
                max: 60,
                onChanged: (v) => change(long: v)),
            const SizedBox(height: 12),
            CountStepper(
                label: context.tr('f_cycles'),
                value: s.cyclesBeforeLong,
                min: 2,
                max: 8,
                onChanged: (v) => change(cycles: v)),
            const SizedBox(height: 18),
            Text(context.tr('f_goal_len'),
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final m in const [30, 60, 90, 120, 180])
                  Pill(
                      label: '$m',
                      selected: s.dailyGoalMin == m,
                      onTap: () => change(goal: m)),
              ],
            ),
            const SizedBox(height: 18),
            Text(context.tr('f_plant'),
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Row(
              children: [
                for (final k in plantKinds)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: GestureDetector(
                        onTap: () => s.saveFocusSettings(plant: k),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
                          decoration: BoxDecoration(
                            color: s.plantKind == k ? C.accentSoft : C.cream,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(
                                color: s.plantKind == k ? C.accent : C.line,
                                width: s.plantKind == k ? 2 : 1),
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 92,
                                child: PlantView(
                                    kind: k, progress: 1, animate: false),
                              ),
                              const SizedBox(height: 4),
                              Text(context.tr('plant_$k'),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
