import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../illus.dart';
import '../plant.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'course_screen.dart';
import 'create_quiz_screen.dart';
import 'exam_screen.dart';
import 'home_shell.dart';
import 'summary_tab.dart';

class _Recent {
  _Recent(this.title, this.sub, this.trailing, this.kind, this.icon, this.date,
      this.open);
  final String title;
  final String sub;
  final String trailing;
  final String kind;
  final IconData icon;
  final DateTime date;
  final void Function(BuildContext) open;
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final now = DateTime.now();
    final greetKey = now.hour < 12
        ? 'good_morning'
        : (now.hour < 18 ? 'good_afternoon' : 'good_evening');
    final name = s.userName.trim();
    final hi = name.isEmpty
        ? context.tr('hi_nobody')
        : '${context.tr('hi')}${context.isAr ? '،' : ','} $name';
    final weekdays = context.tr('weekdays').split(',');
    final months = context.tr('months').split(',');
    final dateStr = '${now.day} ${months[now.month - 1]} ${now.year}';

    final items = <_Recent>[
      for (final q in s.quizzes)
        _Recent(
          q.title,
          '${q.questions.length} ${context.tr('questions_word')}',
          q.lastPercent == null ? '' : '${q.lastPercent!.round()}%',
          context.tr('kind_quiz'),
          Icons.quiz_rounded,
          q.createdAt,
          (c) => Navigator.push(c, slideRoute(ExamScreen(quiz: q))),
        ),
      for (final c in s.courses)
        _Recent(
          c.title,
          '${c.done}/${c.total} ${context.tr('lessons_word')}',
          '${(c.progress * 100).round()}%',
          context.tr('kind_course'),
          Icons.school_rounded,
          c.createdAt,
          (ctx) => Navigator.push(ctx, slideRoute(CourseScreen(course: c))),
        ),
      for (final m in s.summaries)
        _Recent(
          m.title,
          m.source.isEmpty ? fmtDate(m.createdAt) : m.source,
          '',
          context.tr('kind_summary'),
          m.mode == 'cards' ? Icons.style_rounded : Icons.article_rounded,
          m.createdAt,
          (c) => Navigator.push(c, slideRoute(SummaryDetailScreen(item: m))),
        ),
    ]..sort((a, b) => b.date.compareTo(a.date));
    final top = items.take(4).toList();

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          // greeting row
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(context.tr(greetKey),
                        style: const TextStyle(color: C.grey, fontSize: 13)),
                    const SizedBox(height: 2),
                    Text(hi,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900, height: 1.2)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => homeTab.value = 5,
                child: Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                      color: C.ink, shape: BoxShape.circle),
                  child: name.isEmpty
                      ? const Icon(Icons.person_rounded, color: C.cream)
                      : Text(String.fromCharCode(name.runes.first).toUpperCase(),
                          style: const TextStyle(
                              color: C.cream,
                              fontWeight: FontWeight.w900,
                              fontSize: 19)),
                ),
              ),
            ],
          ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.2, end: 0),
          const SizedBox(height: 18),

          // hero card
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 8, 18),
            decoration: BoxDecoration(
              color: C.paper,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: C.line),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withAlpha(18),
                    blurRadius: 22,
                    offset: const Offset(0, 8)),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(context.tr('today_label'),
                          style: const TextStyle(color: C.grey, fontSize: 12.5)),
                      const SizedBox(height: 4),
                      Text(weekdays[now.weekday - 1],
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w900, height: 1.2)),
                      Text(dateStr,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800, height: 1.3)),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Icon(Icons.local_fire_department_rounded,
                              size: 20, color: C.ink),
                          const SizedBox(width: 4),
                          Text('${s.streak} ${context.tr('days_word')}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800, fontSize: 14)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      GestureDetector(
                        onTap: () => Navigator.push(
                            context, slideRoute(const CreateQuizScreen())),
                        child: Row(
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                  color: C.ink,
                                  borderRadius: BorderRadius.circular(14)),
                              child: const Icon(Icons.add_rounded,
                                  color: C.cream, size: 28),
                            ),
                            const SizedBox(width: 10),
                            Flexible(
                              child: Text(context.tr('new_quiz'),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w800, fontSize: 14)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const IllusImg('start', size: 150, float: true),
              ],
            ),
          ).animate(delay: 100.ms).fadeIn(duration: 450.ms).slideY(begin: 0.1, end: 0),

          const SizedBox(height: 14),
          const _FocusMiniCard()
              .animate(delay: 180.ms)
              .fadeIn(duration: 450.ms)
              .slideY(begin: 0.1, end: 0),
          const SizedBox(height: 26),
          Text(context.tr('continue_study'),
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          if (top.isEmpty)
            EmptyState(
                icon: Icons.rocket_launch_rounded,
                illus: 'e_calendar',
                text: context.tr('empty_home'))
          else
            for (var i = 0; i < top.length; i++)
              _RecentCard(item: top[i], dark: i == 0)
                  .animate(delay: (200 + 90 * i).ms)
                  .fadeIn(duration: 350.ms)
                  .slideX(begin: 0.12, end: 0),
        ],
      ),
    );
  }
}

class _RecentCard extends StatelessWidget {
  const _RecentCard({required this.item, required this.dark});
  final _Recent item;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final bg = dark ? C.ink : C.accent;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => item.open(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: C.cream,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w700)),
                          ),
                          if (dark) ...[
                            const SizedBox(width: 8),
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                  color: Color(0xFF4ADE80), shape: BoxShape.circle),
                            ),
                            const SizedBox(width: 4),
                            Text(context.tr('latest'),
                                style: const TextStyle(
                                    color: Color(0xFF4ADE80),
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w800)),
                          ],
                        ],
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          Icon(item.icon,
                              size: 13, color: C.cream.withAlpha(190)),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(item.sub,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: C.cream.withAlpha(190), fontSize: 12)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (item.trailing.isNotEmpty)
                      Text(item.trailing,
                          style: const TextStyle(
                              color: C.cream,
                              fontWeight: FontWeight.w900,
                              fontSize: 15)),
                    Text(item.kind,
                        style: TextStyle(
                            color: C.cream.withAlpha(180),
                            fontSize: 11,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


/// Daily focus goal: the plant grows as today's focus minutes approach the goal.
class _FocusMiniCard extends StatelessWidget {
  const _FocusMiniCard();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final goal = s.dailyGoalMin < 1 ? 1 : s.dailyGoalMin;
    final v = (s.focusToday / goal).clamp(0.0, 1.0).toDouble();
    return PaperCard(
      onTap: () => homeTab.value = 3,
      padding: const EdgeInsets.fromLTRB(14, 12, 16, 12),
      child: Row(
        children: [
          SizedBox(
            width: 74,
            height: 84,
            child: PlantView(
                kind: s.plantKind, progress: v, animate: false),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.tr('f_goal'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 2),
                Text(
                    '${s.focusToday} / ${s.dailyGoalMin} ${context.tr('f_min_short')}',
                    style: const TextStyle(color: C.grey, fontSize: 13)),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: v,
                    minHeight: 8,
                    color: v >= 1 ? C.good : C.accent,
                    backgroundColor: C.creamDark,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.chevron_right_rounded, color: C.grey),
        ],
      ),
    );
  }
}
