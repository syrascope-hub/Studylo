import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/extract.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'course_screen.dart';

class CoursesTab extends StatelessWidget {
  const CoursesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('courses_title'),
              subtitle: context.tr('courses_sub')),
          GestureDetector(
            onTap: () =>
                Navigator.push(context, slideRoute(const CreateCourseScreen())),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                  color: C.ink, borderRadius: BorderRadius.circular(26)),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.tr('new_course'),
                            style: const TextStyle(
                                color: C.cream,
                                fontSize: 24,
                                fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Text(context.tr('new_course_sub'),
                            style: TextStyle(
                                color: C.cream.withAlpha(190),
                                fontSize: 14,
                                height: 1.5)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  Container(
                    width: 56,
                    height: 56,
                    decoration: const BoxDecoration(
                        color: C.cream, shape: BoxShape.circle),
                    child: const Icon(Icons.add_rounded, color: C.ink, size: 32),
                  ),
                ],
              ),
            ),
          ).animate().fadeIn(duration: 450.ms).slideY(begin: 0.15, end: 0),
          const SizedBox(height: 22),
          SectionTitle(context.tr('my_courses')),
          if (s.courses.isEmpty)
            EmptyState(
                icon: Icons.school_rounded,
                illus: 'e_books',
                text: context.tr('no_courses'))
          else
            for (var i = 0; i < s.courses.length; i++)
              _CourseTile(course: s.courses[i])
                  .animate(delay: (60 * (i > 6 ? 6 : i)).ms)
                  .fadeIn(duration: 350.ms)
                  .slideY(begin: 0.12, end: 0),
        ],
      ),
    );
  }
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.course});
  final Course course;

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Dismissible(
        key: ValueKey(course.id),
        direction: DismissDirection.horizontal,
        confirmDismiss: (_) => confirm(context, context.trr('delete_confirm')),
        onDismissed: (_) => s.deleteCourse(course),
        background: Container(
          decoration: BoxDecoration(
              color: C.bad, borderRadius: BorderRadius.circular(18)),
          alignment: Alignment.center,
          child: const Icon(Icons.delete_rounded, color: Colors.white),
        ),
        child: PaperCard(
          onTap: () => Navigator.push(
              context, slideRoute(CourseScreen(course: course))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(course.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 17, height: 1.3)),
              const SizedBox(height: 4),
              Text(
                  '${course.modules.length} ${context.tr('modules_word')} · ${course.done}/${course.total} ${context.tr('lessons_word')}',
                  style: const TextStyle(color: C.grey, fontSize: 13)),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: course.progress),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => LinearProgressIndicator(
                    value: v,
                    minHeight: 8,
                    backgroundColor: C.creamDark,
                    color: C.ink,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CreateCourseScreen extends StatefulWidget {
  const CreateCourseScreen({super.key});

  @override
  State<CreateCourseScreen> createState() => _CreateCourseScreenState();
}

class _CreateCourseScreenState extends State<CreateCourseScreen> {
  String _src = 'ai';
  String _level = 'beginner';
  final TextEditingController _topic = TextEditingController();
  final TextEditingController _text = TextEditingController();
  String? _pdfName;
  String? _pdfText;

  @override
  void dispose() {
    _topic.dispose();
    _text.dispose();
    super.dispose();
  }

  Future<void> _pickPdf() async {
    try {
      final f = await Extractor.pickPdfBytes();
      if (f == null || !mounted) return;
      final text = await runBusy<String>(
          context, context.trr('reading_pdf'), () => Extractor.pdfToText(f.$2));
      if (text == null || !mounted) return;
      if (text.length < 30) {
        toast(context, context.trr('err_pdf_empty'), error: true);
        return;
      }
      setState(() {
        _pdfName = f.$1;
        _pdfText = text;
      });
    } catch (e) {
      if (mounted) toast(context, errMsg(context, e), error: true);
    }
  }

  Future<void> _create() async {
    var topic = _topic.text.trim();
    var source = '';
    if (_src == 'ai') {
      if (topic.isEmpty) {
        toast(context, context.trr('need_topic'), error: true);
        return;
      }
    } else if (_src == 'text') {
      source = _text.text.trim();
      if (source.length < 30) {
        toast(context, context.trr('err_empty_src'), error: true);
        return;
      }
    } else {
      source = _pdfText ?? '';
      if (source.isEmpty) {
        toast(context, context.trr('choose_pdf'), error: true);
        return;
      }
    }
    final s = context.read<AppState>();
    final course = await runBusy<Course>(
      context,
      context.trr('building_course'),
      () => s.ai.generateCourse(topic: topic, source: source, level: _level),
    );
    if (course == null || !mounted) return;
    s.addCourse(course);
    Navigator.pushReplacement(context, slideRoute(CourseScreen(course: course)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('new_course'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          Seg<String>(
            items: {
              'ai': context.tr('c_ai'),
              'text': context.tr('src_text'),
              'pdf': 'PDF',
            },
            value: _src,
            onChanged: (v) => setState(() => _src = v),
          ),
          const SizedBox(height: 16),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: KeyedSubtree(key: ValueKey(_src), child: _input(context)),
          ),
          const SizedBox(height: 18),
          SectionTitle(context.tr('level')),
          Seg<String>(
            items: {
              'beginner': context.tr('l_beginner'),
              'intermediate': context.tr('l_intermediate'),
              'advanced': context.tr('l_advanced'),
            },
            value: _level,
            onChanged: (v) => setState(() => _level = v),
          ),
          const SizedBox(height: 28),
          ElevatedButton.icon(
            onPressed: _create,
            icon: const Icon(Icons.auto_awesome),
            label: Text(context.tr('build_course')),
          ),
        ],
      ),
    );
  }

  Widget _input(BuildContext context) {
    switch (_src) {
      case 'ai':
        return TextField(
          controller: _topic,
          minLines: 3,
          maxLines: 6,
          decoration: InputDecoration(hintText: context.tr('course_idea_hint')),
        );
      case 'text':
        return Column(
          children: [
            TextField(
              controller: _text,
              minLines: 6,
              maxLines: 12,
              decoration: InputDecoration(hintText: context.tr('course_text_hint')),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _topic,
              decoration: InputDecoration(hintText: context.tr('course_focus_hint')),
            ),
          ],
        );
      default:
        return _pdfName == null
            ? OutlinedButton.icon(
                onPressed: _pickPdf,
                icon: const Icon(Icons.picture_as_pdf_rounded),
                label: Text(context.tr('choose_pdf')),
              )
            : PaperCard(
                child: Row(
                  children: [
                    const Icon(Icons.picture_as_pdf_rounded),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(_pdfName!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    IconButton(
                        icon: const Icon(Icons.swap_horiz_rounded),
                        onPressed: _pickPdf),
                  ],
                ),
              );
    }
  }
}
