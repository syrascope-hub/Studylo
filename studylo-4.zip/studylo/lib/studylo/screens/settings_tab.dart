import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../services/ai_service.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  late final TextEditingController _name;
  late final TextEditingController _key;
  late final TextEditingController _model;
  late final TextEditingController _vision;
  bool _hide = true;
  KeyTestResult? _result;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _name = TextEditingController(text: s.userName);
    _key = TextEditingController(text: s.apiKey);
    _model = TextEditingController(text: s.model);
    _vision = TextEditingController(text: s.visionModel);
  }

  @override
  void dispose() {
    _name.dispose();
    _key.dispose();
    _model.dispose();
    _vision.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final s = context.read<AppState>();
    await s.saveKey(_key.text);
    s.saveModels(_model.text, _vision.text);
    _model.text = s.model;
    _vision.text = s.visionModel;
    if (mounted) toast(context, context.trr('saved'));
  }

  Future<void> _test() async {
    final s = context.read<AppState>();
    if (_key.text.trim().isEmpty) {
      toast(context, context.trr('no_key'), error: true);
      return;
    }
    final service = AiService(
      apiKey: _key.text,
      model: _model.text.trim().isEmpty ? AppState.defaultModel : _model.text.trim(),
      visionModel:
          _vision.text.trim().isEmpty ? AppState.defaultVision : _vision.text.trim(),
      lang: s.locale,
    );
    final r = await runBusy<KeyTestResult>(
        context, context.trr('testing'), service.testKey);
    if (r == null || !mounted) return;
    setState(() => _result = r);
    // A working key is saved automatically.
    if (r.tokenOk && r.modelOk) await _save();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('settings_title'),
              subtitle: context.tr('settings_sub')),
          PaperCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.person_rounded),
                    const SizedBox(width: 10),
                    Text(context.tr('your_name'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _name,
                  maxLength: 20,
                  onChanged: s.setName,
                  decoration: InputDecoration(
                    hintText: context.tr('name_hint'),
                    counterText: '',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PaperCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.vpn_key_rounded),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(context.tr('hf_key'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 17)),
                    ),
                    _StatusChip(ok: s.hasKey),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _key,
                  obscureText: _hide,
                  autocorrect: false,
                  enableSuggestions: false,
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                    hintText: 'hf_xxxxxxxxxxxxxxxx',
                    suffixIcon: IconButton(
                      icon: Icon(_hide
                          ? Icons.visibility_rounded
                          : Icons.visibility_off_rounded),
                      onPressed: () => setState(() => _hide = !_hide),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(context.tr('hf_key_help'),
                    style: const TextStyle(color: C.grey, fontSize: 13, height: 1.55)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.link_rounded, size: 16, color: C.grey),
                    const SizedBox(width: 6),
                    const Expanded(
                      child: SelectableText('huggingface.co/settings/tokens',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    ),
                    TextButton(
                      onPressed: () async {
                        await Clipboard.setData(
                            const ClipboardData(text: 'https://huggingface.co/settings/tokens'));
                        if (context.mounted) toast(context, context.trr('copied'));
                      },
                      child: Text(context.tr('copy')),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _save,
                        icon: const Icon(Icons.save_rounded),
                        label: Text(context.tr('save')),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _test,
                        icon: const Icon(Icons.bolt_rounded),
                        label: Text(context.tr('test')),
                        style: ElevatedButton.styleFrom(
                            minimumSize: const Size(0, 50)),
                      ),
                    ),
                  ],
                ),
                if (_result != null) _resultCard(context, _result!),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PaperCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.memory_rounded),
                    const SizedBox(width: 10),
                    Text(context.tr('models'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                const SizedBox(height: 12),
                Text(context.tr('text_model'),
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 6),
                TextField(
                  controller: _model,
                  autocorrect: false,
                  decoration: const InputDecoration(hintText: AppState.defaultModel),
                ),
                const SizedBox(height: 12),
                Text(context.tr('vision_model'),
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 6),
                TextField(
                  controller: _vision,
                  autocorrect: false,
                  decoration: const InputDecoration(hintText: AppState.defaultVision),
                ),
                const SizedBox(height: 8),
                Text(context.tr('models_help'),
                    style: const TextStyle(color: C.grey, fontSize: 12.5, height: 1.5)),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton(
                    onPressed: () {
                      _model.text = AppState.defaultModel;
                      _vision.text = AppState.defaultVision;
                      _save();
                    },
                    child: Text(context.tr('reset_defaults')),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          PaperCard(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.language_rounded),
                    const SizedBox(width: 10),
                    Text(context.tr('language'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                const SizedBox(height: 12),
                Seg<String>(
                  items: const {'ar': 'العربية', 'en': 'English'},
                  value: s.locale,
                  onChanged: s.setLocale,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: () async {
              if (await confirm(context, context.trr('clear_confirm'))) {
                await s.clearAll();
                if (context.mounted) toast(context, context.trr('cleared'));
              }
            },
            icon: const Icon(Icons.delete_sweep_rounded, color: C.bad),
            label: Text(context.tr('clear_data'),
                style: const TextStyle(color: C.bad)),
            style: OutlinedButton.styleFrom(
                side: const BorderSide(color: C.bad, width: 1.4)),
          ),
          const SizedBox(height: 22),
          Center(
            child: Text('Studylo · v1.0.0',
                style: const TextStyle(color: C.grey, fontSize: 12.5)),
          ),
        ],
      ),
    );
  }

  Widget _resultCard(BuildContext context, KeyTestResult r) {
    Widget row(bool ok, String text) => Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(ok ? Icons.check_circle_rounded : Icons.cancel_rounded,
                  size: 20, color: ok ? C.good : C.bad),
              const SizedBox(width: 8),
              Expanded(child: Text(text, style: const TextStyle(height: 1.45, fontSize: 14))),
            ],
          ),
        );
    final t = context.trr;
    return Container(
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: C.cream,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          row(
            r.tokenOk,
            r.tokenOk
                ? '${t('test_token_ok')}${r.user == null ? '' : ' (${r.user})'}'
                : '${t('test_token_bad')} ${r.tokenError ?? ''}',
          ),
          if (r.tokenOk)
            row(
              r.modelOk,
              r.modelOk
                  ? t('test_model_ok')
                  : '${t(r.modelErrCode ?? 'err_model')}${(r.modelErrDetail ?? '').isEmpty ? '' : '\n${r.modelErrDetail}'}',
            ),
        ],
      ),
    ).animate().fadeIn(duration: 350.ms).slideY(begin: 0.1, end: 0);
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.ok});
  final bool ok;

  @override
  Widget build(BuildContext context) {
    final col = ok ? C.good : C.bad;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: col.withAlpha(24),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: col),
      ),
      child: Text(context.tr(ok ? 'key_saved' : 'key_missing'),
          style: TextStyle(color: col, fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }
}
