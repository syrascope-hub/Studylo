import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'summary_tab.dart';

/// Flashcards list: words + translations, search, filter, review.
class CardsTab extends StatefulWidget {
  const CardsTab({super.key});

  @override
  State<CardsTab> createState() => _CardsTabState();
}

class _CardsTabState extends State<CardsTab> {
  final _search = TextEditingController();
  int _filter = 0; // 0 all, 1 to review, 2 learned

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<CardItem> _visible(AppState s) {
    final q = _search.text.trim().toLowerCase();
    return s.cards.where((c) {
      if (_filter == 1 && c.learned) return false;
      if (_filter == 2 && !c.learned) return false;
      if (q.isEmpty) return true;
      return c.front.toLowerCase().contains(q) ||
          c.back.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _edit(CardItem? card) async {
    final r = await showDialog<List<String>>(
      context: context,
      builder: (_) => _CardDialog(card: card),
    );
    if (r == null || !mounted) return;
    final st = context.read<AppState>();
    if (card == null) {
      final n = st.addCards([r]);
      if (n == 0) toast(context, context.trr('cards_dup'), error: true);
    } else {
      st.updateCard(card, r[0], r[1]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = _visible(s);
    final learned = s.cards.where((c) => c.learned).length;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('cards_title'),
              subtitle: context.tr('cards_sub')),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.push(
                      context, slideRoute(const BulkAddScreen())),
                  icon: const Icon(Icons.playlist_add_rounded),
                  label: Text(context.tr('cards_bulk')),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _edit(null),
                  icon: const Icon(Icons.add_rounded),
                  label: Text(context.tr('cards_add')),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (s.cards.isEmpty)
            EmptyState(
                icon: Icons.style_rounded,
                illus: 'e_cards',
                text: context.tr('cards_empty'))
          else ...[
            PaperCard(
              color: C.ink,
              borderColor: C.ink,
              padding: const EdgeInsets.fromLTRB(18, 14, 12, 14),
              onTap: list.isEmpty
                  ? null
                  : () => Navigator.push(
                      context, slideRoute(CardsStudyScreen(cards: list))),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(context.tr('cards_study'),
                            style: const TextStyle(
                                color: C.cream,
                                fontSize: 19,
                                fontWeight: FontWeight.w900)),
                        const SizedBox(height: 2),
                        Text(
                            '${s.cards.length} ${context.tr('cards_word')}  ·  $learned ${context.tr('cards_done')}',
                            style: TextStyle(
                                color: C.cream.withAlpha(190), fontSize: 13.5)),
                      ],
                    ),
                  ),
                  Container(
                    width: 46,
                    height: 46,
                    decoration: const BoxDecoration(
                        color: C.cream, shape: BoxShape.circle),
                    child: const Icon(Icons.play_arrow_rounded, color: C.ink),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: context.tr('cards_search'),
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () => setState(_search.clear),
                      ),
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                for (final e in [
                  (0, 'cards_all'),
                  (1, 'cards_todo'),
                  (2, 'cards_done'),
                ])
                  ChoiceChip(
                    label: Text(context.tr(e.$2),
                        style: TextStyle(
                            color: _filter == e.$1 ? C.cream : C.ink,
                            fontWeight: FontWeight.w700)),
                    selected: _filter == e.$1,
                    selectedColor: C.ink,
                    backgroundColor: C.paper,
                    showCheckmark: false,
                    side: const BorderSide(color: C.line),
                    onSelected: (_) => setState(() => _filter = e.$1),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (list.isEmpty)
              EmptyState(
                  icon: Icons.search_off_rounded,
                  text: context.tr('cards_none'))
            else
              for (var i = 0; i < list.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _CardTile(card: list[i], onEdit: () => _edit(list[i])),
                )
                    .animate(delay: (40 * (i > 6 ? 6 : i)).ms)
                    .fadeIn(duration: 300.ms)
                    .slideY(begin: 0.1, end: 0),
          ],
        ],
      ),
    );
  }
}

class _CardTile extends StatelessWidget {
  const _CardTile({required this.card, required this.onEdit});
  final CardItem card;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    return PaperCard(
      padding: const EdgeInsets.fromLTRB(16, 8, 4, 8),
      onTap: onEdit,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(card.front,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(card.back,
                    style: const TextStyle(
                        color: C.grey, fontSize: 15, height: 1.4)),
              ],
            ),
          ),
          IconButton(
            tooltip: context.tr('cards_mark'),
            icon: Icon(
              card.learned
                  ? Icons.check_circle_rounded
                  : Icons.radio_button_unchecked_rounded,
              color: card.learned ? C.good : C.grey,
            ),
            onPressed: () => context.read<AppState>().toggleLearned(card),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: C.bad),
            onPressed: () async {
              final st = context.read<AppState>();
              if (await confirm(context, context.trr('delete_confirm'))) {
                st.deleteCard(card);
              }
            },
          ),
        ],
      ),
    );
  }
}

/// Add / edit one card. Pops with [word, translation].
class _CardDialog extends StatefulWidget {
  const _CardDialog({this.card});
  final CardItem? card;

  @override
  State<_CardDialog> createState() => _CardDialogState();
}

class _CardDialogState extends State<_CardDialog> {
  late final TextEditingController _f =
      TextEditingController(text: widget.card?.front ?? '');
  late final TextEditingController _b =
      TextEditingController(text: widget.card?.back ?? '');

  @override
  void dispose() {
    _f.dispose();
    _b.dispose();
    super.dispose();
  }

  void _ok() {
    final f = _f.text.trim();
    final b = _b.text.trim();
    if (f.isEmpty || b.isEmpty) return;
    Navigator.pop(context, [f, b]);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(context.tr(widget.card == null ? 'cards_add' : 'cards_edit'),
          style: const TextStyle(fontWeight: FontWeight.w800)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _f,
            autofocus: true,
            textInputAction: TextInputAction.next,
            decoration:
                InputDecoration(labelText: context.tr('cards_front')),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _b,
            minLines: 1,
            maxLines: 3,
            decoration: InputDecoration(labelText: context.tr('cards_back')),
          ),
        ],
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(context.tr('cancel'))),
        TextButton(onPressed: _ok, child: Text(context.tr('save'))),
      ],
    );
  }
}

/// Paste many lines like "apple, تفاحة" and add them all at once.
class BulkAddScreen extends StatefulWidget {
  const BulkAddScreen({super.key});

  @override
  State<BulkAddScreen> createState() => _BulkAddScreenState();
}

class _BulkAddScreenState extends State<BulkAddScreen> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text;
    if (t == null || t.trim().isEmpty || !mounted) return;
    setState(() {
      final cur = _c.text.trimRight();
      _c.text = cur.isEmpty ? t : '$cur\n$t';
      _c.selection = TextSelection.collapsed(offset: _c.text.length);
    });
  }

  void _add() {
    final p = parseCardLines(_c.text);
    if (p.pairs.isEmpty) return;
    final n = context.read<AppState>().addCards(p.pairs);
    final dup = p.pairs.length - n;
    var msg = '${context.trr('cards_added')} $n';
    if (dup > 0) msg += '  ·  $dup ${context.trr('cards_dups')}';
    final messenger = ScaffoldMessenger.of(context);
    Navigator.pop(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final p = parseCardLines(_c.text);
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('cards_bulk_title'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
        children: [
          PaperCard(
            color: C.creamDark,
            borderColor: C.creamDark,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(context.tr('cards_bulk_help'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, height: 1.5)),
                const SizedBox(height: 10),
                const Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text('apple, تفاحة\nbook, كتاب\nrun, يركض',
                      style: TextStyle(color: C.grey, height: 1.6)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _c,
            onChanged: (_) => setState(() {}),
            keyboardType: TextInputType.multiline,
            minLines: 8,
            maxLines: 14,
            decoration: const InputDecoration(hintText: 'apple, تفاحة'),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: _paste,
                icon: const Icon(Icons.content_paste_rounded),
                label: Text(context.tr('cards_paste')),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '${p.pairs.length} ${context.tr('cards_ready')}'
                  '${p.invalid > 0 ? '\n${p.invalid} ${context.tr('cards_invalid')}' : ''}',
                  style: TextStyle(
                      color: p.invalid > 0 ? C.warn : C.grey,
                      fontWeight: FontWeight.w700,
                      height: 1.4),
                ),
              ),
            ],
          ),
          if (p.pairs.isNotEmpty) ...[
            const SizedBox(height: 12),
            for (final e in p.pairs.take(3))
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: PaperCard(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(e[0],
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800))),
                      const Icon(Icons.swap_horiz_rounded,
                          size: 18, color: C.grey),
                      Expanded(
                          child: Text(e[1],
                              textAlign: TextAlign.end,
                              style: const TextStyle(color: C.grey))),
                    ],
                  ),
                ),
              ),
          ],
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: p.pairs.isEmpty ? null : _add,
            icon: const Icon(Icons.done_all_rounded),
            label: Text(context.tr('cards_add_n')),
          ),
        ],
      ),
    );
  }
}

/// Swipe through the cards; optional shuffle and "translation first".
class CardsStudyScreen extends StatefulWidget {
  const CardsStudyScreen({super.key, required this.cards});
  final List<CardItem> cards;

  @override
  State<CardsStudyScreen> createState() => _CardsStudyScreenState();
}

class _CardsStudyScreenState extends State<CardsStudyScreen> {
  late final List<CardItem> _order = List.of(widget.cards);
  bool _reverse = false;
  int _gen = 0;

  @override
  Widget build(BuildContext context) {
    final deck = <Map<String, String>>[
      for (final c in _order)
        {
          'front': _reverse ? c.back : c.front,
          'back': _reverse ? c.front : c.back,
        }
    ];
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('cards_study_title'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          FlashDeck(key: ValueKey('$_gen-$_reverse'), cards: deck),
          const SizedBox(height: 18),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _reverse,
            onChanged: (v) => setState(() => _reverse = v),
            title: Text(context.tr('cards_reverse'),
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          OutlinedButton.icon(
            onPressed: () => setState(() {
              _order.shuffle();
              _gen++;
            }),
            icon: const Icon(Icons.shuffle_rounded),
            label: Text(context.tr('cards_shuffle')),
          ),
        ],
      ),
    );
  }
}
