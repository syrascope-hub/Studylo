import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../illus.dart';
import '../plant.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'home_shell.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final PageController _pc = PageController();
  int _page = 0;
  static const _count = 4;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _finish() {
    context.read<AppState>().finishOnboarding();
    Navigator.of(context).pushReplacement(slideRoute(const HomeShell()));
  }

  void _next() {
    if (_page == _count - 1) {
      _finish();
    } else {
      _pc.nextPage(
          duration: const Duration(milliseconds: 450), curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final titles = ['wel1_t', 'wel2_t', 'wel3_t', 'wel4_t'];
    final descs = ['wel1_d', 'wel2_d', 'wel3_d', 'wel4_d'];
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: Row(
                children: [
                  SizedBox(
                    width: 130,
                    child: Seg<String>(
                      items: const {'ar': 'عربي', 'en': 'EN'},
                      value: s.locale,
                      onChanged: s.setLocale,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: _finish,
                    child: Text(context.tr('skip')),
                  ),
                ],
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pc,
                itemCount: _count,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (context, i) {
                  // Changing the key when the page becomes active replays animations.
                  return KeyedSubtree(
                    key: ValueKey('$i-${_page == i}'),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Column(
                        children: [
                          Expanded(child: Center(child: _illustration(i))),
                          Text(
                            context.tr(titles[i]),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 28, fontWeight: FontWeight.w900, height: 1.25),
                          )
                              .animate()
                              .fadeIn(delay: 150.ms, duration: 500.ms)
                              .slideY(begin: 0.3, end: 0),
                          const SizedBox(height: 12),
                          Text(
                            context.tr(descs[i]),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 16, height: 1.6, color: C.grey),
                          ).animate().fadeIn(delay: 300.ms, duration: 500.ms),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < _count; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: _page == i ? 28 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _page == i ? C.ink : C.line,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
              child: ElevatedButton(
                onPressed: _next,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Text(
                    context.tr(_page == _count - 1 ? 'start' : 'next'),
                    key: ValueKey(_page == _count - 1),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _illustration(int i) {
    switch (i) {
      case 0:
        return const IllusImg('quizzes', size: 250, float: true);
      case 1:
        return const IllusImg('notes', size: 250, float: true);
      case 2:
        return const IllusImg('subjects', size: 250, float: true);
      default:
        return SizedBox(
          width: 260,
          height: 300,
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: 1),
            duration: const Duration(seconds: 6),
            curve: Curves.easeInOut,
            builder: (context, v, _) => PlantView(kind: 'flower', progress: v),
          ),
        );
    }
  }
}
