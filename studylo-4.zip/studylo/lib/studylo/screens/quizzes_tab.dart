import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'create_quiz_screen.dart';
import 'exam_screen.dart';
import 'home_shell.dart';

class QuizzesTab extends StatelessWidget {
  const QuizzesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('quizzes_title'),
              subtitle: context.tr('quizzes_sub')),
          if (!s.hasKey) const _KeyBanner(),
          const _NewQuizCard(),
          const SizedBox(height: 22),
          SectionTitle(context.tr('my_quizzes')),
          if (s.quizzes.isEmpty)
            EmptyState(
                icon: Icons.edit_note_rounded,
                illus: 'e_idea',
                text: context.tr('no_quizzes'))
          else
            for (var i = 0; i < s.quizzes.length; i++)
              _QuizTile(quiz: s.quizzes[i])
                  .animate(delay: (60 * (i > 6 ? 6 : i)).ms)
                  .fadeIn(duration: 350.ms)
                  .slideY(begin: 0.12, end: 0),
        ],
      ),
    );
  }
}

class _KeyBanner extends StatelessWidget {
  const _KeyBanner();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: PaperCard(
        color: C.creamDark,
        onTap: () {
          Navigator.of(context).popUntil((r) => r.isFirst);
          homeTab.value = 5;
        },
        child: Row(
          children: [
            const Icon(Icons.vpn_key_rounded, color: C.ink),
            const SizedBox(width: 12),
            Expanded(
              child: Text(context.tr('banner_key'),
                  style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4)),
            ),
            const Icon(Icons.chevron_right_rounded),
          ],
        ),
      ),
    ).animate().fadeIn().shakeX(hz: 3, amount: 4, duration: 600.ms, delay: 500.ms);
  }
}

class _NewQuizCard extends StatelessWidget {
  const _NewQuizCard();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(context, slideRoute(const CreateQuizScreen())),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: C.ink,
          borderRadius: BorderRadius.circular(26),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(context.tr('new_quiz'),
                      style: const TextStyle(
                          color: C.cream, fontSize: 24, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(context.tr('new_quiz_sub'),
                      style: TextStyle(
                          color: C.cream.withAlpha(190), fontSize: 14, height: 1.5)),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Container(
              width: 56,
              height: 56,
              decoration:
                  const BoxDecoration(color: C.cream, shape: BoxShape.circle),
              child: const Icon(Icons.auto_awesome, color: C.ink, size: 28),
            )
                .animate(onPlay: (c) => c.repeat(reverse: true))
                .scale(
                    begin: const Offset(1, 1),
                    end: const Offset(1.1, 1.1),
                    duration: 1100.ms,
                    curve: Curves.easeInOut),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 450.ms).slideY(begin: 0.15, end: 0);
  }
}

class _QuizTile extends StatelessWidget {
  const _QuizTile({required this.quiz});
  final Quiz quiz;

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    final p = quiz.lastPercent;
    final col = p == null
        ? C.grey
        : (p >= 70 ? C.good : (p >= 50 ? C.warn : C.bad));
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Dismissible(
        key: ValueKey(quiz.id),
        direction: DismissDirection.horizontal,
        confirmDismiss: (_) => confirm(context, context.trr('delete_confirm')),
        onDismissed: (_) => s.deleteQuiz(quiz),
        background: Container(
          decoration: BoxDecoration(
              color: C.bad, borderRadius: BorderRadius.circular(18)),
          alignment: Alignment.center,
          child: const Icon(Icons.delete_rounded, color: Colors.white),
        ),
        child: PaperCard(
          onTap: () => Navigator.push(context, slideRoute(ExamScreen(quiz: quiz))),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: col, width: 2),
                ),
                alignment: Alignment.center,
                child: p == null
                    ? const Icon(Icons.description_outlined, color: C.ink)
                    : Text('${p.round()}%',
                        style: TextStyle(
                            color: col, fontWeight: FontWeight.w900, fontSize: 14)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(quiz.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16, height: 1.3)),
                    const SizedBox(height: 4),
                    Text(
                      '${quiz.questions.length} ${context.tr('questions_word')} · ${fmtDate(quiz.createdAt)}',
                      style: const TextStyle(color: C.grey, fontSize: 13),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: C.grey),
            ],
          ),
        ),
      ),
    );
  }
}
