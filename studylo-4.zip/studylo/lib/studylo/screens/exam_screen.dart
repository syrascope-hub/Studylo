import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../services/sfx.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';

/// The exam paper: answer, submit, get graded by AI, see corrections in place.
class ExamScreen extends StatefulWidget {
  const ExamScreen({super.key, required this.quiz});
  final Quiz quiz;

  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  late final Quiz quiz = widget.quiz;
  final Map<int, int> _pick = {};
  late final List<TextEditingController> _ctl =
      List.generate(quiz.questions.length, (_) => TextEditingController());
  final Map<int, QResult> _res = {};
  final ScrollController _scroll = ScrollController();
  bool _graded = false;
  Timer? _timer;
  int _left = 0;
  double _percent = 0;
  double _points = 0;

  @override
  void initState() {
    super.initState();
    if (quiz.minutes > 0) _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in _ctl) {
      c.dispose();
    }
    _scroll.dispose();
    super.dispose();
  }

  void _startTimer() {
    _left = quiz.minutes * 60;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _left--);
      if (_left <= 0) {
        t.cancel();
        _submit(force: true);
      }
    });
  }

  String get _clock {
    final m = (_left ~/ 60).toString().padLeft(2, '0');
    final s = (_left % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  List<String> get _letters => context.trr('letters').split(',');

  String _num(double v) =>
      v.toStringAsFixed(2).replaceFirst(RegExp(r'\.?0+$'), '');

  // ------------------------------------------------------------- submit
  Future<void> _submit({bool force = false}) async {
    if (_graded) return;
    final s = context.read<AppState>();
    var unanswered = 0;
    for (var i = 0; i < quiz.questions.length; i++) {
      final q = quiz.questions[i];
      final empty = q.isMcq ? !_pick.containsKey(i) : _ctl[i].text.trim().isEmpty;
      if (empty) unanswered++;
    }
    if (!force && unanswered > 0) {
      final ok = await confirm(
          context, '${context.trr('unanswered')} ($unanswered). ${context.trr('submit_anyway')}');
      if (!ok || !mounted) return;
    }
    _timer?.cancel();
    FocusManager.instance.primaryFocus?.unfocus();

    final res = await runBusy<Map<int, QResult>>(
      context,
      context.trr('grading'),
      () async {
        final out = <int, QResult>{};
        final open = <Map<String, String>>[];
        for (var i = 0; i < quiz.questions.length; i++) {
          final q = quiz.questions[i];
          if (q.isMcq) {
            final ok = _pick[i] == q.correct;
            out[i] = QResult(ok ? 1 : 0, q.explanation);
          } else {
            final a = _ctl[i].text.trim();
            if (a.isEmpty) {
              out[i] = QResult(0, s.t('no_answer'));
            } else {
              open.add({
                'id': '$i',
                'type': q.type,
                'q': q.text,
                'model_answer': q.modelAnswer,
                'student': a,
              });
            }
          }
        }
        if (open.isNotEmpty) {
          final graded = await s.ai.gradeOpen(open);
          for (final item in open) {
            final id = int.parse(item['id']!);
            out[id] = graded[id] ?? const QResult(0, '');
          }
        }
        return out;
      },
    );
    if (res == null || !mounted) {
      // grading failed: let the student try again (timer is not restarted)
      return;
    }
    _finish(res);
  }

  void _finish(Map<int, QResult> res) {
    final s = context.read<AppState>();
    var sum = 0.0;
    for (var i = 0; i < quiz.questions.length; i++) {
      res.putIfAbsent(i, () => const QResult(0, ''));
      sum += res[i]!.score;
    }
    final total = quiz.questions.length;
    final percent = total == 0 ? 0.0 : sum / total * 100;

    quiz.lastPercent = percent;
    Sfx.play(percent >= 90 ? 'cheer' : (percent >= 50 ? 'done' : 'wrong'));
    s.addAttempt(Attempt(quizTitle: quiz.title, percent: percent, date: DateTime.now()));
    for (var i = 0; i < total; i++) {
      final q = quiz.questions[i];
      final r = res[i]!;
      final pass = q.isMcq ? r.score >= 1 : r.score >= 0.5;
      if (pass) {
        if (q.ref != null) s.removeMistake(q.ref!);
      } else if (q.ref == null) {
        final answer = q.isMcq
            ? (_pick.containsKey(i) ? q.options[_pick[i]!] : '')
            : _ctl[i].text.trim();
        s.addMistake(Mistake(
          id: newId(),
          question: q,
          userAnswer: answer,
          feedback: r.feedback,
          date: DateTime.now(),
        ));
      }
    }
    s.persistQuizzes();

    setState(() {
      _res
        ..clear()
        ..addAll(res);
      _graded = true;
      _percent = percent;
      _points = sum;
    });
    if (_scroll.hasClients) {
      _scroll.animateTo(0,
          duration: const Duration(milliseconds: 600), curve: Curves.easeOutCubic);
    }
  }

  void _reset() {
    setState(() {
      _pick.clear();
      for (final c in _ctl) {
        c.clear();
      }
      _res.clear();
      _graded = false;
      _percent = 0;
      _points = 0;
    });
    if (quiz.minutes > 0) _startTimer();
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  void _share() {
    final letters = _letters;
    final b = StringBuffer()
      ..writeln(quiz.title)
      ..writeln();
    for (var i = 0; i < quiz.questions.length; i++) {
      final q = quiz.questions[i];
      b.writeln('${i + 1}. ${q.text}');
      if (q.isMcq) {
        for (var o = 0; o < q.options.length; o++) {
          b.writeln('   ${o < letters.length ? letters[o] : o + 1}) ${q.options[o]}');
        }
      }
      b.writeln();
    }
    Share.share(b.toString(), subject: quiz.title);
  }

  // --------------------------------------------------------------- build
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('exam')),
        actions: [
          if (quiz.minutes > 0 && !_graded) _timerChip(),
          IconButton(
              icon: const Icon(Icons.ios_share_rounded), onPressed: _share),
        ],
      ),
      body: ListView(
        controller: _scroll,
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
        children: [_paper(context)],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: _graded
              ? Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _reset,
                        icon: const Icon(Icons.refresh_rounded),
                        label: Text(context.tr('retry')),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(context.tr('close')),
                      ),
                    ),
                  ],
                )
              : ElevatedButton.icon(
                  onPressed: () => _submit(),
                  icon: const Icon(Icons.task_alt_rounded),
                  label: Text(context.tr('submit')),
                ),
        ),
      ),
    );
  }

  Widget _timerChip() {
    final low = _left <= 60;
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: low ? C.bad : C.ink,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.timer_outlined, size: 16, color: C.cream),
          const SizedBox(width: 5),
          Text(_clock,
              style: const TextStyle(
                  color: C.cream,
                  fontWeight: FontWeight.w800,
                  fontFeatures: [FontFeature.tabularFigures()])),
        ],
      ),
    );
  }

  Widget _paper(BuildContext context) {
    final children = <Widget>[_header(context)];
    String? last;
    for (var i = 0; i < quiz.questions.length; i++) {
      final q = quiz.questions[i];
      if (q.type != last) {
        last = q.type;
        children.add(_sectionTitle(context, q.type));
      }
      children.add(Padding(
        padding: const EdgeInsets.only(bottom: 24),
        child: q.isMcq ? _mcq(context, i, q) : _open(context, i, q),
      ));
    }
    return Container(
      decoration: BoxDecoration(
        color: C.paper,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: C.line),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withAlpha(28),
              blurRadius: 18,
              offset: const Offset(0, 8)),
        ],
      ),
      child: Stack(
        children: [
          // red margin line like a school exam sheet
          Positioned.directional(
            textDirection: Directionality.of(context),
            start: 30,
            top: 0,
            bottom: 0,
            width: 1.4,
            child: Container(color: C.bad.withAlpha(70)),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(44, 20, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 450.ms).slideY(begin: 0.05, end: 0);
  }

  Widget _doubleRule() => Column(
        children: [
          Container(height: 1.4, color: C.ink),
          const SizedBox(height: 3),
          Container(height: 0.8, color: C.ink),
        ],
      );

  Widget _blank(String label) => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text('$label: ',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          Expanded(
            child: Container(
              height: 1,
              margin: const EdgeInsets.only(bottom: 6),
              color: C.ink.withAlpha(110),
            ),
          ),
        ],
      );

  Widget _header(BuildContext context) {
    return Column(
      children: [
        const Text('S T U D Y L O',
            style: TextStyle(
                letterSpacing: 3, fontSize: 11, color: C.grey, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(quiz.title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.3)),
        const SizedBox(height: 12),
        _doubleRule(),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _blank(context.tr('student_name'))),
            const SizedBox(width: 12),
            Text('${context.tr('date')}: ${fmtDate(DateTime.now())}',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          ],
        ),
        const SizedBox(height: 10),
        _doubleRule(),
        if (_graded) _resultBanner(context),
        const SizedBox(height: 18),
      ],
    );
  }

  Widget _resultBanner(BuildContext context) {
    final col = _percent >= 70 ? C.good : (_percent >= 50 ? C.warn : C.bad);
    final gradeKey = _percent >= 85
        ? 'g_great'
        : (_percent >= 70 ? 'g_good' : (_percent >= 50 ? 'g_ok' : 'g_low'));
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Transform.rotate(
            angle: -0.18,
            child: Container(
              width: 86,
              height: 86,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: col, width: 3.5),
              ),
              alignment: Alignment.center,
              child: Text('${_percent.round()}%',
                  style: TextStyle(
                      color: col, fontSize: 24, fontWeight: FontWeight.w900)),
            ),
          )
              .animate()
              .fadeIn(duration: 200.ms)
              .scale(
                  begin: const Offset(2.4, 2.4),
                  end: const Offset(1, 1),
                  duration: 650.ms,
                  curve: Curves.bounceOut),
          const SizedBox(width: 18),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(context.tr('score'),
                  style: const TextStyle(color: C.grey, fontSize: 13)),
              Text('${_num(_points)} / ${quiz.questions.length}',
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              Text(context.tr(gradeKey),
                  style: TextStyle(color: col, fontWeight: FontWeight.w800)),
            ],
          ).animate().fadeIn(delay: 350.ms),
        ],
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String type) {
    const keys = {'mcq': 'sec_mcq', 'explain': 'sec_explain', 'solve': 'sec_solve'};
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.only(top: 4, bottom: 16),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: C.ink,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(context.tr(keys[type] ?? 'sec_explain'),
            style: const TextStyle(
                color: C.cream, fontWeight: FontWeight.w800, fontSize: 14)),
      ),
    );
  }

  Widget _qTitle(int i, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${i + 1}.',
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(width: 8),
            Expanded(
              child: Text(text,
                  style: const TextStyle(
                      fontSize: 16, height: 1.55, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );

  Widget _note(String title, String body, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsetsDirectional.fromSTEB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: color.withAlpha(22),
        borderRadius: BorderRadius.circular(8),
        border: BorderDirectional(start: BorderSide(color: color, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12.5)),
          const SizedBox(height: 3),
          SelectableText(body, style: const TextStyle(fontSize: 14.5, height: 1.55)),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1, end: 0);
  }

  // multiple choice -----------------------------------------------------
  Widget _mcq(BuildContext context, int i, Question q) {
    final letters = _letters;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _qTitle(i, q.text),
        for (var o = 0; o < q.options.length; o++) _option(i, q, o, letters),
        if (_graded && q.explanation.isNotEmpty)
          _note(context.tr('teacher_note'), q.explanation,
              (_res[i]?.score ?? 0) >= 1 ? C.good : C.bad),
      ],
    );
  }

  Widget _option(int i, Question q, int o, List<String> letters) {
    final selected = _pick[i] == o;
    final isCorrect = o == q.correct;
    var border = C.line;
    var fill = Colors.transparent;
    Widget? mark;
    if (_graded) {
      if (isCorrect) {
        border = C.good;
        fill = C.good.withAlpha(26);
        mark = const Icon(Icons.check_circle_rounded, color: C.good);
      } else if (selected) {
        border = C.bad;
        fill = C.bad.withAlpha(24);
        mark = const Icon(Icons.cancel_rounded, color: C.bad);
      }
    } else if (selected) {
      border = C.ink;
      fill = C.ink.withAlpha(14);
    }
    final bold = selected || (_graded && isCorrect);
    return GestureDetector(
      onTap: _graded ? null : () => setState(() => _pick[i] = o),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: border, width: bold ? 1.8 : 1),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 28,
              height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected && !_graded ? C.ink : Colors.transparent,
                border: Border.all(
                    color: selected && !_graded ? C.ink : C.grey, width: 1.4),
              ),
              child: Text(
                o < letters.length ? letters[o] : '${o + 1}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: selected && !_graded ? C.cream : C.ink,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(q.options[o],
                  style: TextStyle(
                      fontSize: 15,
                      height: 1.4,
                      fontWeight: bold ? FontWeight.w700 : FontWeight.w500)),
            ),
            if (mark != null) ...[const SizedBox(width: 8), mark],
          ],
        ),
      ),
    );
  }

  // explain / solve -------------------------------------------------------
  Widget _open(BuildContext context, int i, Question q) {
    final isSolve = q.type == 'solve';
    final r = _res[i];
    final col = r == null
        ? C.ink
        : (r.score >= 0.75 ? C.good : (r.score >= 0.5 ? C.warn : C.bad));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _qTitle(i, q.text),
        if (isSolve)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(context.tr('write_solution'),
                style: const TextStyle(
                    color: C.grey, fontSize: 12.5, fontWeight: FontWeight.w700)),
          ),
        RuledField(
          controller: _ctl[i],
          minLines: isSolve ? 8 : 4,
          readOnly: _graded,
          hint: context.tr(isSolve ? 'solve_hint' : 'explain_hint'),
        ),
        if (_graded && r != null) ...[
          const SizedBox(height: 6),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: col, width: 1.6),
              ),
              child: Text('${_num(r.score)} / 1',
                  style: TextStyle(
                      color: col, fontWeight: FontWeight.w900, fontSize: 13)),
            ),
          ),
          if (r.feedback.isNotEmpty) _note(context.tr('teacher_note'), r.feedback, col),
          if (q.modelAnswer.isNotEmpty)
            _note(context.tr(isSolve ? 'model_solution' : 'model_answer'),
                q.modelAnswer, C.good),
        ],
      ],
    );
  }
}
