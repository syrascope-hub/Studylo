import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/extract.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'exam_screen.dart';

class CreateQuizScreen extends StatefulWidget {
  const CreateQuizScreen({super.key, this.initialText = ''});
  final String initialText;

  @override
  State<CreateQuizScreen> createState() => _CreateQuizScreenState();
}

class _CreateQuizScreenState extends State<CreateQuizScreen> {
  late final TextEditingController _txt =
      TextEditingController(text: widget.initialText);
  String? _pdfName;
  String? _pdfText;
  int _mcq = 5;
  int _explain = 2;
  int _solve = 2;
  String _diff = 'medium';
  int _minutes = 0;

  @override
  void dispose() {
    _txt.dispose();
    super.dispose();
  }

  Future<void> _pickPdf() async {
    try {
      final f = await Extractor.pickPdfBytes();
      if (f == null || !mounted) return;
      final text = await runBusy<String>(
          context, context.trr('reading_pdf'), () => Extractor.pdfToText(f.$2));
      if (text == null || !mounted) return;
      if (text.length < 30) {
        toast(context, context.trr('err_pdf_empty'), error: true);
        return;
      }
      setState(() {
        _pdfName = f.$1;
        _pdfText = text;
      });
    } catch (e) {
      if (mounted) toast(context, errMsg(context, e), error: true);
    }
  }

  Future<void> _generate() async {
    final typed = _txt.text.trim();
    if (typed.isEmpty && _pdfText == null) {
      toast(context, context.trr('need_topic'), error: true);
      return;
    }
    if (_mcq + _explain + _solve == 0) {
      toast(context, context.trr('need_questions'), error: true);
      return;
    }
    final s = context.read<AppState>();
    final source = [typed, if (_pdfText != null) _pdfText!].join('\n\n');
    final isTopic = _pdfText == null && typed.length < 200;
    final quiz = await runBusy<Quiz>(
      context,
      context.trr('generating_quiz'),
      () => s.ai.generateQuiz(
        source: source,
        isTopic: isTopic,
        mcq: _mcq,
        explain: _explain,
        solve: _solve,
        difficulty: _diff,
        minutes: _minutes,
      ),
    );
    if (quiz == null || !mounted) return;
    s.addQuiz(quiz);
    Navigator.pushReplacement(context, slideRoute(ExamScreen(quiz: quiz)));
  }

  @override
  Widget build(BuildContext context) {
    final total = _mcq + _explain + _solve;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('new_quiz'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          SectionTitle(context.tr('quiz_source')),
          TextField(
            controller: _txt,
            minLines: 5,
            maxLines: 10,
            decoration: InputDecoration(hintText: context.tr('quiz_hint')),
          ),
          const SizedBox(height: 10),
          if (_pdfName == null)
            OutlinedButton.icon(
              onPressed: _pickPdf,
              icon: const Icon(Icons.picture_as_pdf_rounded),
              label: Text(context.tr('attach_pdf')),
            )
          else
            PaperCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  const Icon(Icons.picture_as_pdf_rounded),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_pdfName!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () => setState(() {
                      _pdfName = null;
                      _pdfText = null;
                    }),
                  ),
                ],
              ),
            ).animate().fadeIn().slideX(begin: 0.1, end: 0),
          const SizedBox(height: 18),
          SectionTitle(context.tr('question_types')),
          PaperCard(
            child: Column(
              children: [
                CountStepper(
                    label: context.tr('t_mcq'),
                    value: _mcq,
                    onChanged: (v) => setState(() => _mcq = v)),
                const Divider(height: 22),
                CountStepper(
                    label: context.tr('t_explain'),
                    value: _explain,
                    max: 10,
                    onChanged: (v) => setState(() => _explain = v)),
                const Divider(height: 22),
                CountStepper(
                    label: context.tr('t_solve'),
                    value: _solve,
                    max: 10,
                    onChanged: (v) => setState(() => _solve = v)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          SectionTitle(context.tr('difficulty')),
          Seg<String>(
            items: {
              'easy': context.tr('d_easy'),
              'medium': context.tr('d_medium'),
              'hard': context.tr('d_hard'),
            },
            value: _diff,
            onChanged: (v) => setState(() => _diff = v),
          ),
          const SizedBox(height: 18),
          SectionTitle(context.tr('timer')),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final m in const [0, 10, 20, 30, 45, 60])
                Pill(
                  label: m == 0 ? context.tr('no_timer') : '$m ${context.tr('min')}',
                  selected: _minutes == m,
                  onTap: () => setState(() => _minutes = m),
                ),
            ],
          ),
          const SizedBox(height: 28),
          ElevatedButton.icon(
            onPressed: total == 0 ? null : _generate,
            icon: const Icon(Icons.auto_awesome),
            label: Text('${context.tr('generate')} ($total)'),
          ),
        ],
      ),
    );
  }
}
