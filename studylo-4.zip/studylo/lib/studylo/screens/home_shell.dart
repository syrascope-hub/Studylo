import 'package:flutter/material.dart';

import '../theme.dart';
import 'cards_tab.dart';
import 'explore_tab.dart';
import 'focus_screen.dart';
import 'home_tab.dart';
import 'progress_tab.dart';
import 'settings_tab.dart';

/// Lets any screen switch the bottom navigation (0 home, 1 explore,
/// 2 cards, 3 focus, 4 progress, 5 settings).
final ValueNotifier<int> homeTab = ValueNotifier<int>(0);

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  @override
  void initState() {
    super.initState();
    homeTab.value = 0;
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: homeTab,
      builder: (context, idx, _) {
        const pages = <Widget>[
          HomeTab(),
          ExploreTab(),
          CardsTab(),
          FocusScreen(),
          ProgressTab(),
          SettingsTab(),
        ];
        return Scaffold(
          body: IndexedStack(
            index: idx,
            children: [
              for (var i = 0; i < pages.length; i++)
                _TabAppear(active: i == idx, child: pages[i]),
            ],
          ),
          bottomNavigationBar: _NavBar(
            index: idx,
            onTap: (i) => homeTab.value = i,
          ),
        );
      },
    );
  }
}

/// Fades/slides a tab in every time it becomes the active one.
class _TabAppear extends StatefulWidget {
  const _TabAppear({required this.active, required this.child});
  final bool active;
  final Widget child;

  @override
  State<_TabAppear> createState() => _TabAppearState();
}

class _TabAppearState extends State<_TabAppear>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 380), value: 1);

  @override
  void didUpdateWidget(covariant _TabAppear old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final curved = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero)
            .animate(curved),
        child: widget.child,
      ),
    );
  }
}

/// Floating light pill with icons only (like the reference design).
class _NavBar extends StatelessWidget {
  const _NavBar({required this.index, required this.onTap});
  final int index;
  final ValueChanged<int> onTap;

  static const _off = [
    Icons.home_outlined,
    Icons.grid_view_outlined,
    Icons.style_outlined,
    Icons.timer_outlined,
    Icons.insights_outlined,
    Icons.person_outline_rounded,
  ];
  static const _on = [
    Icons.home_rounded,
    Icons.grid_view_rounded,
    Icons.style_rounded,
    Icons.timer_rounded,
    Icons.insights_rounded,
    Icons.person_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          color: C.paper,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: C.line),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withAlpha(30),
                blurRadius: 22,
                offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (var i = 0; i < _on.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Center(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 280),
                      curve: Curves.easeOutCubic,
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: i == index ? C.ink : Colors.transparent,
                        borderRadius: BorderRadius.circular(23),
                      ),
                      child: AnimatedScale(
                        scale: i == index ? 1.1 : 1,
                        duration: const Duration(milliseconds: 280),
                        child: Icon(
                          i == index ? _on[i] : _off[i],
                          size: 24,
                          color: i == index ? C.cream : C.grey,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
