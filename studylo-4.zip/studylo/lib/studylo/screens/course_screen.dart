import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'exam_screen.dart';

class CourseScreen extends StatefulWidget {
  const CourseScreen({super.key, required this.course});
  final Course course;

  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _CourseScreenState extends State<CourseScreen> {
  Course get course => widget.course;

  Future<void> _openLesson(Module m, Lesson l) async {
    await Navigator.push(
        context, slideRoute(LessonScreen(course: course, module: m, lesson: l)));
    if (mounted) setState(() {});
  }

  Future<void> _moduleQuiz(Module m) async {
    final s = context.read<AppState>();
    final buf = StringBuffer()
      ..writeln('${course.title} - ${m.title}')
      ..writeln();
    for (final l in m.lessons) {
      buf.writeln('# ${l.title}');
      if (l.content.isNotEmpty) {
        buf.writeln(l.content.length > 2500 ? l.content.substring(0, 2500) : l.content);
      }
      buf.writeln();
    }
    final quiz = await runBusy<Quiz>(
      context,
      context.trr('generating_quiz'),
      () => s.ai.generateQuiz(
        source: buf.toString(),
        isTopic: m.lessons.every((l) => l.content.isEmpty),
        mcq: 5,
        explain: 1,
        solve: 1,
        difficulty: 'medium',
      ),
    );
    if (quiz == null || !mounted) return;
    s.addQuiz(quiz);
    Navigator.push(context, slideRoute(ExamScreen(quiz: quiz)));
  }

  @override
  Widget build(BuildContext context) {
    final p = course.progress;
    return Scaffold(
      appBar: AppBar(title: Text(course.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
                color: C.ink, borderRadius: BorderRadius.circular(24)),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(course.title,
                          style: const TextStyle(
                              color: C.cream,
                              fontSize: 21,
                              fontWeight: FontWeight.w900,
                              height: 1.3)),
                      if (course.description.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(course.description,
                            style: TextStyle(
                                color: C.cream.withAlpha(200),
                                fontSize: 13.5,
                                height: 1.5)),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                SizedBox(
                  width: 66,
                  height: 66,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      TweenAnimationBuilder<double>(
                        tween: Tween<double>(begin: 0, end: p),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, __) => CircularProgressIndicator(
                          value: v,
                          strokeWidth: 6,
                          backgroundColor: C.cream.withAlpha(50),
                          color: C.cream,
                        ),
                      ),
                      SizedBox(
                        width: 66,
                        height: 66,
                        child: Center(
                          child: Text('${(p * 100).round()}%',
                              style: const TextStyle(
                                  color: C.cream, fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ).animate().fadeIn(duration: 400.ms).slideY(begin: -0.1, end: 0),
          const SizedBox(height: 18),
          for (var mi = 0; mi < course.modules.length; mi++)
            _moduleCard(context, mi, course.modules[mi])
                .animate(delay: (80 * mi).ms)
                .fadeIn(duration: 350.ms)
                .slideY(begin: 0.1, end: 0),
        ],
      ),
    );
  }

  Widget _moduleCard(BuildContext context, int mi, Module m) {
    final done = m.lessons.where((l) => l.done).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: PaperCard(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: C.ink, shape: BoxShape.circle),
                  child: Text('${mi + 1}',
                      style: const TextStyle(
                          color: C.cream, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(m.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 16.5, height: 1.3)),
                ),
                Text('$done/${m.lessons.length}',
                    style: const TextStyle(
                        color: C.grey, fontWeight: FontWeight.w800)),
              ],
            ),
            const SizedBox(height: 8),
            for (final l in m.lessons)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _openLesson(m, l),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
                  child: Row(
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: Icon(
                          l.done
                              ? Icons.check_circle_rounded
                              : Icons.radio_button_unchecked_rounded,
                          key: ValueKey(l.done),
                          color: l.done ? C.good : C.grey,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(l.title,
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                height: 1.35,
                                color: l.done ? C.grey : C.ink)),
                      ),
                      const Icon(Icons.chevron_right_rounded, color: C.grey),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: () => _moduleQuiz(m),
              icon: const Icon(Icons.quiz_rounded, size: 20),
              label: Text(context.tr('module_quiz')),
            ),
          ],
        ),
      ),
    );
  }
}

class LessonScreen extends StatefulWidget {
  const LessonScreen({
    super.key,
    required this.course,
    required this.module,
    required this.lesson,
  });
  final Course course;
  final Module module;
  final Lesson lesson;

  @override
  State<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  bool _loading = false;
  Object? _error;

  @override
  void initState() {
    super.initState();
    if (widget.lesson.content.isEmpty) _load();
  }

  Future<void> _load() async {
    final s = context.read<AppState>();
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final text = await s.ai.generateLesson(
        course: widget.course,
        module: widget.module,
        lesson: widget.lesson,
      );
      widget.lesson.content = text;
      s.persistCourses();
    } catch (e) {
      _error = e;
    }
    if (mounted) setState(() => _loading = false);
  }

  void _toggleDone() {
    final s = context.read<AppState>();
    widget.lesson.done = !widget.lesson.done;
    s.persistCourses();
    if (widget.lesson.done) s.markActive();
    setState(() {});
    if (widget.lesson.done) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final l = widget.lesson;
    return Scaffold(
      appBar: AppBar(
        title: Text(l.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: context.tr('regenerate'),
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(context.tr('writing_lesson'),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            )
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline_rounded, size: 44, color: C.bad),
                        const SizedBox(height: 12),
                        Text(errMsg(context, _error!),
                            textAlign: TextAlign.center,
                            style: const TextStyle(height: 1.5)),
                        const SizedBox(height: 16),
                        OutlinedButton(
                            onPressed: _load, child: Text(context.tr('retry'))),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
                  children: [
                    Text(widget.module.title,
                        style: const TextStyle(
                            color: C.grey, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(l.title,
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900, height: 1.3)),
                    const Divider(height: 28),
                    FormattedText(l.content, fontSize: 16.5),
                  ],
                ).animate().fadeIn(duration: 400.ms),
      bottomNavigationBar: (_loading || _error != null)
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: l.done
                    ? OutlinedButton.icon(
                        onPressed: _toggleDone,
                        icon: const Icon(Icons.undo_rounded),
                        label: Text(context.tr('mark_undone')),
                      )
                    : ElevatedButton.icon(
                        onPressed: _toggleDone,
                        icon: const Icon(Icons.check_rounded),
                        label: Text(context.tr('finish_lesson')),
                      ),
              ),
            ),
    );
  }
}
