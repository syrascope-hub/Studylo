import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models.dart';
import '../services/ai_service.dart';
import '../services/extract.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'create_quiz_screen.dart';

class SummaryTab extends StatefulWidget {
  const SummaryTab({super.key});

  @override
  State<SummaryTab> createState() => _SummaryTabState();
}

class _SummaryTabState extends State<SummaryTab> {
  String _src = 'text';
  String _mode = 'points';
  final TextEditingController _text = TextEditingController();
  final TextEditingController _yt = TextEditingController();
  String? _pdfName;
  String? _pdfText;
  final List<Uint8List> _images = [];
  SummaryItem? _current;

  @override
  void dispose() {
    _text.dispose();
    _yt.dispose();
    super.dispose();
  }

  Future<void> _pickPdf() async {
    try {
      final f = await Extractor.pickPdfBytes();
      if (f == null || !mounted) return;
      final text = await runBusy<String>(
          context, context.trr('reading_pdf'), () => Extractor.pdfToText(f.$2));
      if (text == null || !mounted) return;
      if (text.length < 30) {
        toast(context, context.trr('err_pdf_empty'), error: true);
        return;
      }
      setState(() {
        _pdfName = f.$1;
        _pdfText = text;
      });
    } catch (e) {
      if (mounted) toast(context, errMsg(context, e), error: true);
    }
  }

  Future<void> _addImages(bool camera) async {
    try {
      final imgs = await Extractor.pickImages(camera: camera);
      if (imgs.isEmpty || !mounted) return;
      setState(() {
        _images.addAll(imgs);
        if (_images.length > 6) _images.removeRange(6, _images.length);
      });
    } catch (e) {
      if (mounted) toast(context, errMsg(context, e), error: true);
    }
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData('text/plain');
    if (d?.text != null) setState(() => _yt.text = d!.text!.trim());
  }

  Future<void> _run() async {
    final s = context.read<AppState>();
    final item = await runBusy<SummaryItem>(
      context,
      context.trr('summarizing'),
      () async {
        var text = '';
        var title = '';
        var label = '';
        switch (_src) {
          case 'text':
            text = _text.text.trim();
            label = 'text';
            break;
          case 'pdf':
            text = _pdfText ?? '';
            title = _pdfName ?? '';
            label = 'PDF';
            break;
          case 'image':
            if (_images.isEmpty) throw AiException('err_empty_src');
            text = await s.ai.imagesToText(_images);
            label = 'image';
            break;
          default:
            final r = await Extractor.youtube(_yt.text, s.locale);
            title = r.$1;
            text = r.$2;
            label = 'YouTube';
        }
        if (text.trim().length < 20) throw AiException('err_empty_src');
        return s.ai.summarize(text, _mode, fallbackTitle: title, source: label);
      },
    );
    if (item == null || !mounted) return;
    s.addSummary(item);
    setState(() => _current = item);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('sum_title'), subtitle: context.tr('sum_sub')),
          Seg<String>(
            items: {
              'text': context.tr('src_text'),
              'pdf': 'PDF',
              'image': context.tr('src_image'),
              'yt': 'YouTube',
            },
            value: _src,
            onChanged: (v) => setState(() => _src = v),
          ),
          const SizedBox(height: 14),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: KeyedSubtree(key: ValueKey(_src), child: _input(context)),
          ),
          const SizedBox(height: 16),
          SectionTitle(context.tr('sum_mode')),
          Seg<String>(
            items: {
              'points': context.tr('m_points'),
              'short': context.tr('m_short'),
              'cards': context.tr('m_cards'),
            },
            value: _mode,
            onChanged: (v) => setState(() => _mode = v),
          ),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            onPressed: _run,
            icon: const Icon(Icons.auto_awesome),
            label: Text(context.tr('summarize')),
          ),
          if (_current != null) ...[
            const SizedBox(height: 22),
            SummaryView(
              item: _current!,
              onDelete: () {
                s.deleteSummary(_current!);
                setState(() => _current = null);
              },
            ).animate().fadeIn(duration: 450.ms).slideY(begin: 0.1, end: 0),
          ],
          const SizedBox(height: 26),
          SectionTitle(context.tr('my_summaries')),
          if (s.summaries.isEmpty)
            EmptyState(
                icon: Icons.menu_book_rounded,
                illus: 'notes',
                text: context.tr('no_summaries'))
          else
            for (final it in s.summaries)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: PaperCard(
                  onTap: () => Navigator.push(
                      context, slideRoute(SummaryDetailScreen(item: it))),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                            color: C.ink, borderRadius: BorderRadius.circular(14)),
                        child: Icon(
                            it.mode == 'cards'
                                ? Icons.style_rounded
                                : Icons.article_rounded,
                            color: C.cream),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(it.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 15.5)),
                            const SizedBox(height: 2),
                            Text(
                                '${it.source.isEmpty ? '' : '${it.source} · '}${fmtDate(it.createdAt)}',
                                style: const TextStyle(color: C.grey, fontSize: 12.5)),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right_rounded, color: C.grey),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }

  Widget _input(BuildContext context) {
    switch (_src) {
      case 'text':
        return TextField(
          controller: _text,
          minLines: 5,
          maxLines: 10,
          decoration: InputDecoration(hintText: context.tr('sum_text_hint')),
        );
      case 'pdf':
        return _pdfName == null
            ? OutlinedButton.icon(
                onPressed: _pickPdf,
                icon: const Icon(Icons.picture_as_pdf_rounded),
                label: Text(context.tr('choose_pdf')),
              )
            : PaperCard(
                child: Row(
                  children: [
                    const Icon(Icons.picture_as_pdf_rounded),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_pdfName!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800)),
                          Text('${_pdfText?.length ?? 0} ${context.tr('chars')}',
                              style: const TextStyle(color: C.grey, fontSize: 12.5)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.swap_horiz_rounded),
                      onPressed: _pickPdf,
                    ),
                  ],
                ),
              );
      case 'image':
        return Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _addImages(true),
                    icon: const Icon(Icons.photo_camera_rounded),
                    label: Text(context.tr('camera')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _addImages(false),
                    icon: const Icon(Icons.photo_library_rounded),
                    label: Text(context.tr('gallery')),
                  ),
                ),
              ],
            ),
            if (_images.isNotEmpty) ...[
              const SizedBox(height: 12),
              SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _images.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) => Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(_images[i],
                            width: 92, height: 92, fit: BoxFit.cover),
                      ),
                      PositionedDirectional(
                        top: 4,
                        end: 4,
                        child: GestureDetector(
                          onTap: () => setState(() => _images.removeAt(i)),
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: const BoxDecoration(
                                color: C.ink, shape: BoxShape.circle),
                            child: const Icon(Icons.close, size: 14, color: C.cream),
                          ),
                        ),
                      ),
                    ],
                  ).animate().fadeIn().scale(
                      begin: const Offset(0.8, 0.8), end: const Offset(1, 1)),
                ),
              ),
            ],
          ],
        );
      default:
        return TextField(
          controller: _yt,
          keyboardType: TextInputType.url,
          decoration: InputDecoration(
            hintText: 'https://youtube.com/watch?v=...',
            prefixIcon: const Icon(Icons.smart_display_rounded),
            suffixIcon: IconButton(
              icon: const Icon(Icons.content_paste_rounded),
              onPressed: _paste,
            ),
          ),
        );
    }
  }
}

/// Shows one summary (text or flashcards) with copy / share / quiz actions.
class SummaryView extends StatelessWidget {
  const SummaryView({super.key, required this.item, this.onDelete});
  final SummaryItem item;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    return PaperCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(item.title,
                    style: const TextStyle(
                        fontSize: 21, fontWeight: FontWeight.w900, height: 1.3)),
              ),
              IconButton(
                tooltip: context.tr('copy'),
                icon: const Icon(Icons.copy_rounded),
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: item.plainText));
                  if (context.mounted) toast(context, context.trr('copied'));
                },
              ),
              IconButton(
                tooltip: context.tr('share'),
                icon: const Icon(Icons.ios_share_rounded),
                onPressed: () => Share.share(item.plainText, subject: item.title),
              ),
            ],
          ),
          const Divider(height: 20),
          if (item.mode == 'cards')
            FlashDeck(cards: item.cards)
          else
            FormattedText(item.body),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    slideRoute(CreateQuizScreen(initialText: item.plainText)),
                  ),
                  icon: const Icon(Icons.quiz_rounded),
                  label: Text(context.tr('quiz_from_this')),
                ),
              ),
              if (onDelete != null) ...[
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded, color: C.bad),
                  onPressed: () async {
                    if (await confirm(context, context.trr('delete_confirm'))) {
                      onDelete!();
                    }
                  },
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class SummaryDetailScreen extends StatelessWidget {
  const SummaryDetailScreen({super.key, required this.item});
  final SummaryItem item;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('summary'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          SummaryView(
            item: item,
            onDelete: () {
              context.read<AppState>().deleteSummary(item);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}

/// Swipeable deck of flip cards.
class FlashDeck extends StatefulWidget {
  const FlashDeck({super.key, required this.cards});
  final List<Map<String, String>> cards;

  @override
  State<FlashDeck> createState() => _FlashDeckState();
}

class _FlashDeckState extends State<FlashDeck> {
  final PageController _pc = PageController(viewportFraction: 0.94);
  int _i = 0;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 240,
          child: PageView.builder(
            controller: _pc,
            itemCount: widget.cards.length,
            onPageChanged: (v) => setState(() => _i = v),
            itemBuilder: (_, i) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: FlipCard(
                front: widget.cards[i]['front'] ?? '',
                back: widget.cards[i]['back'] ?? '',
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text('${_i + 1} / ${widget.cards.length}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(context.tr('tap_flip'),
            style: const TextStyle(color: C.grey, fontSize: 12.5)),
      ],
    );
  }
}

class FlipCard extends StatefulWidget {
  const FlipCard({super.key, required this.front, required this.back});
  final String front;
  final String back;

  @override
  State<FlipCard> createState() => _FlipCardState();
}

class _FlipCardState extends State<FlipCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 450));
  bool _front = true;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _flip() {
    if (_front) {
      _c.forward();
    } else {
      _c.reverse();
    }
    _front = !_front;
  }

  Widget _face(String text, bool back) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      padding: const EdgeInsets.all(20),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: back ? C.paper : C.ink,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: C.ink, width: 1.6),
      ),
      child: SingleChildScrollView(
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: back ? C.ink : C.cream,
            fontSize: back ? 17 : 20,
            fontWeight: back ? FontWeight.w600 : FontWeight.w800,
            height: 1.5,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _flip,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final v = _c.value;
          final showBack = v > 0.5;
          return Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(v * math.pi),
            child: showBack
                ? Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.rotationY(math.pi),
                    child: _face(widget.back, true),
                  )
                : _face(widget.front, false),
          );
        },
      ),
    );
  }
}
