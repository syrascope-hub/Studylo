import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'exam_screen.dart';

class ProgressTab extends StatelessWidget {
  const ProgressTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final recent = s.attempts.length > 7
        ? s.attempts.sublist(s.attempts.length - 7)
        : s.attempts;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          ScreenHeader(
              title: context.tr('progress_title'),
              subtitle: context.tr('progress_sub')),
          Row(
            children: [
              Expanded(
                  child: _Stat(
                      icon: Icons.local_fire_department_rounded,
                      value: '${s.streak}',
                      label: context.tr('st_streak'),
                      dark: true)),
              const SizedBox(width: 10),
              Expanded(
                  child: _Stat(
                      icon: Icons.task_alt_rounded,
                      value: '${s.attempts.length}',
                      label: context.tr('st_quizzes'))),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                  child: _Stat(
                      icon: Icons.percent_rounded,
                      value: '${s.avgPercent.round()}%',
                      label: context.tr('st_avg'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _Stat(
                      icon: Icons.error_outline_rounded,
                      value: '${s.mistakes.length}',
                      label: context.tr('st_mistakes'))),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                  child: _Stat(
                      icon: Icons.timer_rounded,
                      value: '${s.focusTotal}',
                      label: context.tr('f_total'))),
              const SizedBox(width: 10),
              Expanded(
                  child: _Stat(
                      icon: Icons.eco_rounded,
                      value: '${s.grownCount}',
                      label: context.tr('f_plants'))),
            ],
          ),
          const SizedBox(height: 22),
          SectionTitle(context.tr('last_results')),
          PaperCard(
            padding: const EdgeInsets.fromLTRB(14, 18, 14, 12),
            child: recent.isEmpty
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 24),
                    child: Center(
                      child: Text(context.tr('no_results'),
                          style: const TextStyle(color: C.grey)),
                    ),
                  )
                : SizedBox(
                    height: 150,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        for (final a in recent)
                          Expanded(child: _Bar(percent: a.percent)),
                      ],
                    ),
                  ),
          ),
          const SizedBox(height: 22),
          PaperCard(
            color: C.ink,
            borderColor: C.ink,
            onTap: () => Navigator.push(
                context, slideRoute(const MistakesScreen())),
            child: Row(
              children: [
                const Icon(Icons.fact_check_rounded, color: C.cream, size: 30),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(context.tr('mistakes_bank'),
                          style: const TextStyle(
                              color: C.cream,
                              fontWeight: FontWeight.w900,
                              fontSize: 17)),
                      Text('${s.mistakes.length} ${context.tr('questions_word')}',
                          style: TextStyle(color: C.cream.withAlpha(190))),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: C.cream),
              ],
            ),
          ),
          if (s.attempts.isNotEmpty) ...[
            const SizedBox(height: 22),
            SectionTitle(context.tr('history')),
            for (final a in s.attempts.reversed.take(10))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: PaperCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(a.quizTitle,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                            Text(fmtDate(a.date),
                                style: const TextStyle(color: C.grey, fontSize: 12.5)),
                          ],
                        ),
                      ),
                      Text('${a.percent.round()}%',
                          style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 17,
                              color: a.percent >= 70
                                  ? C.good
                                  : (a.percent >= 50 ? C.warn : C.bad))),
                    ],
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({
    required this.icon,
    required this.value,
    required this.label,
    this.dark = false,
  });
  final IconData icon;
  final String value;
  final String label;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final fg = dark ? C.cream : C.ink;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: dark ? C.ink : C.paper,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: dark ? C.ink : C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: fg, size: 26),
          const SizedBox(height: 10),
          Text(value,
              style: TextStyle(color: fg, fontSize: 30, fontWeight: FontWeight.w900, height: 1)),
          const SizedBox(height: 4),
          Text(label,
              style: TextStyle(color: fg.withAlpha(180), fontSize: 13, fontWeight: FontWeight.w700)),
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).scale(
        begin: const Offset(0.92, 0.92), end: const Offset(1, 1), duration: 400.ms);
  }
}

class _Bar extends StatelessWidget {
  const _Bar({required this.percent});
  final double percent;

  @override
  Widget build(BuildContext context) {
    final col = percent >= 70 ? C.ink : C.grey;
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Text('${percent.round()}',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0, end: percent / 100 * 100),
          duration: const Duration(milliseconds: 800),
          curve: Curves.easeOutCubic,
          builder: (_, v, __) => Container(
            width: 22,
            height: v + 4,
            decoration: BoxDecoration(
              color: col,
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ],
    );
  }
}

class MistakesScreen extends StatelessWidget {
  const MistakesScreen({super.key});

  void _retry(BuildContext context, List<Mistake> list) {
    final qs = list.take(15).map((m) => m.question.withRef(m.id)).toList()
      ..sort((a, b) => Question.rank(a.type).compareTo(Question.rank(b.type)));
    final quiz = Quiz(
      id: newId(),
      title: context.trr('mistakes_bank'),
      questions: qs,
      createdAt: DateTime.now(),
    );
    Navigator.push(context, slideRoute(ExamScreen(quiz: quiz)));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final letters = context.tr('letters').split(',');
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('mistakes_bank'))),
      body: s.mistakes.isEmpty
          ? Center(
              child: EmptyState(
                  icon: Icons.celebration_rounded,
                  illus: 'e_target',
                  text: context.tr('no_mistakes')))
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              children: [
                ElevatedButton.icon(
                  onPressed: () => _retry(context, s.mistakes),
                  icon: const Icon(Icons.replay_rounded),
                  label: Text(context.tr('test_my_mistakes')),
                ),
                const SizedBox(height: 16),
                for (final m in s.mistakes)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Dismissible(
                      key: ValueKey(m.id),
                      direction: DismissDirection.horizontal,
                      onDismissed: (_) => s.removeMistake(m.id),
                      background: Container(
                        decoration: BoxDecoration(
                            color: C.bad, borderRadius: BorderRadius.circular(18)),
                        alignment: Alignment.center,
                        child: const Icon(Icons.delete_rounded, color: Colors.white),
                      ),
                      child: PaperCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(m.question.text,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 15.5, height: 1.5)),
                            if (m.userAnswer.isNotEmpty) ...[
                              const SizedBox(height: 8),
                              _line(context.tr('your_answer'), m.userAnswer, C.bad),
                            ],
                            const SizedBox(height: 6),
                            _line(
                              context.tr('correct_answer'),
                              m.question.isMcq
                                  ? '${m.question.correct < letters.length ? letters[m.question.correct] : ''}) ${m.question.options[m.question.correct]}'
                                  : m.question.modelAnswer,
                              C.good,
                            ),
                            if (m.feedback.isNotEmpty) ...[
                              const SizedBox(height: 6),
                              Text(m.feedback,
                                  style: const TextStyle(color: C.grey, height: 1.5, fontSize: 13.5)),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }

  Widget _line(String label, String text, Color c) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ',
              style: TextStyle(color: c, fontWeight: FontWeight.w900, fontSize: 13.5)),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14, height: 1.45))),
        ],
      );
}
