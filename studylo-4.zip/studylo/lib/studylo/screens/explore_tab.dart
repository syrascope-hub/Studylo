import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../illus.dart';
import '../theme.dart';
import '../ui.dart';
import 'courses_tab.dart';
import 'home_shell.dart';
import 'progress_tab.dart';
import 'quizzes_tab.dart';
import 'summary_tab.dart';

/// Wraps a tab screen so it can be opened as a normal page with a back button.
class SubPage extends StatelessWidget {
  const SubPage({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: child,
    );
  }
}

class ExploreTab extends StatelessWidget {
  const ExploreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = <_Cat>[
      _Cat('cat_quizzes', 'quizzes',
          () => _open(context, const QuizzesTab())),
      _Cat('cat_summary', 'notes',
          () => _open(context, const SummaryTab())),
      _Cat('cat_courses', 'subjects',
          () => _open(context, const CoursesTab())),
      _Cat('cat_mistakes', 'tasks',
          () => Navigator.push(context, slideRoute(const MistakesScreen()))),
      _Cat('cat_stats', 'progress', () => homeTab.value = 4),
      _Cat('cat_key', 'smart', () => homeTab.value = 5),
    ];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
        children: [
          Text(context.tr('explore'),
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900))
              .animate()
              .fadeIn(duration: 400.ms)
              .slideY(begin: -0.2, end: 0),
          const SizedBox(height: 16),
          _FocusBanner(onTap: () => homeTab.value = 3)
              .animate(delay: 60.ms)
              .fadeIn(duration: 380.ms)
              .slideY(begin: 0.1, end: 0),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: C.paper,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: C.line),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withAlpha(18),
                    blurRadius: 22,
                    offset: const Offset(0, 8)),
              ],
            ),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.92,
              children: [
                for (var i = 0; i < cats.length; i++)
                  _CatCard(cat: cats[i], seed: i)
                      .animate(delay: (80 * i).ms)
                      .fadeIn(duration: 350.ms)
                      .scale(
                          begin: const Offset(0.9, 0.9),
                          end: const Offset(1, 1),
                          duration: 350.ms,
                          curve: Curves.easeOutBack),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _open(BuildContext context, Widget page) =>
      Navigator.push(context, slideRoute(SubPage(child: page)));
}

class _Cat {
  _Cat(this.titleKey, this.img, this.onTap);
  final String titleKey;
  final String img;
  final VoidCallback onTap;
}

class _CatCard extends StatelessWidget {
  const _CatCard({required this.cat, required this.seed});
  final _Cat cat;
  final int seed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withAlpha(150),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: cat.onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: C.line.withAlpha(140)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(context.tr(cat.titleKey),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w800)),
              Expanded(
                child: Center(
                  child: IllusImg(cat.img, size: 98),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _FocusBanner extends StatelessWidget {
  const _FocusBanner({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: C.ink,
      borderRadius: BorderRadius.circular(28),
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 12, 16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(context.tr('focus_title'),
                        style: const TextStyle(
                            color: C.cream,
                            fontSize: 20,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text(context.tr('focus_sub'),
                        style: TextStyle(
                            color: C.cream.withAlpha(200),
                            fontSize: 13,
                            height: 1.4)),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: C.cream,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.play_arrow_rounded,
                              size: 18, color: C.ink),
                          const SizedBox(width: 4),
                          Text(context.tr('f_open'),
                              style: const TextStyle(
                                  color: C.ink,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const IllusImg('focus', size: 118, float: true),
            ],
          ),
        ),
      ),
    );
  }
}
