import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../state.dart';
import '../theme.dart';
import '../ui.dart';
import 'home_shell.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2700), () {
      if (!mounted) return;
      final done = context.read<AppState>().onboarded;
      Navigator.of(context).pushReplacement(PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, __, ___) =>
            done ? const HomeShell() : const WelcomeScreen(),
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // soft floating circles
          Positioned(
            top: -90,
            right: -70,
            child: _Blob(size: 260, color: C.creamDark),
          ),
          Positioned(
            bottom: -110,
            left: -80,
            child: _Blob(size: 300, color: C.creamDark),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const StudyLogo(size: 112)
                    .animate()
                    .fadeIn(duration: 300.ms)
                    .scale(
                      begin: const Offset(0.2, 0.2),
                      end: const Offset(1, 1),
                      duration: 800.ms,
                      curve: Curves.elasticOut,
                    )
                    .then(delay: 300.ms)
                    .shake(hz: 2, duration: 500.ms, rotation: 0.05),
                const SizedBox(height: 26),
                const Typewriter(
                  text: 'Studylo',
                  delay: Duration(milliseconds: 600),
                  duration: Duration(milliseconds: 900),
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    color: C.ink,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  context.tr('tagline'),
                  style: const TextStyle(color: C.grey, fontSize: 16),
                ).animate().fadeIn(delay: 1500.ms, duration: 600.ms).slideY(begin: 0.4, end: 0),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({required this.size, required this.color});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    )
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scale(
          begin: const Offset(0.92, 0.92),
          end: const Offset(1.08, 1.08),
          duration: 2600.ms,
          curve: Curves.easeInOut,
        );
  }
}
