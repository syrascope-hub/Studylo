import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/ai.dart';
import '../services/notify.dart';
import '../services/sfx.dart';
import '../services/tts.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _key;
  late final TextEditingController _model;
  late final TextEditingController _base;
  bool _show = false;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>().settings;
    _key = TextEditingController(text: s.apiKey);
    _model = TextEditingController(text: s.model);
    _base = TextEditingController(text: s.baseUrl);
  }

  @override
  void dispose() {
    _key.dispose();
    _model.dispose();
    _base.dispose();
    super.dispose();
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 8),
        child: Text(t,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      );

  Widget _drop<T>(Pal p, T value, Map<T, String> items, void Function(T) on) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.line, width: 2),
      ),
      child: DropdownButton<T>(
        value: value,
        isExpanded: true,
        underline: const SizedBox.shrink(),
        dropdownColor: p.surface,
        items: [
          for (final e in items.entries)
            DropdownMenuItem<T>(value: e.key, child: Text(e.value)),
        ],
        onChanged: (v) {
          if (v != null) on(v);
        },
      ),
    );
  }

  Future<void> _testAi(AppState app) async {
    setState(() => _testing = true);
    try {
      final r = await app.ai.ask(
          history: [ChatMsg('user', 'قل: تم الاتصال بنجاح')], system: '');
      if (mounted) toast(context, '✓ $r');
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final app = context.watch<AppState>();
    final s = app.settings;

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
        children: [
          _section('الذكاء الاصطناعي'),
          _drop<String>(
            p,
            s.provider,
            {for (final e in presets.entries) e.key: e.value.name},
            (v) {
              s.provider = v;
              final pr = presets[v]!;
              if (v != 'custom') {
                s.baseUrl = pr.base;
                s.model = pr.model;
                _base.text = pr.base;
                _model.text = pr.model;
              }
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _key,
            obscureText: !_show,
            autocorrect: false,
            decoration: InputDecoration(
              hintText: 'مفتاح API',
              suffixIcon: IconButton(
                icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => _show = !_show),
              ),
            ),
            onChanged: (v) {
              s.apiKey = v.trim();
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _model,
            autocorrect: false,
            decoration: const InputDecoration(hintText: 'اسم النموذج'),
            onChanged: (v) {
              s.model = v.trim();
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _base,
            autocorrect: false,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(hintText: 'عنوان الخادم (Base URL)'),
            onChanged: (v) {
              s.baseUrl = v.trim();
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _testing ? null : () => _testAi(app),
            icon: _testing
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.bolt_rounded),
            label: const Text('اختبار الاتصال'),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'المفتاح يُحفظ على جهازك فقط ويُرسل مباشرة إلى المزوّد الذي تختاره.',
              style: TextStyle(color: p.muted, fontSize: 12),
            ),
          ),
          _section('الصوت'),
          _drop<String>(
            p,
            s.ttsEngine,
            const {
              'device': 'صوت الجهاز',
              'google': 'Google (عصبي، يحتاج إنترنت)',
              'openai': 'OpenAI TTS (يحتاج مفتاح OpenAI)',
            },
            (v) {
              s.ttsEngine = v;
              app.saveSettings();
            },
          ),
          const SizedBox(height: 10),
          _drop<String>(
            p,
            s.ttsLang,
            const {
              'en-US': 'English (US)',
              'en-GB': 'English (UK)',
              'ar-SA': 'العربية',
              'fr-FR': 'Français',
              'es-ES': 'Español',
              'de-DE': 'Deutsch',
              'tr-TR': 'Türkçe',
              'it-IT': 'Italiano',
            },
            (v) {
              s.ttsLang = v;
              app.saveSettings();
            },
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Text('السرعة'),
              Expanded(
                child: Slider(
                  value: s.ttsRate,
                  min: 0.2,
                  max: 0.8,
                  onChanged: (v) {
                    s.ttsRate = v;
                    app.saveSettings();
                  },
                ),
              ),
            ],
          ),
          OutlinedButton.icon(
            onPressed: () => Tts.i
                .speak('Hello, this is a voice test.', s, lang: s.ttsLang)
                .catchError((_) {}),
            icon: const Icon(Icons.volume_up_rounded),
            label: const Text('تجربة الصوت'),
          ),
          _section('المؤثرات الصوتية'),
          SoftCard(
            shadow: false,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: ValueListenableBuilder<bool>(
              valueListenable: Sfx.enabled,
              builder: (_, on, __) => Row(
                children: [
                  const Expanded(child: Text('أصوات الإجابة والإنجاز')),
                  Switch(
                    value: on,
                    onChanged: (v) {
                      Sfx.setEnabled(v);
                      if (v) Sfx.play('correct');
                    },
                  ),
                ],
              ),
            ),
          ),
          _section('الإشعارات'),
          SoftCard(
            shadow: false,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Column(
              children: [
                Row(
                  children: [
                    const Expanded(child: Text('تذكير يومي بكلمة اليوم')),
                    Switch(
                      value: s.notifOn,
                      onChanged: (v) async {
                        s.notifOn = v;
                        await app.saveSettings(reschedule: true);
                      },
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Expanded(child: Text('الوقت')),
                    TextButton(
                      onPressed: () async {
                        final t = await showTimePicker(
                          context: context,
                          initialTime:
                              TimeOfDay(hour: s.notifH, minute: s.notifM),
                        );
                        if (t != null) {
                          s.notifH = t.hour;
                          s.notifM = t.minute;
                          await app.saveSettings(reschedule: true);
                        }
                      },
                      child: Text(
                          '${s.notifH.toString().padLeft(2, '0')}:${s.notifM.toString().padLeft(2, '0')}',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () async {
              try {
                await Notify.init();
                await Notify.test();
              } catch (e) {
                if (mounted) toast(context, 'تعذّر إرسال الإشعار');
              }
            },
            icon: const Icon(Icons.notifications_active_outlined),
            label: const Text('إرسال إشعار تجريبي'),
          ),
          _section('بومودورو'),
          Row(
            children: [
              const SizedBox(width: 90, child: Text('التركيز')),
              Expanded(
                child: Slider(
                  value: s.workMin.toDouble(),
                  min: 5,
                  max: 90,
                  divisions: 17,
                  label: '${s.workMin} د',
                  onChanged: (v) {
                    s.workMin = v.round();
                    app.saveSettings();
                  },
                ),
              ),
              Text('${s.workMin} د'),
            ],
          ),
          Row(
            children: [
              const SizedBox(width: 90, child: Text('الاستراحة')),
              Expanded(
                child: Slider(
                  value: s.breakMin.toDouble(),
                  min: 1,
                  max: 30,
                  divisions: 29,
                  label: '${s.breakMin} د',
                  onChanged: (v) {
                    s.breakMin = v.round();
                    app.saveSettings();
                  },
                ),
              ),
              Text('${s.breakMin} د'),
            ],
          ),
          _section('المظهر'),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'system', label: Text('تلقائي')),
              ButtonSegment(value: 'light', label: Text('فاتح')),
              ButtonSegment(value: 'dark', label: Text('داكن')),
            ],
            selected: {s.theme},
            showSelectedIcon: false,
            onSelectionChanged: (v) {
              s.theme = v.first;
              app.saveSettings();
            },
          ),
        ],
      ),
    );
  }
}
