import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../art/character.dart';
import '../models.dart';
import '../services/ai.dart';
import '../services/tts.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

/// واجهة محادثة قابلة لإعادة الاستخدام (المحادثة + فاينمان).
class ChatPane extends StatefulWidget {
  const ChatPane({
    super.key,
    required this.messages,
    required this.onSend,
    required this.busy,
    this.hint = 'اكتب رسالتك...',
    this.emptyText = 'ابدأ المحادثة، اسأل عن أي شيء!',
  });

  final List<ChatMsg> messages;
  final Future<void> Function(String) onSend;
  final bool busy;
  final String hint;
  final String emptyText;

  @override
  State<ChatPane> createState() => _ChatPaneState();
}

class _ChatPaneState extends State<ChatPane> {
  final _c = TextEditingController();
  final _scroll = ScrollController();

  @override
  void didUpdateWidget(covariant ChatPane old) {
    super.didUpdateWidget(old);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  @override
  void dispose() {
    _c.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final t = _c.text.trim();
    if (t.isEmpty || widget.busy) return;
    _c.clear();
    widget.onSend(t);
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final msgs = widget.messages;
    return Column(
      children: [
        Expanded(
          child: msgs.isEmpty && !widget.busy
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Character(pose: Pose.chat, height: 190),
                      const SizedBox(height: 6),
                      Text(widget.emptyText, style: TextStyle(color: p.muted)),
                    ],
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  itemCount: msgs.length + (widget.busy ? 1 : 0),
                  itemBuilder: (ctx, i) {
                    if (i >= msgs.length) return const _TypingBubble();
                    return _Bubble(msgs[i]);
                  },
                ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _c,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(hintText: widget.hint),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: widget.busy ? null : _send,
                icon: const Icon(Icons.arrow_upward_rounded),
                style: IconButton.styleFrom(
                  fixedSize: const Size(52, 52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: p.line, width: 2),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble(this.m);
  final ChatMsg m;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final user = m.isUser;
    return Align(
      alignment:
          user ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        decoration: BoxDecoration(
          color: user ? p.accent : p.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: p.line, width: 2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SelectableText(
              m.text,
              textDirection: dirOf(m.text),
              style: TextStyle(
                  color: user ? p.onAccent : p.text, fontSize: 15.5, height: 1.45),
            ),
            if (!user)
              InkWell(
                onTap: () {
                  final s = context.read<AppState>().settings;
                  Tts.i.speak(m.text, s).catchError((_) {});
                },
                child: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Icon(Icons.volume_up_rounded, size: 20, color: p.muted),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TypingBubble extends StatefulWidget {
  const _TypingBubble();
  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
        ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: p.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: p.line, width: 2),
        ),
        child: AnimatedBuilder(
          animation: _c,
          builder: (ctx, _) => Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (var i = 0; i < 3; i++)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: 8,
                  height: 8,
                  transform: Matrix4.translationValues(
                      0, math.sin(_c.value * 2 * math.pi + i * 0.8) * 4, 0),
                  decoration: BoxDecoration(color: p.muted, shape: BoxShape.circle),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class ChatTab extends StatefulWidget {
  const ChatTab({super.key});
  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  bool _busy = false;

  Future<void> _send(String text) async {
    final app = context.read<AppState>();
    if (!app.ai.ready) {
      toast(context, 'أضف مفتاح API من الإعدادات أولاً');
      return;
    }
    app.addChat(ChatMsg('user', text));
    setState(() => _busy = true);
    try {
      final hist = app.chat.length > 20
          ? app.chat.sublist(app.chat.length - 20)
          : List<ChatMsg>.from(app.chat);
      final r = await app.ai.ask(history: hist, system: AiService.chatSystem);
      app.addChat(ChatMsg('assistant', r));
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TabHeader(
              title: 'المحادثة',
              subtitle: 'اسأل مساعدك الدراسي',
              trailing: app.chat.isEmpty
                  ? null
                  : IconButton(
                      tooltip: 'مسح المحادثة',
                      icon: const Icon(Icons.delete_sweep_outlined),
                      onPressed: app.clearChat,
                    ),
            ),
          ),
          Expanded(
            child: ChatPane(
              messages: app.chat,
              onSend: _send,
              busy: _busy,
            ),
          ),
        ],
      ),
    );
  }
}
