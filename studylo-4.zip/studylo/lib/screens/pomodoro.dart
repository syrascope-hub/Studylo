import 'dart:async';
import 'dart:math';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../art/plant.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class PomodoroTab extends StatefulWidget {
  const PomodoroTab({super.key});
  @override
  State<PomodoroTab> createState() => _PomodoroTabState();
}

class _PomodoroTabState extends State<PomodoroTab> with WidgetsBindingObserver {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      context.read<AppState>().pomoTick();
      setState(() {});
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      context.read<AppState>().pomoTick();
      setState(() {});
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _t?.cancel();
    super.dispose();
  }

  String _fmt(int ms) {
    final s = (ms / 1000).ceil();
    final m = s ~/ 60;
    final r = s % 60;
    return '${m.toString().padLeft(2, '0')}:${r.toString().padLeft(2, '0')}';
  }

  Future<void> _cancel(AppState app) async {
    if (app.pomo.phase == 'break') {
      await app.cancelPomo();
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('إلغاء الجلسة؟'),
        content: const Text('إن غادرت الآن ستذبل نبتتك 🥀'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(d, false),
              child: const Text('أكمل التركيز')),
          FilledButton(
              onPressed: () => Navigator.pop(d, true), child: const Text('إلغاء')),
        ],
      ),
    );
    if (ok == true) await app.cancelPomo();
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final app = context.watch<AppState>();
    final po = app.pomo;
    final running = po.phase != 'idle';
    final label = po.phase == 'work'
        ? 'تركيز'
        : po.phase == 'break'
            ? 'استراحة'
            : po.last == 'work'
                ? 'ازدهرت نبتتك 🌸'
                : po.last == 'wilt'
                    ? 'ذبلت النبتة 🥀'
                    : 'جاهز للزراعة';
    final timeText = running
        ? _fmt(app.pomoRemainingMs)
        : _fmt(app.settings.workMin * 60000);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        const Pop(child: TabHeader(title: 'بومودورو', subtitle: 'ازرع نبتة بتركيزك')),
        const SizedBox(height: 8),
        SoftCard(
          color: p.soft,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: p.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: p.line, width: 2),
                ),
                child: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 6),
              PlantView(
                growth: app.plantGrowth,
                wilt: app.plantWilt,
                height: 250,
              ),
              Text(timeText,
                  style: const TextStyle(
                      fontSize: 52,
                      fontWeight: FontWeight.w900,
                      fontFeatures: [FontFeature.tabularFigures()])),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (!running) ...[
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 8,
            children: [
              for (final m in [15, 25, 40, 50])
                ChoiceChip(
                  label: Text('$m د'),
                  selected: app.settings.workMin == m,
                  showCheckmark: false,
                  selectedColor: p.accent,
                  onSelected: (_) {
                    app.settings.workMin = m;
                    app.saveSettings();
                  },
                ),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => app.startPomo('work'),
            icon: const Icon(Icons.eco_rounded),
            label: const Text('ازرع وابدأ التركيز'),
          ),
          if (po.last == 'work') ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => app.startPomo('break'),
              icon: const Icon(Icons.coffee_rounded),
              label: Text('استراحة ${app.settings.breakMin} دقائق'),
            ),
          ],
        ] else
          OutlinedButton.icon(
            onPressed: () => _cancel(app),
            icon: const Icon(Icons.close_rounded),
            label: Text(po.phase == 'work' ? 'إلغاء (ستذبل النبتة)' : 'تخطي الاستراحة'),
          ),
        const SizedBox(height: 22),
        Row(
          children: [
            const Text('حديقتي',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const Spacer(),
            Text('🌸 ${po.grown}   🥀 ${po.wilted}',
                style: const TextStyle(fontSize: 16)),
          ],
        ),
        const SizedBox(height: 10),
        if (po.grown == 0)
          Text('أكمل جلسة تركيز لتنمو أول نبتة في حديقتك.',
              style: TextStyle(color: p.muted))
        else
          Wrap(
            spacing: 4,
            runSpacing: 4,
            children: [
              for (var i = 0; i < min(po.grown, 24); i++)
                const PlantView(growth: 1, height: 64, animate: false),
            ],
          ),
      ],
    );
  }
}
