import 'package:flutter/material.dart';

import '../services/sfx.dart';
import '../studylo/section.dart';
import '../theme.dart';
import 'chat.dart';
import 'create.dart';
import 'pomodoro.dart';
import 'study.dart';
import 'words.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  static const _items = [
    (Icons.style_rounded, 'بطاقات'),
    (Icons.format_list_bulleted_rounded, 'كلماتي'),
    (Icons.auto_stories_rounded, 'دراسة'),
    (Icons.local_florist_rounded, 'تركيز'),
    (Icons.chat_bubble_rounded, 'محادثة'),
    (Icons.school_rounded, 'Studylo'),
  ];

  // آخر عنصر يفتح قسم Studylo بملء الشاشة بدل تبديل التبويب.
  static const _studyloIndex = 5;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _i,
          children: const [
            CreateTab(),
            WordsTab(),
            StudyTab(),
            PomodoroTab(),
            ChatTab(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: p.surface,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: p.line, width: 2),
              boxShadow: [BoxShadow(color: p.line, offset: const Offset(3, 3))],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var k = 0; k < _items.length; k++)
                  _NavItem(
                    icon: _items[k].$1,
                    label: _items[k].$2,
                    selected: k == _i,
                    onTap: () {
                      Sfx.play('tap');
                      if (k == _studyloIndex) {
                        Navigator.of(context).push(MaterialPageRoute<void>(
                            builder: (_) => const StudyloSection()));
                      } else {
                        setState(() => _i = k);
                      }
                    },
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(horizontal: selected ? 12 : 8, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? p.accent : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
              color: selected ? p.line : Colors.transparent, width: 2),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 24, color: selected ? p.onAccent : p.muted),
            AnimatedSize(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              child: selected
                  ? Padding(
                      padding: const EdgeInsetsDirectional.only(start: 6),
                      child: Text(label,
                          style: TextStyle(
                              color: p.onAccent,
                              fontWeight: FontWeight.w800,
                              fontSize: 13)),
                    )
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }
}
