import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../models.dart';

class AiException implements Exception {
  AiException(this.msg);
  final String msg;
  @override
  String toString() => msg;
}

class Preset {
  const Preset(this.name, this.base, this.model);
  final String name, base, model;
}

const presets = <String, Preset>{
  'openai': Preset('OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'),
  'gemini': Preset('Gemini',
      'https://generativelanguage.googleapis.com/v1beta/openai', 'gemini-2.5-flash'),
  'claude': Preset('Claude', 'https://api.anthropic.com/v1', 'claude-haiku-5-5'),
  'openrouter':
      Preset('OpenRouter', 'https://openrouter.ai/api/v1', 'openai/gpt-4o-mini'),
  'custom': Preset('مخصص (متوافق مع OpenAI)', '', ''),
};

class AiService {
  AiService(this.s);
  final Settings s;

  bool get ready => s.apiKey.trim().isNotEmpty;

  Future<String> ask({
    required List<ChatMsg> history,
    String system = '',
    Uint8List? image,
  }) async {
    if (!ready) throw AiException('أضف مفتاح API من الإعدادات أولاً');
    try {
      return s.provider == 'claude'
          ? await _claude(history, system, image)
          : await _openai(history, system, image);
    } on AiException {
      rethrow;
    } catch (e) {
      throw AiException('تعذّر الاتصال: $e');
    }
  }

  String _base() => s.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');

  Future<String> _openai(
      List<ChatMsg> history, String system, Uint8List? image) async {
    final msgs = <Map<String, dynamic>>[];
    if (system.isNotEmpty) msgs.add({'role': 'system', 'content': system});
    for (var i = 0; i < history.length; i++) {
      final m = history[i];
      final isLast = i == history.length - 1;
      if (image != null && isLast && m.isUser) {
        msgs.add({
          'role': 'user',
          'content': [
            {'type': 'text', 'text': m.text},
            {
              'type': 'image_url',
              'image_url': {'url': 'data:image/jpeg;base64,${base64Encode(image)}'}
            },
          ],
        });
      } else {
        msgs.add({'role': m.role, 'content': m.text});
      }
    }
    final r = await http
        .post(
          Uri.parse('${_base()}/chat/completions'),
          headers: {
            'Authorization': 'Bearer ${s.apiKey.trim()}',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({'model': s.model, 'messages': msgs}),
        )
        .timeout(const Duration(seconds: 90));
    final body = utf8.decode(r.bodyBytes);
    if (r.statusCode >= 300) throw AiException(_err(body, r.statusCode));
    final j = jsonDecode(body) as Map<String, dynamic>;
    final content = j['choices'][0]['message']['content'];
    return (content ?? '').toString().trim();
  }

  Future<String> _claude(
      List<ChatMsg> history, String system, Uint8List? image) async {
    final msgs = <Map<String, dynamic>>[];
    for (var i = 0; i < history.length; i++) {
      final m = history[i];
      final isLast = i == history.length - 1;
      if (image != null && isLast && m.isUser) {
        msgs.add({
          'role': 'user',
          'content': [
            {
              'type': 'image',
              'source': {
                'type': 'base64',
                'media_type': 'image/jpeg',
                'data': base64Encode(image),
              },
            },
            {'type': 'text', 'text': m.text},
          ],
        });
      } else {
        msgs.add({'role': m.role, 'content': m.text});
      }
    }
    final base = _base().isEmpty ? 'https://api.anthropic.com/v1' : _base();
    final r = await http
        .post(
          Uri.parse('$base/messages'),
          headers: {
            'x-api-key': s.apiKey.trim(),
            'anthropic-version': '2023-06-01',
            'Content-Type': 'application/json',
          },
          body: jsonEncode({
            'model': s.model,
            'max_tokens': 2048,
            if (system.isNotEmpty) 'system': system,
            'messages': msgs,
          }),
        )
        .timeout(const Duration(seconds: 90));
    final body = utf8.decode(r.bodyBytes);
    if (r.statusCode >= 300) throw AiException(_err(body, r.statusCode));
    final j = jsonDecode(body) as Map<String, dynamic>;
    final parts = (j['content'] as List)
        .where((e) => e['type'] == 'text')
        .map((e) => e['text'].toString());
    return parts.join('\n').trim();
  }

  String _err(String body, int code) {
    try {
      final j = jsonDecode(body);
      final e = j['error'];
      if (e is Map && e['message'] != null) return '${e['message']}';
      if (e is String) return e;
    } catch (_) {}
    if (code == 401 || code == 403) return 'مفتاح API غير صالح ($code)';
    if (code == 429) return 'تجاوزت الحد المسموح، حاول لاحقاً (429)';
    return 'خطأ من الخادم ($code)';
  }

  // ───────── مهام جاهزة ─────────

  static const chatSystem =
      'أنت مساعد دراسة ودود ومختصر. أجب بلغة المستخدم (العربية افتراضياً) '
      'وبدون Markdown. ساعد في تعلم اللغات والمواد الدراسية وقدّم أمثلة قصيرة.';

  static const feynmanSystem =
      'أنت مقيّم بأسلوب فاينمان وتتصرف كطالب فضولي. سيشرح لك المستخدم موضوعاً '
      'بكلماته. بعد كل شرح: (1) قل ما فهمته بجملة بسيطة، (2) حدّد الثغرات أو '
      'الغموض أو المصطلحات غير المشروحة، (3) اطرح سؤالاً واحداً يبسّط أو يختبر '
      'الفهم، (4) أعطِ تقييماً للوضوح من 10. اكتب بلغة المستخدم (العربية '
      'افتراضياً) وبدون Markdown.';

  Future<String> summarizeImage(Uint8List bytes) => ask(
        system: 'أنت مساعد دراسة دقيق.',
        image: bytes,
        history: [
          ChatMsg(
              'user',
              'استخرج النص من هذه الصورة ثم لخّصه تلخيصاً منظماً للمذاكرة: '
                  'عنوان قصير، ثم النقاط الرئيسية (كل نقطة تبدأ بـ •)، ثم أهم '
                  'المصطلحات مع تعريف من سطر واحد. بدون Markdown. بنفس لغة '
                  'المحتوى (العربية إن كان مختلطاً).'),
        ],
      );

  Future<List<QuizQ>> makeQuiz(String text, int n) async {
    final raw = await ask(
      system: 'أنت منشئ اختبارات. أعد JSON فقط بلا أي شرح.',
      history: [
        ChatMsg(
            'user',
            'أنشئ $n أسئلة اختيار من متعدد (4 خيارات لكل سؤال) من النص التالي. '
                'أعد مصفوفة JSON فقط بهذا الشكل: '
                '[{"q":"السؤال","options":["أ","ب","ج","د"],"answer":0,'
                '"explain":"شرح قصير"}] حيث answer هو فهرس الخيار الصحيح (0-3). '
                'استخدم لغة النص.\n\nالنص:\n$text'),
      ],
    );
    return parseQuiz(raw);
  }

  Future<Map<String, String>> translate(List<String> words) async {
    final raw = await ask(
      system: 'أنت مترجم. أعد JSON فقط.',
      history: [
        ChatMsg(
            'user',
            'ترجم كل كلمة أو عبارة التالية إلى العربية بترجمة قصيرة. أعد كائن '
                'JSON فقط على شكل {"الكلمة":"الترجمة"}.\n${words.join('\n')}'),
      ],
    );
    final t = raw.replaceAll('```json', '').replaceAll('```', '');
    final a = t.indexOf('{');
    final b = t.lastIndexOf('}');
    if (a < 0 || b <= a) throw AiException('تعذّرت قراءة الترجمة');
    final m = jsonDecode(t.substring(a, b + 1)) as Map<String, dynamic>;
    return m.map((k, v) => MapEntry(k, v.toString()));
  }
}

List<QuizQ> parseQuiz(String raw) {
  final s = raw.replaceAll('```json', '').replaceAll('```', '');
  final a = s.indexOf('[');
  final b = s.lastIndexOf(']');
  if (a < 0 || b <= a) {
    throw AiException('تعذّرت قراءة الأسئلة، حاول مرة أخرى');
  }
  final list = jsonDecode(s.substring(a, b + 1)) as List;
  return list.map((e) {
    final m = e as Map;
    final opts = (m['options'] as List).map((x) => x.toString()).toList();
    final ans = (m['answer'] as num).toInt().clamp(0, opts.length - 1).toInt();
    return QuizQ(m['q'].toString(), opts, ans, (m['explain'] ?? '').toString());
  }).toList();
}
