import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// مؤثرات صوتية قصيرة (assets/sounds): correct, wrong, done, start, flip.
class Sfx {
  Sfx._();
  static final ValueNotifier<bool> enabled = ValueNotifier<bool>(true);
  static final AudioPlayer _player = AudioPlayer();

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      enabled.value = p.getBool('sfx_on') ?? true;
    } catch (_) {}
  }

  static Future<void> setEnabled(bool v) async {
    enabled.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('sfx_on', v);
    } catch (_) {}
  }

  static Future<void> play(String name) async {
    if (!enabled.value) return;
    try {
      await _player.stop();
      await _player.play(AssetSource('sounds/$name.wav'), volume: 0.8);
    } catch (_) {}
  }
}
