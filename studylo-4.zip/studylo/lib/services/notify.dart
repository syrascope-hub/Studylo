import 'dart:math';
import 'dart:ui' show Color;

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../store.dart';

/// إشعارات: تذكير يومي بكلمة اليوم + نهاية جلسات بومودورو (تعمل والتطبيق مغلق).
class Notify {
  static final FlutterLocalNotificationsPlugin _p =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const int idDaily = 1, idPomoEnd = 2, idPomoRun = 3, idTest = 9;
  static const _brown = Color(0xFFC8A27A);

  static Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _p.initialize(const InitializationSettings(android: android));
    final a = _p.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    _ready = true;
  }

  static NotificationDetails _details(
    String channel,
    String name, {
    bool ongoing = false,
    int? timeoutMs,
    String? big,
  }) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channel,
        name,
        importance: Importance.high,
        priority: Priority.high,
        ongoing: ongoing,
        autoCancel: !ongoing,
        timeoutAfter: timeoutMs,
        color: _brown,
        styleInformation: big == null ? null : BigTextStyleInformation(big),
      ),
    );
  }

  static tz.TZDateTime _at(DateTime t) => tz.TZDateTime.from(t, tz.local);

  /// تذكير يومي بنمط حديث: عنوان بكلمة اليوم + ترجمتها.
  static Future<void> refreshDaily(AppState a) async {
    if (!_ready) return;
    await _p.cancel(idDaily);
    if (!a.settings.notifOn) return;

    var title = 'Studylo · وقت المراجعة 🌿';
    var body = 'ادخل وراجع كلماتك اليوم، دقائق قليلة تكفي.';
    if (a.cards.isNotEmpty) {
      final c = a.cards[Random().nextInt(a.cards.length)];
      title = 'كلمة اليوم: ${c.front}';
      body = '${c.back}\nاضغط لتراجع بطاقاتك الآن';
    }

    final now = DateTime.now();
    var t = DateTime(now.year, now.month, now.day, a.settings.notifH,
        a.settings.notifM);
    if (!t.isAfter(now)) t = t.add(const Duration(days: 1));

    await _p.zonedSchedule(
      idDaily,
      title,
      body,
      _at(t),
      _details('daily', 'التذكير اليومي', big: body),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  static Future<void> test() async {
    await _p.show(
      idTest,
      'الإشعارات تعمل 🎉',
      'ستصلك كلمة اليوم في الوقت الذي اخترته.',
      _details('daily', 'التذكير اليومي'),
    );
  }

  static Future<void> pomoStart(DateTime end,
      {required bool work, required int mins}) async {
    if (!_ready) return;
    await _p.cancel(idPomoEnd);
    await _p.cancel(idPomoRun);

    final title = work ? 'انتهى وقت التركيز 🌸' : 'انتهت الاستراحة ☕';
    final body =
        work ? 'ازدهرت نبتتك! خذ استراحة قصيرة.' : 'هيا نزرع نبتة جديدة.';
    final d = _details('pomo_end', 'نهاية جلسة التركيز');

    try {
      await _p.zonedSchedule(
        idPomoEnd,
        title,
        body,
        _at(end),
        d,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (_) {
      await _p.zonedSchedule(
        idPomoEnd,
        title,
        body,
        _at(end),
        d,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    }

    await _p.show(
      idPomoRun,
      work ? 'جلسة تركيز جارية 🌱' : 'استراحة جارية ☕',
      work ? 'نبتتك تنمو… لا تغادر!' : 'استرح قليلاً.',
      _details('pomo_run', 'الجلسة الجارية',
          ongoing: true, timeoutMs: mins * 60000),
    );
  }

  static Future<void> pomoCancel() async {
    if (!_ready) return;
    await _p.cancel(idPomoEnd);
    await _p.cancel(idPomoRun);
  }

  static Future<void> pomoRunningOff() async {
    if (!_ready) return;
    await _p.cancel(idPomoRun);
  }
}
