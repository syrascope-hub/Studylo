import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

/// يلتقط صورة ويحفظ نسخة داخل مجلد التطبيق ويعيد مسارها.
Future<String?> saveImage(ImageSource src, {double maxWidth = 900}) async {
  final x = await ImagePicker()
      .pickImage(source: src, maxWidth: maxWidth, imageQuality: 72);
  if (x == null) return null;
  final base = await getApplicationDocumentsDirectory();
  final dir = Directory('${base.path}/imgs');
  if (!await dir.exists()) await dir.create(recursive: true);
  final path = '${dir.path}/${DateTime.now().microsecondsSinceEpoch}.jpg';
  await File(x.path).copy(path);
  return path;
}

Future<String?> chooseImage(BuildContext context,
    {double maxWidth = 900}) async {
  final src = await showModalBottomSheet<ImageSource>(
    context: context,
    builder: (c) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('الكاميرا'),
            onTap: () => Navigator.pop(c, ImageSource.camera),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('المعرض'),
            onTap: () => Navigator.pop(c, ImageSource.gallery),
          ),
        ],
      ),
    ),
  );
  if (src == null) return null;
  try {
    return await saveImage(src, maxWidth: maxWidth);
  } catch (_) {
    return null;
  }
}
