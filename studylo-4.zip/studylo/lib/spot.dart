import 'package:flutter/material.dart';

/// رسمة جاهزة من assets/illus: e_cards, e_trophy, e_books, e_idea, e_rocket, e_target.
class Spot extends StatelessWidget {
  const Spot(this.name, {super.key, this.size = 170});
  final String name;
  final double size;

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/illus/$name.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.medium,
        errorBuilder: (_, __, ___) => SizedBox(width: size, height: size),
      );
}
