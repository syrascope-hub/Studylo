import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'screens/settings.dart';
import 'theme.dart';

TextDirection dirOf(String s) =>
    RegExp(r'[֐-ࣿ]').hasMatch(s) ? TextDirection.rtl : TextDirection.ltr;

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));
}

/// بطاقة بإطار سميك وظل صلب (أسلوب الرسوم المسطحة).
class SoftCard extends StatelessWidget {
  const SoftCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.shadow = true,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final Color? color;
  final bool shadow;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final r = BorderRadius.circular(22);
    return Container(
      decoration: BoxDecoration(
        color: color ?? p.surface,
        borderRadius: r,
        border: Border.all(color: p.line, width: 2),
        boxShadow:
            shadow ? [BoxShadow(color: p.line, offset: const Offset(3, 3))] : null,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: r,
        child: InkWell(
          borderRadius: r,
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

/// ظهور متدرج للعناصر.
class Pop extends StatelessWidget {
  const Pop({super.key, required this.child, this.index = 0});
  final Widget child;
  final int index;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 380 + index * 80),
      curve: Curves.easeOutCubic,
      builder: (c, v, ch) => Opacity(
        opacity: v.clamp(0.0, 1.0).toDouble(),
        child: Transform.translate(offset: Offset(0, (1 - v) * 26), child: ch),
      ),
      child: child,
    );
  }
}

class TabHeader extends StatelessWidget {
  const TabHeader({super.key, required this.title, this.subtitle, this.trailing});
  final String title;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              if (subtitle != null)
                Text(subtitle!, style: TextStyle(color: p.muted, fontSize: 14)),
            ],
          ),
        ),
        if (trailing != null) trailing!,
        IconButton(
          tooltip: 'الإعدادات',
          icon: const Icon(Icons.settings_outlined, size: 26),
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
        ),
      ],
    );
  }
}

class CardImage extends StatelessWidget {
  const CardImage(this.path, {super.key, this.height = 100});
  final String path;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Image.file(
        File(path),
        height: height,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (c, e, s) =>
            SizedBox(height: height, child: const Icon(Icons.broken_image_outlined)),
      ),
    );
  }
}

/// بطاقة تتقلب بحركة ثلاثية الأبعاد.
class FlipCard extends StatelessWidget {
  const FlipCard({
    super.key,
    required this.front,
    required this.back,
    this.image,
    required this.flipped,
    required this.onTap,
    this.height = 220,
  });

  final String front, back;
  final String? image;
  final bool flipped;
  final VoidCallback onTap;
  final double height;

  Widget _face(BuildContext context, String text, String? img, bool isBack) {
    final p = Pal.of(context);
    return SoftCard(
      color: isBack ? p.accent : p.surface,
      padding: const EdgeInsets.all(14),
      child: SizedBox(
        height: height - 28,
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (img != null && !isBack) ...[
              CardImage(img, height: (height - 28) * 0.5),
              const SizedBox(height: 10),
            ],
            Flexible(
              child: Text(
                text,
                textAlign: TextAlign.center,
                textDirection: dirOf(text),
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: isBack ? p.onAccent : p.text,
                ),
              ),
            ),
            if (!isBack)
              Text('اضغط للقلب',
                  style: TextStyle(color: p.muted, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: flipped ? 1.0 : 0.0),
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeInOut,
        builder: (c, v, _) {
          final showBack = v > 0.5;
          return Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(v * math.pi),
            child: showBack
                ? Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()..rotateY(math.pi),
                    child: _face(context, back, image, true),
                  )
                : _face(context, front, image, false),
          );
        },
      ),
    );
  }
}

class ToolCard extends StatelessWidget {
  const ToolCard({
    super.key,
    required this.icon,
    required this.title,
    required this.desc,
    required this.onTap,
  });
  final IconData icon;
  final String title, desc;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return SoftCard(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: p.accent,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: p.line, width: 2),
            ),
            child: Icon(icon, color: p.onAccent, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(desc, style: TextStyle(color: p.muted, fontSize: 13)),
              ],
            ),
          ),
          Icon(Icons.chevron_left_rounded, color: p.muted),
        ],
      ),
    );
  }
}

/// تنبيه عند عدم وجود مفتاح API.
class NeedKey extends StatelessWidget {
  const NeedKey({super.key});
  @override
  Widget build(BuildContext context) {
    return SoftCard(
      child: Column(
        children: [
          const Text('أضف مفتاح API للذكاء الاصطناعي لتفعيل هذه الميزة.',
              textAlign: TextAlign.center),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
            child: const Text('فتح الإعدادات'),
          ),
        ],
      ),
    );
  }
}
