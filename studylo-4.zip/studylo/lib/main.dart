import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'screens/home.dart';
import 'services/notify.dart';
import 'services/sfx.dart';
import 'store.dart';
import 'studylo/pomodoro.dart' as sl;
import 'studylo/state.dart' as sl;
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Sfx.load();
  final app = AppState();
  await app.load();
  final studylo = sl.AppState();
  await studylo.load();
  final studyloPomo = sl.PomodoroController(studylo);
  try {
    await Notify.init();
    await Notify.refreshDaily(app);
  } catch (_) {}
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider<AppState>.value(value: app),
      ChangeNotifierProvider<sl.AppState>.value(value: studylo),
      ChangeNotifierProvider<sl.PomodoroController>.value(value: studyloPomo),
    ],
    child: const StudyloApp(),
  ));
}

class StudyloApp extends StatelessWidget {
  const StudyloApp({super.key});

  @override
  Widget build(BuildContext context) {
    final mode = context.select<AppState, String>((a) => a.settings.theme);
    return MaterialApp(
      title: 'Studylo',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: mode == 'light'
          ? ThemeMode.light
          : mode == 'dark'
              ? ThemeMode.dark
              : ThemeMode.system,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeShell(),
    );
  }
}
