import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// مصدر واحد للبطاقات تشترك فيه واجهة ورقة وقسم Studylo:
/// أي بطاقة تُضاف أو تُعدَّل أو تُحذف في أحدهما تظهر فوراً في الآخر.
class CardStore extends ChangeNotifier {
  CardStore._();
  static final CardStore instance = CardStore._();

  static const _key = 'cards';
  final List<Flashcard> cards = [];
  SharedPreferences? _p;
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    _p = await SharedPreferences.getInstance();
    try {
      final c = _p!.getString(_key);
      if (c != null) {
        cards
          ..clear()
          ..addAll((jsonDecode(c) as List)
              .map((e) => Flashcard.fromJson(Map<String, dynamic>.from(e as Map))));
      }
    } catch (_) {}
    _loaded = true;
  }

  /// يحفظ ويُعلم المستمعين (الطرفين).
  void save() {
    _p?.setString(_key, jsonEncode(cards.map((e) => e.toJson()).toList()));
    notifyListeners();
  }
}
