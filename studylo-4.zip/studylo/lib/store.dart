import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'card_store.dart';
import 'models.dart';
import 'services/ai.dart';
import 'services/notify.dart';
import 'services/sfx.dart';

class AppState extends ChangeNotifier {
  SharedPreferences? _p;

  final CardStore _cs = CardStore.instance;
  List<Flashcard> get cards => _cs.cards;
  Settings settings = Settings();
  List<ChatMsg> chat = [];
  Pomo pomo = Pomo();

  AppState() {
    // أي تغيير في البطاقات (من ورقة أو Studylo) يحدّث الواجهة هنا.
    _cs.addListener(notifyListeners);
  }

  AiService get ai => AiService(settings);

  // ───────── التحميل والحفظ ─────────
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    await _cs.load();
    try {
      final s = _p!.getString('settings');
      if (s != null) settings.load(Map<String, dynamic>.from(jsonDecode(s) as Map));
      final ch = _p!.getString('chat');
      if (ch != null) {
        chat = (jsonDecode(ch) as List)
            .map((e) => ChatMsg.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      }
      final po = _p!.getString('pomo');
      if (po != null) pomo.load(Map<String, dynamic>.from(jsonDecode(po) as Map));
    } catch (_) {}
    pomoTick();
  }

  void _saveCards() => _cs.save();
  void _saveChat() =>
      _p?.setString('chat', jsonEncode(chat.map((e) => e.toJson()).toList()));
  void _savePomo() => _p?.setString('pomo', jsonEncode(pomo.toJson()));

  Future<void> saveSettings({bool reschedule = false}) async {
    await _p?.setString('settings', jsonEncode(settings.toJson()));
    notifyListeners();
    if (reschedule) {
      try {
        await Notify.refreshDaily(this);
      } catch (_) {}
    }
  }

  // ───────── البطاقات ─────────
  static String _id() =>
      '${DateTime.now().microsecondsSinceEpoch}${Random().nextInt(999)}';

  void addCard(String front, String back, String? image) {
    cards.add(Flashcard(id: _id(), front: front, back: back, image: image));
    _saveCards();
    notifyListeners();
  }

  void addMany(List<Flashcard> list) {
    cards.addAll(list);
    _saveCards();
    notifyListeners();
  }

  Flashcard make(String front, String back, String? image) =>
      Flashcard(id: _id(), front: front, back: back, image: image);

  void updateCard(Flashcard c, String front, String back) {
    c.front = front;
    c.back = back;
    _saveCards();
    notifyListeners();
  }

  void deleteCard(Flashcard c) {
    cards.removeWhere((e) => e.id == c.id);
    final img = c.image;
    if (img != null) {
      try {
        File(img).deleteSync();
      } catch (_) {}
    }
    _saveCards();
    notifyListeners();
  }

  // نظام لايتنر: 0..5 بفواصل بالأيام
  static const _days = [0, 1, 2, 4, 8, 16];

  List<Flashcard> dueCards() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final l = cards.where((c) => c.due <= now).toList();
    l.sort((a, b) => a.due.compareTo(b.due));
    return l;
  }

  void review(Flashcard c, bool known) {
    c.box = known ? min(c.box + 1, 5) : 0;
    c.due = DateTime.now().millisecondsSinceEpoch + _days[c.box] * 86400000;
    _saveCards();
    notifyListeners();
  }

  // ───────── المحادثة ─────────
  void addChat(ChatMsg m) {
    chat.add(m);
    if (chat.length > 60) chat = chat.sublist(chat.length - 60);
    _saveChat();
    notifyListeners();
  }

  void clearChat() {
    chat = [];
    _saveChat();
    notifyListeners();
  }

  // ───────── بومودورو (يعتمد على وقت الانتهاء فيستمر والتطبيق مغلق) ─────────
  int get pomoRemainingMs {
    if (pomo.phase == 'idle') return 0;
    final r = pomo.endMs - DateTime.now().millisecondsSinceEpoch;
    return r < 0 ? 0 : r;
  }

  double get pomoProgress {
    if (pomo.phase == 'idle') return 0;
    final total = pomo.endMs - pomo.startMs;
    if (total <= 0) return 1;
    final p = (DateTime.now().millisecondsSinceEpoch - pomo.startMs) / total;
    return p.clamp(0.0, 1.0).toDouble();
  }

  double get plantGrowth {
    if (pomo.phase == 'work') return pomoProgress;
    if (pomo.last == 'work') return 1;
    if (pomo.last == 'wilt') return pomo.lastGrowth;
    if (pomo.phase == 'break') return 1;
    return 0;
  }

  bool get plantWilt => pomo.phase != 'work' && pomo.last == 'wilt';

  Future<void> startPomo(String phase) async {
    final mins = phase == 'work' ? settings.workMin : settings.breakMin;
    final now = DateTime.now().millisecondsSinceEpoch;
    pomo.phase = phase;
    pomo.startMs = now;
    pomo.endMs = now + mins * 60000;
    if (phase == 'work') pomo.last = '';
    _savePomo();
    notifyListeners();
    try {
      await Notify.pomoStart(DateTime.fromMillisecondsSinceEpoch(pomo.endMs),
          work: phase == 'work', mins: mins);
    } catch (_) {}
  }

  Future<void> cancelPomo() async {
    if (pomo.phase == 'work') {
      pomo.lastGrowth = pomoProgress;
      pomo.wilted++;
      pomo.last = 'wilt';
    } else {
      pomo.last = '';
    }
    pomo.phase = 'idle';
    _savePomo();
    notifyListeners();
    try {
      await Notify.pomoCancel();
    } catch (_) {}
  }

  void pomoTick() {
    if (pomo.phase == 'idle') return;
    if (DateTime.now().millisecondsSinceEpoch < pomo.endMs) return;
    if (pomo.phase == 'work') {
      pomo.grown++;
      pomo.last = 'work';
      Sfx.play('done');
    } else {
      pomo.last = 'break';
      Sfx.play('start');
    }
    pomo.phase = 'idle';
    _savePomo();
    notifyListeners();
    Notify.pomoRunningOff().catchError((_) {});
  }
}
