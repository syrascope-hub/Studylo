#!/usr/bin/env bash
# يجهّز مجلد android ويثبّت الحزم ويولّد أيقونة التطبيق.
# الاستخدام (من جذر المشروع):  bash tool/setup.sh
set -euo pipefail

if [ ! -d android ]; then
  TMP="$(mktemp -d)"
  flutter create --platforms=android --org com.studylo --project-name studylo "$TMP/app"
  cp -r "$TMP/app/android" ./android
  rm -rf "$TMP"
fi

python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
echo "تم. الآن: flutter run   أو   flutter build apk --release"
