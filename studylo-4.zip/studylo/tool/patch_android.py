"""يعدّل مشروع android المولَّد بـ flutter create: الصلاحيات، مستقبلات الإشعارات،
اسم التطبيق، وdesugaring المطلوب لـ flutter_local_notifications."""
import pathlib
import re
import sys

root = pathlib.Path("android")
manifest = root / "app/src/main/AndroidManifest.xml"
if not manifest.exists():
    sys.exit("android/ folder not found - run flutter create first")

t = manifest.read_text(encoding="utf-8")

PERMS = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32"/>
    <queries>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
    </queries>
"""

RECEIVERS = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""

if "POST_NOTIFICATIONS" not in t:
    t = t.replace("<application", PERMS + "    <application", 1)
if "ScheduledNotificationReceiver" not in t:
    t = t.replace("</application>", RECEIVERS + "    </application>", 1)
t = re.sub(r'android:label="[^"]*"', 'android:label="Studylo"', t, count=1)
manifest.write_text(t, encoding="utf-8")

# ---- gradle: core library desugaring ----
app = root / "app"
kts = app / "build.gradle.kts"
groovy = app / "build.gradle"
if kts.exists():
    g = kts.read_text(encoding="utf-8")
    if "isCoreLibraryDesugaringEnabled" not in g:
        g = re.sub(r"compileOptions\s*\{",
                   "compileOptions {\n        isCoreLibraryDesugaringEnabled = true",
                   g, count=1)
        g += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n}\n'
        kts.write_text(g, encoding="utf-8")
elif groovy.exists():
    g = groovy.read_text(encoding="utf-8")
    if "coreLibraryDesugaringEnabled" not in g:
        g = re.sub(r"compileOptions\s*\{",
                   "compileOptions {\n        coreLibraryDesugaringEnabled true",
                   g, count=1)
        g += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'\n}\n"
        groovy.write_text(g, encoding="utf-8")
else:
    sys.exit("no app/build.gradle(.kts) found")

print("android patched")


# ---- رفع إصدارات Kotlin / AGP / Gradle (قالب Flutter 3.24 قديم على الحزم الحالية) ----
KOTLIN = "1.9.24"
AGP = "8.3.2"
GRADLE = "8.7"


def _ver(v):
    return tuple(int(x) for x in re.findall(r"\d+", v))


def sub_file(path, pattern, target):
    """يرفع الإصدار إلى target فقط إذا كان أقدم منه (لا يخفّض أبداً)."""
    if not path.exists():
        return
    s = path.read_text(encoding="utf-8")

    def fix(m):
        cur = m.group(2)
        return m.group(1) + (target if _ver(cur) < _ver(target) else cur)

    n = re.sub(pattern, fix, s)
    if n != s:
        path.write_text(n, encoding="utf-8")
        print("updated", path)


for name in ("settings.gradle", "settings.gradle.kts"):
    f = root / name
    sub_file(f, r'(org\.jetbrains\.kotlin\.android["\']\)?\s*version\s*\(?\s*["\'])([^"\']+)', KOTLIN)
    sub_file(f, r'(com\.android\.application["\']\)?\s*version\s*\(?\s*["\'])([^"\']+)', AGP)

for name in ("build.gradle", "build.gradle.kts"):
    f = root / name
    sub_file(f, r"(ext\.kotlin_version\s*=\s*['\"])([^'\"]+)", KOTLIN)
    sub_file(f, r"(com\.android\.tools\.build:gradle:)([\d.]+)", AGP)

sub_file(root / "gradle/wrapper/gradle-wrapper.properties",
         r"(gradle-)([\d.]+)(?=-(?:all|bin)\.zip)", GRADLE)
print("gradle versions checked")

# ---- minSdk 24 (مطلوب لـ flutter_tts و flutter_secure_storage) ----
for name in ("build.gradle", "build.gradle.kts"):
    g = app / name
    if g.exists():
        t = g.read_text(encoding="utf-8")
        t = re.sub(r"minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)", "minSdk = 24", t)
        g.write_text(t, encoding="utf-8")
print("minSdk set to 24")

# ---- تشخيص: اطبع الإصدارات النهائية في سجل البناء ----
for name in ("settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts"):
    f = root / name
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            if re.search(r"kotlin|com\.android\.(application|tools\.build)", line):
                print(f"[{name}]", line.strip())
gw = root / "gradle/wrapper/gradle-wrapper.properties"
if gw.exists():
    print([l for l in gw.read_text().splitlines() if "distributionUrl" in l])
